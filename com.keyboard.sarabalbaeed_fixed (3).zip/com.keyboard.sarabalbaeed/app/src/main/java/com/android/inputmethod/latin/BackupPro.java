package com.android.inputmethod.latin;

import android.app.Activity;
import android.app.AlertDialog;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.view.View;
import android.view.inputmethod.InputMethodManager;
import android.widget.TextView;
import inputmethod.latin.perfectkeyboard.R;

/* loaded from: classes.dex */
public class BackupPro extends Activity implements DialogInterface.OnClickListener {
    private View ChangeInputButton;
    private View enableKeyboardButton;
    private View removeiconButton;
    private View shareKeyboardButton;

    // هذي أول شاشة يشوفها المستخدم فعلياً وقت فتح التطبيق، فهذا المكان الصحيح لطلب
    // الصلاحيات (ميكروفون/جهات اتصال/تخزين) وقت التشغيل على أندرويد 6+. بدونها الصلاحيات
    // تضل مرفوضة دايماً حتى لو مكتوبة بالـ AndroidManifest.
    private void requestNeededPermissionsIfMissing() {
        if (Build.VERSION.SDK_INT < 23) {
            return;
        }
        try {
            java.util.ArrayList<String> missing = new java.util.ArrayList<>();
            String[] candidates = {
                    "android.permission.RECORD_AUDIO",
                    "android.permission.READ_CONTACTS",
                    "android.permission.WRITE_EXTERNAL_STORAGE",
                    "android.permission.READ_EXTERNAL_STORAGE"
            };
            for (String p : candidates) {
                if (checkSelfPermission(p) != PackageManager.PERMISSION_GRANTED) {
                    missing.add(p);
                }
            }
            if (!missing.isEmpty()) {
                requestPermissions(missing.toArray(new String[0]), 4210);
            }
        } catch (Throwable ignored) {
        }
    }

    @Override // android.app.Activity
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        requestNeededPermissionsIfMissing();
        setContentView(R.layout.main_luncher);
        TextView textView1 = (TextView) findViewById(R.id.textView1);
        textView1.setText("كيبورد السراب البعيد  3.0.0 \n\n  برمجة: أحمد باسم \n\n تلكرام: u200u \n\n الهاتف: 07722927144 \n\n الايميل: gggk14k@gmail.com");
        this.enableKeyboardButton = findViewById(R.id.enable_keyboard);
        this.enableKeyboardButton.setOnClickListener(new View.OnClickListener() { // from class: com.android.inputmethod.latin.BackupPro.1
            @Override // android.view.View.OnClickListener
            public void onClick(View v) {
                Intent intent = new Intent();
                intent.setClassName("com.android.settings", "com.android.settings.LanguageSettings");
                intent.setFlags(268435456);
                try {
                    BackupPro.this.startActivity(intent);
                } catch (Throwable th) {
                    try {
                        Intent intent2 = new Intent();
                        intent2.setClassName("com.android.settings.Settings$InputMethodConfigActivity", "com.android.settings.LanguageSettings");
                        intent2.setFlags(268435456);
                        BackupPro.this.startActivity(intent);
                    } catch (Throwable th2) {
                        AlertDialog.Builder builder = new AlertDialog.Builder(BackupPro.this);
                        builder.setMessage("Sorry,this shortcut doesn't work on your device.\nYou still can enable the keyboard by going to Settings / Language & keyboard / perfect Keyboard. \nWe will appreciate if you will let us know about this issue").setCancelable(false).setPositiveButton("Ok", new DialogInterface.OnClickListener() { // from class: com.android.inputmethod.latin.BackupPro.1.1
                            @Override // android.content.DialogInterface.OnClickListener
                            public void onClick(DialogInterface dialog, int id) {
                                dialog.cancel();
                            }
                        });
                        AlertDialog alert = builder.create();
                        alert.show();
                    }
                }
            }
        });
        this.ChangeInputButton = findViewById(R.id.switch_to_keyboard);
        this.ChangeInputButton.setOnClickListener(new View.OnClickListener() { // from class: com.android.inputmethod.latin.BackupPro.2
            @Override // android.view.View.OnClickListener
            public void onClick(View v) {
                ((InputMethodManager) BackupPro.this.getSystemService("input_method")).showInputMethodPicker();
            }
        });
        this.shareKeyboardButton = findViewById(R.id.share_keyboard);
        this.shareKeyboardButton.setOnClickListener(new View.OnClickListener() { // from class: com.android.inputmethod.latin.BackupPro.3
            @Override // android.view.View.OnClickListener
            public void onClick(View v) {
                Intent i = new Intent("android.intent.action.VIEW");
                i.setData(Uri.parse("https://ap9ap.com"));
                BackupPro.this.startActivity(i);
            }
        });
    }

    @Override // android.content.DialogInterface.OnClickListener
    public void onClick(DialogInterface arg0, int arg1) {
        for (int i = 0; i < 10; i = i + 1 + 1) {
        }
    }
}
