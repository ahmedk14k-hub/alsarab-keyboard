package com.android.inputmethod.latin;

import android.app.Activity;
import android.app.Application;
import android.graphics.Insets;
import android.os.Build;
import android.os.Bundle;
import android.view.View;
import android.view.ViewTreeObserver;
import android.view.WindowInsets;
import java.util.Map;
import java.util.WeakHashMap;

/** Keeps screens clear of the system bars on Android 15+ (edge-to-edge). */
public class AlsarabApp extends Application {
    private static final Map<Activity, Boolean> sDone = new WeakHashMap<Activity, Boolean>();

    @Override
    public void onCreate() {
        super.onCreate();
        if (Build.VERSION.SDK_INT >= 35) {
            registerActivityLifecycleCallbacks(new ActivityLifecycleCallbacks() {
                @Override public void onActivityStarted(Activity a) { applyInsets(a); }
                @Override public void onActivityCreated(Activity a, Bundle b) { }
                @Override public void onActivityResumed(Activity a) { }
                @Override public void onActivityPaused(Activity a) { }
                @Override public void onActivityStopped(Activity a) { }
                @Override public void onActivitySaveInstanceState(Activity a, Bundle b) { }
                @Override public void onActivityDestroyed(Activity a) { }
            });
        }
    }

    private static void applyInsets(final Activity a) {
        try {
            if (sDone.containsKey(a)) {
                return;
            }
            final View content = a.findViewById(android.R.id.content);
            if (content == null) {
                return;
            }
            sDone.put(a, Boolean.TRUE);
            content.getViewTreeObserver().addOnGlobalLayoutListener(new ViewTreeObserver.OnGlobalLayoutListener() {
                @Override
                public void onGlobalLayout() {
                    fixPadding(a, content);
                }
            });
            content.requestLayout();
        } catch (Throwable ignored) {
        }
    }

    /** Pads the content so it sits below the action bar / status bar and above the navigation bar. */
    private static void fixPadding(Activity a, View content) {
        try {
            View decor = a.getWindow().getDecorView();
            WindowInsets wi = decor.getRootWindowInsets();
            if (wi == null || content.getHeight() == 0) {
                return;
            }
            Insets bars = wi.getInsets(WindowInsets.Type.systemBars() | WindowInsets.Type.displayCutout());
            int[] c = new int[2];
            content.getLocationInWindow(c);
            int cTop = c[1];
            int cLeft = c[0];
            int cBottom = cTop + content.getHeight();
            int cRight = cLeft + content.getWidth();

            int topEdge = bars.top;
            int abId = a.getResources().getIdentifier("action_bar_container", "id", "android");
            View ab = abId != 0 ? decor.findViewById(abId) : null;
            if (ab != null && ab.getVisibility() == View.VISIBLE && ab.getHeight() > 0) {
                int[] l = new int[2];
                ab.getLocationInWindow(l);
                topEdge = Math.max(topEdge, l[1] + ab.getHeight());
            }
            int padTop = Math.max(0, topEdge - cTop);
            int padBottom = Math.max(0, cBottom - (decor.getHeight() - bars.bottom));
            int padLeft = Math.max(0, bars.left - cLeft);
            int padRight = Math.max(0, cRight - (decor.getWidth() - bars.right));
            if (padLeft != content.getPaddingLeft() || padTop != content.getPaddingTop()
                    || padRight != content.getPaddingRight() || padBottom != content.getPaddingBottom()) {
                content.setPadding(padLeft, padTop, padRight, padBottom);
            }
        } catch (Throwable ignored) {
        }
    }
}
