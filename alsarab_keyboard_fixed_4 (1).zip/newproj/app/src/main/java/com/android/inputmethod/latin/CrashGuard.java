package com.android.inputmethod.latin;

import android.content.Context;
import android.content.SharedPreferences;
import android.graphics.Color;
import android.graphics.Typeface;
import android.inputmethodservice.InputMethodService;
import android.util.Log;
import android.view.View;
import android.widget.ScrollView;
import android.widget.TextView;

/**
 * Safety net: remembers the last crash and shows it inside the keyboard area on the next start,
 * so that a failure never ends up as a keyboard that silently "does not appear".
 */
final class CrashGuard {
    private static final String PREFS = "alsarab_crash";
    private static final String KEY = "last";
    private static boolean installed;

    private CrashGuard() {
    }

    static synchronized void install(final Context context) {
        if (installed) {
            return;
        }
        installed = true;
        final Context app = context.getApplicationContext();
        final Thread.UncaughtExceptionHandler previous = Thread.getDefaultUncaughtExceptionHandler();
        Thread.setDefaultUncaughtExceptionHandler(new Thread.UncaughtExceptionHandler() {
            @Override
            public void uncaughtException(Thread thread, Throwable throwable) {
                save(app, "Thread: " + thread.getName() + "\n" + Log.getStackTraceString(throwable));
                if (previous != null) {
                    previous.uncaughtException(thread, throwable);
                }
            }
        });
    }

    static void save(Context context, String text) {
        try {
            context.getSharedPreferences(PREFS, Context.MODE_PRIVATE).edit().putString(KEY, text).commit();
        } catch (Throwable ignored) {
        }
    }

    /** Returns the stored crash text (once) or null. */
    static String take(Context context) {
        try {
            SharedPreferences sp = context.getSharedPreferences(PREFS, Context.MODE_PRIVATE);
            String text = sp.getString(KEY, null);
            if (text != null) {
                sp.edit().remove(KEY).commit();
            }
            return text;
        } catch (Throwable t) {
            return null;
        }
    }

    static View errorView(final InputMethodService service, String text) {
        TextView tv = new TextView(service);
        tv.setText("Alsarab keyboard error (tap to close):\n\n" + text);
        tv.setTextColor(Color.WHITE);
        tv.setTextSize(11f);
        tv.setTypeface(Typeface.MONOSPACE);
        tv.setPadding(16, 16, 16, 16);
        ScrollView sv = new ScrollView(service);
        sv.setBackgroundColor(0xFF8B0000);
        sv.addView(tv);
        sv.setMinimumHeight((int) (220 * service.getResources().getDisplayMetrics().density));
        sv.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                service.requestHideSelf(0);
            }
        });
        return sv;
    }
}
