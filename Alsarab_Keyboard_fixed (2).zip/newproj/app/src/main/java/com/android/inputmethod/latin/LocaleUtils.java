package com.android.inputmethod.latin;

import android.content.res.Configuration;
import android.content.res.Resources;
import android.text.TextUtils;
import java.util.HashMap;
import java.util.Locale;

/* loaded from: classes.dex */
public class LocaleUtils {
    public static final int LOCALE_ANY_MATCH = 10;
    public static final int LOCALE_FULL_MATCH = 30;
    public static final int LOCALE_LANGUAGE_AND_COUNTRY_MATCH = 20;
    public static final int LOCALE_LANGUAGE_AND_COUNTRY_MATCH_VARIANT_DIFFER = 6;
    public static final int LOCALE_LANGUAGE_MATCH = 15;
    public static final int LOCALE_LANGUAGE_MATCH_COUNTRY_DIFFER = 3;
    private static final int LOCALE_MATCH = 10;
    public static final int LOCALE_NO_MATCH = 0;
    private static final int MATCH_LEVEL_MAX = 30;
    private static final HashMap<String, Locale> sLocaleCache = new HashMap<>();

    private LocaleUtils() {
    }

    public static int getMatchLevel(String referenceLocale, String testedLocale) {
        if (TextUtils.isEmpty(referenceLocale)) {
            return TextUtils.isEmpty(testedLocale) ? 30 : 10;
        }
        if (testedLocale == null) {
            return 0;
        }
        String[] referenceParams = referenceLocale.split("_", 3);
        String[] testedParams = testedLocale.split("_", 3);
        if (!referenceParams[0].equals(testedParams[0])) {
            return 0;
        }
        switch (referenceParams.length) {
            case 1:
                return 1 != testedParams.length ? 15 : 30;
            case 2:
                if (1 != testedParams.length && referenceParams[1].equals(testedParams[1])) {
                    return 3 == testedParams.length ? 20 : 30;
                }
                return 3;
            case 3:
                if (1 != testedParams.length && referenceParams[1].equals(testedParams[1])) {
                    return (2 != testedParams.length && referenceParams[2].equals(testedParams[2])) ? 30 : 6;
                }
                return 3;
            default:
                return 0;
        }
    }

    public static String getMatchLevelSortedString(int matchLevel) {
        return String.format("%02d", Integer.valueOf(30 - matchLevel));
    }

    public static boolean isMatch(int level) {
        return 10 <= level;
    }

    public static Locale setSystemLocale(Resources res, Locale newLocale) {
        Configuration conf = res.getConfiguration();
        Locale saveLocale = conf.locale;
        conf.locale = newLocale;
        res.updateConfiguration(conf, res.getDisplayMetrics());
        return saveLocale;
    }

    public static Locale constructLocaleFromString(String localeStr) {
        if (localeStr == null) {
            return null;
        }
        synchronized (sLocaleCache) {
            if (sLocaleCache.containsKey(localeStr)) {
                return sLocaleCache.get(localeStr);
            }
            Locale retval = null;
            String[] localeParams = localeStr.split("_", 3);
            if (localeParams.length == 1) {
                retval = new Locale(localeParams[0]);
            } else if (localeParams.length == 2) {
                retval = new Locale(localeParams[0], localeParams[1]);
            } else if (localeParams.length == 3) {
                retval = new Locale(localeParams[0], localeParams[1], localeParams[2]);
            }
            if (retval != null) {
                sLocaleCache.put(localeStr, retval);
            }
            return retval;
        }
    }
}
