package com.android.inputmethod.latin;

import android.text.method.MetaKeyKeyListener;
import android.view.KeyEvent;
import com.android.inputmethod.latin.LatinKeyboard;

/* loaded from: classes.dex */
public class HardKeyboardActionImpl implements LatinKeyboard.HardKeyboardAction {
    private long mMetaState;
    private int mKeyCode = 0;
    private boolean mChanegd = false;
    private final int META_ACTIVE_ALT = 514;
    private final int META_ACTIVE_SHIFT = 257;

    public void initializeAction(KeyEvent event, long metaState) {
        this.mChanegd = false;
        this.mKeyCode = event.getKeyCode();
        this.mMetaState = metaState;
    }

    @Override // com.android.inputmethod.latin.LatinKeyboard.HardKeyboardAction
    public int getKeyCode() {
        return this.mKeyCode;
    }

    @Override // com.android.inputmethod.latin.LatinKeyboard.HardKeyboardAction
    public boolean isAltActive() {
        return (MetaKeyKeyListener.getMetaState(this.mMetaState) & 514) != 0;
    }

    @Override // com.android.inputmethod.latin.LatinKeyboard.HardKeyboardAction
    public boolean isShiftActive() {
        return (MetaKeyKeyListener.getMetaState(this.mMetaState) & 257) != 0;
    }

    @Override // com.android.inputmethod.latin.LatinKeyboard.HardKeyboardAction
    public void setNewKeyCode(int keyCode) {
        this.mChanegd = true;
        this.mKeyCode = keyCode;
    }

    public boolean getKeyCodeWasChanged() {
        return this.mChanegd;
    }
}
