package com.android.inputmethod.latin;

import android.content.Context;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;
import android.util.Log;

/* loaded from: classes.dex */
public class DatabaseHelper extends SQLiteOpenHelper {
    public static final String KEY = "key";
    public static final String VALUE = "value";

    /* loaded from: classes.dex */
    public class AutoTextEntry {
        String key;
        String value;

        public AutoTextEntry() {
        }
    }

    public DatabaseHelper(Context context, String db) {
        super(context, db, (SQLiteDatabase.CursorFactory) null, 1);
    }

    @Override // android.database.sqlite.SQLiteOpenHelper
    public void onCreate(SQLiteDatabase db) {
        db.execSQL("CREATE TABLE autotext (_id INTEGER PRIMARY KEY AUTOINCREMENT, key TEXT, value TEXT);");
    }

    @Override // android.database.sqlite.SQLiteOpenHelper
    public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {
        Log.w("autotext", "Upgrading database, which will destroy all old data");
        db.execSQL("DROP TABLE IF EXISTS autotext");
        onCreate(db);
    }
}
