package com.android.inputmethod.latin;

import android.content.Context;
import android.content.res.Resources;

/* loaded from: classes.dex */
public class Flag {
    private static final int SOURCE_CONFIG = 1;
    private static final int SOURCE_EXTRAVALUE = 2;
    private static final int SOURCE_PARAM = 3;
    public final int mMask;
    public final String mName;
    public final int mResource;
    public final int mSource;

    public Flag(int resourceId, int mask) {
        this.mName = null;
        this.mResource = resourceId;
        this.mSource = 1;
        this.mMask = mask;
    }

    public Flag(String name, int mask) {
        this.mName = name;
        this.mResource = 0;
        this.mSource = 2;
        this.mMask = mask;
    }

    public Flag(int mask) {
        this.mName = null;
        this.mResource = 0;
        this.mSource = 3;
        this.mMask = mask;
    }

    public static int initFlags(Flag[] flagArray, Context context) {
        int flags = 0;
        Resources res = context == null ? null : context.getResources();
        for (Flag entry : flagArray) {
            switch (entry.mSource) {
                case 1:
                    if (res != null && !res.getBoolean(entry.mResource)) {
                        break;
                    } else {
                        flags |= entry.mMask;
                        break;
                    }
                case 2:
                    flags |= entry.mMask;
                    break;
                case 3:
                    flags |= entry.mMask;
                    break;
            }
        }
        return flags;
    }
}
