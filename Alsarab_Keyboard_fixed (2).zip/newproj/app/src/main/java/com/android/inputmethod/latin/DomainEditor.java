package com.android.inputmethod.latin;

import android.app.AlertDialog;
import android.app.Dialog;
import android.app.backup.BackupManager;
import android.content.ActivityNotFoundException;
import android.content.ComponentName;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.SharedPreferences;
import android.content.pm.PackageManager;
import android.content.res.AssetFileDescriptor;
import android.content.res.Resources;
import android.media.MediaPlayer;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.os.Environment;
import android.os.Process;
import android.os.Vibrator;
import android.preference.CheckBoxPreference;
import android.preference.EditTextPreference;
import android.preference.ListPreference;
import android.preference.Preference;
import android.preference.PreferenceActivity;
import android.preference.PreferenceGroup;
import android.preference.PreferenceManager;
import android.speech.SpeechRecognizer;
import android.text.AutoText;
import android.util.Log;
import android.widget.Toast;
import com.android.common.colorPicker.AmbilWarnaDialog;
import com.android.common.speech.LoggingEvents;
import com.android.inputmethod.voice.SettingsUtil;
import com.android.inputmethod.voice.VoiceInputLogger;
import inputmethod.latin.perfectkeyboard.R;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.util.ArrayList;
import java.util.Locale;

/* loaded from: classes.dex */
public class DomainEditor extends PreferenceActivity implements SharedPreferences.OnSharedPreferenceChangeListener, DialogInterface.OnDismissListener {
    private static final String DISPLAY_LUNCHER_ICON = "display_BackupPro_icon";
    private static final String PREDICTION_SETTINGS_KEY = "prediction_settings";
    private static final String PREF_KB_SOUND_STYLE = "tap_sound_style_pref";
    static final String PREF_LONG_PRESS_DELAY = "long_press_delay";
    private static final String PREF_PUNCTUATION_EDITOR = "punctuation_editor";
    static final String PREF_SETTINGS_KEY = "settings_key";
    private static final String PREF_SOUND_VOLUME = "sound_volume";
    public static final String PREF_SUGGESTION_BAR_COLOR = "suggestion_bar_color";
    private static final String PREF_VIBRATE_LENGTH = "vibration_length";
    private static final String PREF_VIBRATE_ON = "vibrate_on";
    private static final String QUICK_FIXES_KEY = "quick_fixes";
    private static final int REQ_CODE_PICK_IMAGE = 0;
    private static final String TAG = "DomainEditor";
    private static final int VOICE_INPUT_CONFIRM_DIALOG = 0;
    private static final String VOICE_SETTINGS_KEY = "voice_mode";
    private EditTextPreference CustomPunctuationPopup;
    private EditTextPreference CustomSmileys;
    private EditTextPreference customePunctuation;
    private VoiceInputLogger mLogger;
    private int mLongPressDelay;
    private DialogSeekBarPreference mLongPressDelayPreference;
    private CheckBoxPreference mQuickFixes;
    private ListPreference mSettingsKeyPreference;
    private boolean mShowIcon;
    private float mSoundVolume;
    private int mVibrateLength;
    private String mVoiceModeOff;
    private boolean mVoiceOn;
    private ListPreference mVoicePreference;
    String path;
    private EditTextPreference popularDomains;
    public static final String[] PREF_CUSTOME_SMILEYS = {"sm0", "sm1", "sm2", "sm3", "sm4", "sm5", "sm6", "sm7", "sm8", "sm9", "sm10", "sm11", "sm12", "sm13", "sm14", "sm15", "sm16", "sm17", "sm18", "sm19", "sm20", "sm21", "sm22", "sm23", "sm24", "sm25", "sm26", "sm27", "sm28", "sm29", "sm30", "sm31", "sm32", "sm33", "sm34", "sm35", "sm36", "sm37", "sm38", "sm39", "sm40", "sm41", "sm42", "sm43"};
    public static int[] popular_smileys_res = {R.string.sm0, R.string.sm1, R.string.sm2, R.string.sm3, R.string.sm4, R.string.sm5, R.string.sm6, R.string.sm7, R.string.sm8, R.string.sm9, R.string.sm10, R.string.sm11, R.string.sm12, R.string.sm13, R.string.sm14, R.string.sm15, R.string.sm16, R.string.sm17, R.string.sm18, R.string.sm19, R.string.sm20, R.string.sm21, R.string.sm22, R.string.sm23, R.string.sm24, R.string.sm25, R.string.sm26, R.string.sm27, R.string.sm28, R.string.sm29, R.string.sm30, R.string.sm31, R.string.sm32, R.string.sm33, R.string.sm34, R.string.sm35, R.string.sm36, R.string.sm37, R.string.sm38, R.string.sm39, R.string.sm40, R.string.sm41, R.string.sm42, R.string.sm43};
    public static final String[] PREF_CUSTOME_PUNCTUATION_POPUP = {"punctuation0", "punctuation1", "punctuation2", "punctuation3", "punctuation4", "punctuation5", "punctuation6", "punctuation7", "punctuation8", "punctuation9", "punctuation10", "punctuation11", "punctuation12", "punctuation13"};
    public static int[] PunctuationPopup_res = {R.string.punctuation0, R.string.punctuation1, R.string.punctuation2, R.string.punctuation3, R.string.punctuation4, R.string.punctuation5, R.string.punctuation6, R.string.punctuation7, R.string.punctuation8, R.string.punctuation9, R.string.punctuation10, R.string.punctuation11, R.string.punctuation12, R.string.punctuation13};
    public static final String[] PREF_POPULAR_DOMAIN = {"popular_domain_0", "popular_domain_1", "popular_domain_2", "popular_domain_3", "popular_domain_4", "popular_domain_5"};
    public static int[] popular_domains_res = {R.string.popular_domain_0, R.string.popular_domain_1, R.string.popular_domain_2, R.string.popular_domain_3, R.string.popular_domain_4, R.string.popular_domain_5};
    MediaPlayer mTypePlay = null;
    private Vibrator mVibrator = null;
    private boolean mOkClicked = false;

    @Override // android.preference.PreferenceActivity, android.app.Activity
    protected void onCreate(Bundle icicle) {
        super.onCreate(icicle);
        addPreferencesFromResource(R.xml.prefs);
        char[] a = {'h', 'e', 'l', 'p', '_', 's', 'c', 'r', 'e', 'e', 'n'};
        char[] b = {1575, 1604, 1587, 1585, 1575, 1576, ' ', 1575, 1604, 1576, 1593, 1610, 1583};
        findPreference(new String(a)).setTitle(new String(b));
        this.mQuickFixes = (CheckBoxPreference) findPreference(QUICK_FIXES_KEY);
        this.mVoicePreference = (ListPreference) findPreference(VOICE_SETTINGS_KEY);
        this.mSettingsKeyPreference = (ListPreference) findPreference(PREF_SETTINGS_KEY);
        this.mLongPressDelayPreference = (DialogSeekBarPreference) findPreference(PREF_LONG_PRESS_DELAY);
        SharedPreferences prefs = getPreferenceManager().getSharedPreferences();
        HandlePopularDomain(prefs);
        HandleSmileys(prefs);
        HandlePunctuationPopup(prefs);
        HandlePunctuation(prefs);
        prefs.registerOnSharedPreferenceChangeListener(this);
        this.mVoiceModeOff = getString(R.string.voice_mode_off);
        this.mVoiceOn = !prefs.getString(VOICE_SETTINGS_KEY, this.mVoiceModeOff).equals(this.mVoiceModeOff);
        this.mLongPressDelay = prefs.getInt(PREF_LONG_PRESS_DELAY, getResources().getInteger(R.integer.config_long_press_key_timeout));
        this.mLogger = VoiceInputLogger.getLogger(this);
        Preference pref_go_website = findPreference("go_website");
        pref_go_website.setOnPreferenceClickListener(new Preference.OnPreferenceClickListener() { // from class: com.android.inputmethod.latin.DomainEditor.1
            @Override // android.preference.Preference.OnPreferenceClickListener
            public boolean onPreferenceClick(Preference preference) {
                Intent goToMarket = new Intent("android.intent.action.VIEW", Uri.parse("http://alsarab100.blogspot.com"));
                goToMarket.setFlags(268435456);
                try {
                    DomainEditor.this.startActivity(goToMarket);
                    return true;
                } catch (ActivityNotFoundException e) {
                    return true;
                }
            }
        });
        Preference pref_send_feedback = findPreference("send_feedback");
        pref_send_feedback.setOnPreferenceClickListener(new Preference.OnPreferenceClickListener() { // from class: com.android.inputmethod.latin.DomainEditor.2
            @Override // android.preference.Preference.OnPreferenceClickListener
            public boolean onPreferenceClick(Preference preference) {
                Intent emailIntent = new Intent("android.intent.action.SEND");
                Resources res = preference.getContext().getResources();
                String[] aEmailList = {"perfectkeyboards@gmail.com"};
                emailIntent.putExtra("android.intent.extra.EMAIL", aEmailList);
                emailIntent.putExtra("android.intent.extra.SUBJECT", "Perfect keyboard");
                emailIntent.setType("plain/text");
                emailIntent.putExtra("android.intent.extra.TEXT", "Device : " + Build.DEVICE + "\nVersion:" + Build.VERSION.RELEASE + "\nKeyboard version:" + res.getString(R.string.version_string) + "\n\n");
                try {
                    DomainEditor.this.startActivity(emailIntent);
                } catch (ActivityNotFoundException e) {
                }
                return true;
            }
        });
        Preference pref_select_background = findPreference("pref_select_background");
        pref_select_background.setOnPreferenceClickListener(new Preference.OnPreferenceClickListener() { // from class: com.android.inputmethod.latin.DomainEditor.3
            @Override // android.preference.Preference.OnPreferenceClickListener
            public boolean onPreferenceClick(Preference preference) {
                Intent intent = new Intent();
                intent.setType("image/*");
                intent.setAction("android.intent.action.GET_CONTENT");
                DomainEditor.this.startActivityForResult(Intent.createChooser(intent, "Select Picture"), 0);
                return true;
            }
        });
        Preference pref_rate_app = findPreference("rate_application");
        pref_rate_app.setOnPreferenceClickListener(new Preference.OnPreferenceClickListener() { // from class: com.android.inputmethod.latin.DomainEditor.4
            @Override // android.preference.Preference.OnPreferenceClickListener
            public boolean onPreferenceClick(Preference preference) {
                Intent goToMarket = new Intent("android.intent.action.VIEW", Uri.parse("market://details?id=inputmethod.latin.perfectkeyboard"));
                goToMarket.setFlags(268435456);
                try {
                    DomainEditor.this.startActivity(goToMarket);
                    return true;
                } catch (ActivityNotFoundException e) {
                    return true;
                }
            }
        });
        Preference pref_download_full = findPreference("full_version");
        pref_download_full.setOnPreferenceClickListener(new Preference.OnPreferenceClickListener() { // from class: com.android.inputmethod.latin.DomainEditor.5
            @Override // android.preference.Preference.OnPreferenceClickListener
            public boolean onPreferenceClick(Preference preference) {
                Intent goToMarket = new Intent("android.intent.action.VIEW", Uri.parse("market://details?id=inputmethod.latin.perfectkeyboard"));
                goToMarket.setFlags(268435456);
                try {
                    DomainEditor.this.startActivity(goToMarket);
                    return true;
                } catch (ActivityNotFoundException e) {
                    return true;
                }
            }
        });
        PreferenceGroup generalSettings = (PreferenceGroup) findPreference("english_ime_settings");
        if (0 == 0) {
            if (getApplicationInfo().packageName.equals("inputmethod.latin.perfectkeyboard")) {
                generalSettings.removePreference(pref_download_full);
            }
        } else {
            generalSettings.removePreference(pref_download_full);
            generalSettings.removePreference(pref_rate_app);
        }
        Preference restore_fies = findPreference("restore_files");
        restore_fies.setOnPreferenceClickListener(new Preference.OnPreferenceClickListener() { // from class: com.android.inputmethod.latin.DomainEditor.6
            @Override // android.preference.Preference.OnPreferenceClickListener
            public boolean onPreferenceClick(Preference preference) {
                DomainEditor.this.RestoreDbFiles();
                return true;
            }
        });
        Preference backupt_files = findPreference("backup_files");
        backupt_files.setOnPreferenceClickListener(new Preference.OnPreferenceClickListener() { // from class: com.android.inputmethod.latin.DomainEditor.7
            @Override // android.preference.Preference.OnPreferenceClickListener
            public boolean onPreferenceClick(Preference preference) {
                DomainEditor.this.doBackup();
                return true;
            }
        });
        Preference Pref_suggestion_font_color = findPreference("suggestion_font_color");
        Pref_suggestion_font_color.setOnPreferenceClickListener(new Preference.OnPreferenceClickListener() { // from class: com.android.inputmethod.latin.DomainEditor.8
            @Override // android.preference.Preference.OnPreferenceClickListener
            public boolean onPreferenceClick(Preference preference) {
                Resources res = preference.getContext().getResources();
                AmbilWarnaDialog dialog = new AmbilWarnaDialog(DomainEditor.this, res.getColor(R.color.candidate_recommended), new AmbilWarnaDialog.OnAmbilWarnaListener() { // from class: com.android.inputmethod.latin.DomainEditor.8.1
                    @Override // com.android.common.colorPicker.AmbilWarnaDialog.OnAmbilWarnaListener
                    public void onOk(AmbilWarnaDialog dialog2, int color) {
                        CandidateView.setColor(color);
                        SharedPreferences.Editor editor = PreferenceManager.getDefaultSharedPreferences(DomainEditor.this).edit();
                        editor.putInt("suggestion_font_color", color);
                        SharedPreferencesCompat.apply(editor);
                    }

                    @Override // com.android.common.colorPicker.AmbilWarnaDialog.OnAmbilWarnaListener
                    public void onCancel(AmbilWarnaDialog dialog2) {
                    }
                });
                dialog.show();
                return true;
            }
        });
        Preference button_color_Pref = findPreference("button_color");
        button_color_Pref.setOnPreferenceClickListener(new Preference.OnPreferenceClickListener() { // from class: com.android.inputmethod.latin.DomainEditor.9
            @Override // android.preference.Preference.OnPreferenceClickListener
            public boolean onPreferenceClick(Preference preference) {
                Resources res = preference.getContext().getResources();
                AmbilWarnaDialog dialogbutton = new AmbilWarnaDialog(DomainEditor.this, res.getColor(R.color.button_color), new AmbilWarnaDialog.OnAmbilWarnaListener() { // from class: com.android.inputmethod.latin.DomainEditor.9.1
                    @Override // com.android.common.colorPicker.AmbilWarnaDialog.OnAmbilWarnaListener
                    public void onOk(AmbilWarnaDialog dialog, int color) {
                        LatinKeyboardBaseView.setColor(color);
                        SharedPreferences.Editor editor = PreferenceManager.getDefaultSharedPreferences(DomainEditor.this).edit();
                        editor.putInt("button_color", color);
                        SharedPreferencesCompat.apply(editor);
                    }

                    @Override // com.android.common.colorPicker.AmbilWarnaDialog.OnAmbilWarnaListener
                    public void onCancel(AmbilWarnaDialog dialog) {
                    }
                });
                dialogbutton.show();
                return true;
            }
        });
        Preference Pref_keyboard_background_color = findPreference("keyboard_background_color");
        Pref_keyboard_background_color.setOnPreferenceClickListener(new Preference.OnPreferenceClickListener() { // from class: com.android.inputmethod.latin.DomainEditor.10
            @Override // android.preference.Preference.OnPreferenceClickListener
            public boolean onPreferenceClick(Preference preference) {
                AmbilWarnaDialog dialogbackgroundColor = new AmbilWarnaDialog(DomainEditor.this, -16777216, new AmbilWarnaDialog.OnAmbilWarnaListener() { // from class: com.android.inputmethod.latin.DomainEditor.10.1
                    @Override // com.android.common.colorPicker.AmbilWarnaDialog.OnAmbilWarnaListener
                    public void onOk(AmbilWarnaDialog dialog, int color) {
                        DictionaryEditor.setKeyboardBackgroundColor(color);
                        SharedPreferences.Editor editor = PreferenceManager.getDefaultSharedPreferences(DomainEditor.this).edit();
                        editor.putInt("keyboard_background_color", color);
                        SharedPreferencesCompat.apply(editor);
                    }

                    @Override // com.android.common.colorPicker.AmbilWarnaDialog.OnAmbilWarnaListener
                    public void onCancel(AmbilWarnaDialog dialog) {
                    }
                });
                dialogbackgroundColor.show();
                return true;
            }
        });
        Preference Pref_suggestion_bar_color = findPreference(PREF_SUGGESTION_BAR_COLOR);
        Pref_suggestion_bar_color.setOnPreferenceClickListener(new Preference.OnPreferenceClickListener() { // from class: com.android.inputmethod.latin.DomainEditor.11
            @Override // android.preference.Preference.OnPreferenceClickListener
            public boolean onPreferenceClick(Preference preference) {
                AmbilWarnaDialog dialogbackgroundColor = new AmbilWarnaDialog(DomainEditor.this, -16777216, new AmbilWarnaDialog.OnAmbilWarnaListener() { // from class: com.android.inputmethod.latin.DomainEditor.11.1
                    @Override // com.android.common.colorPicker.AmbilWarnaDialog.OnAmbilWarnaListener
                    public void onOk(AmbilWarnaDialog dialog, int color) {
                        DictionaryEditor.setSuggestionBarColor(color);
                        SharedPreferences.Editor editor = PreferenceManager.getDefaultSharedPreferences(DomainEditor.this).edit();
                        editor.putInt(DomainEditor.PREF_SUGGESTION_BAR_COLOR, color);
                        SharedPreferencesCompat.apply(editor);
                    }

                    @Override // com.android.common.colorPicker.AmbilWarnaDialog.OnAmbilWarnaListener
                    public void onCancel(AmbilWarnaDialog dialog) {
                    }
                });
                dialogbackgroundColor.show();
                return true;
            }
        });
        Preference keyboard_font_symbol_color_new = findPreference("keyboard_font_symbol_color_new");
        keyboard_font_symbol_color_new.setOnPreferenceClickListener(new Preference.OnPreferenceClickListener() { // from class: com.android.inputmethod.latin.DomainEditor.12
            @Override // android.preference.Preference.OnPreferenceClickListener
            public boolean onPreferenceClick(Preference preference) {
                AmbilWarnaDialog dialogbackgroundColor = new AmbilWarnaDialog(DomainEditor.this, -1, new AmbilWarnaDialog.OnAmbilWarnaListener() { // from class: com.android.inputmethod.latin.DomainEditor.12.1
                    @Override // com.android.common.colorPicker.AmbilWarnaDialog.OnAmbilWarnaListener
                    public void onOk(AmbilWarnaDialog dialog, int color) {
                        Calibration.mFontSymbolColors = color;
                        SharedPreferences.Editor editor = PreferenceManager.getDefaultSharedPreferences(DomainEditor.this).edit();
                        editor.putInt("keyboard_font_symbol_color_new", color);
                        SharedPreferencesCompat.apply(editor);
                    }

                    @Override // com.android.common.colorPicker.AmbilWarnaDialog.OnAmbilWarnaListener
                    public void onCancel(AmbilWarnaDialog dialog) {
                    }
                });
                dialogbackgroundColor.show();
                return true;
            }
        });
    }

    @Override // android.app.Activity
    protected void onResume() {
        super.onResume();
        int autoTextSize = AutoText.getSize(getListView());
        if (autoTextSize < 1) {
            ((PreferenceGroup) findPreference(PREDICTION_SETTINGS_KEY)).removePreference(this.mQuickFixes);
        }
        if (!SpeechRecognizer.isRecognitionAvailable(this)) {
            getPreferenceScreen().removePreference(this.mVoicePreference);
        } else {
            updateVoiceModeSummary();
        }
        updateSettingsKeySummary();
        updateLongPressDelaySummary();
    }

    @Override // android.preference.PreferenceActivity, android.app.ListActivity, android.app.Activity
    protected void onDestroy() {
        getPreferenceManager().getSharedPreferences().unregisterOnSharedPreferenceChangeListener(this);
        super.onDestroy();
    }

    @Override // android.content.SharedPreferences.OnSharedPreferenceChangeListener
    public void onSharedPreferenceChanged(SharedPreferences prefs, String key) {
        new BackupManager(this).dataChanged();
        if (key.equals(VOICE_SETTINGS_KEY) && !this.mVoiceOn) {
            if (!prefs.getString(VOICE_SETTINGS_KEY, this.mVoiceModeOff).equals(this.mVoiceModeOff)) {
                showVoiceConfirmation();
            }
        } else if (PREF_VIBRATE_LENGTH.equals(key)) {
            if (this.mVibrator == null) {
                this.mVibrator = (Vibrator) getSystemService("vibrator");
            }
            this.mVibrateLength = prefs.getInt(PREF_VIBRATE_LENGTH, getResources().getInteger(R.integer.vibrate_duration_ms));
            this.mVibrator.vibrate(this.mVibrateLength);
        } else if (PREF_SOUND_VOLUME.equals(key) || PREF_KB_SOUND_STYLE.equals(key)) {
            String soundStyle = prefs.getString(PREF_KB_SOUND_STYLE, getString(R.string.sound_android));
            if ((PREF_SOUND_VOLUME.equals(key) && this.mTypePlay == null) || PREF_KB_SOUND_STYLE.equals(key)) {
                if (this.mTypePlay != null) {
                    this.mTypePlay.release();
                }
                if (soundStyle.equals(getString(R.string.sound_android))) {
                    this.path = "android.ogg";
                } else if (soundStyle.equals(getString(R.string.sound_iphone))) {
                    this.path = "iphone.ogg";
                } else if (soundStyle.equals(getString(R.string.sound_samsung))) {
                    this.path = "samsung.ogg";
                } else if (soundStyle.equals(getString(R.string.sound_winphone))) {
                    this.path = "tock.ogg";
                } else if (soundStyle.equals(getString(R.string.sound_custom))) {
                    File sdcard = Environment.getExternalStorageDirectory();
                    this.mTypePlay = new MediaPlayer();
                    this.mTypePlay.setAudioStreamType(1);
                    this.path = String.valueOf(sdcard.getAbsolutePath()) + File.separator + "external_sd" + File.separator + "custom.ogg";
                    try {
                        this.mTypePlay.setDataSource(this.path);
                    } catch (IOException e) {
                        e.printStackTrace();
                    } catch (IllegalArgumentException e2) {
                        e2.printStackTrace();
                    } catch (IllegalStateException e3) {
                        e3.printStackTrace();
                    }
                    try {
                        this.mTypePlay.prepare();
                    } catch (IOException e4) {
                        e4.printStackTrace();
                    } catch (IllegalStateException e5) {
                        e5.printStackTrace();
                    }
                }
                if (!soundStyle.equals(getString(R.string.sound_custom))) {
                    this.mTypePlay = new MediaPlayer();
                    this.mTypePlay.setAudioStreamType(1);
                    try {
                        AssetFileDescriptor descriptor = getAssets().openFd(this.path);
                        this.mTypePlay.setDataSource(descriptor.getFileDescriptor(), descriptor.getStartOffset(), descriptor.getLength());
                        descriptor.close();
                    } catch (IOException e6) {
                        e6.printStackTrace();
                    } catch (IllegalArgumentException e7) {
                        e7.printStackTrace();
                    } catch (IllegalStateException e8) {
                        e8.printStackTrace();
                    }
                    try {
                        this.mTypePlay.prepare();
                    } catch (IOException e9) {
                        e9.printStackTrace();
                    } catch (IllegalStateException e10) {
                        e10.printStackTrace();
                    }
                }
            }
            if (PREF_SOUND_VOLUME.equals(key)) {
                this.mSoundVolume = prefs.getInt(PREF_SOUND_VOLUME, getResources().getInteger(R.integer.config_defalut_sound_volume));
                this.mTypePlay.setVolume(this.mSoundVolume / 100.0f, this.mSoundVolume / 100.0f);
                this.mTypePlay.start();
            }
        }
        if (DISPLAY_LUNCHER_ICON.equals(key)) {
            PackageManager pm = getPackageManager();
            String packagename = getBaseContext().getPackageName();
            this.mShowIcon = prefs.getBoolean(DISPLAY_LUNCHER_ICON, true);
            if (this.mShowIcon) {
                pm.setComponentEnabledSetting(new ComponentName(packagename, "com.android.inputmethod.latin.BackupPro"), 0, 1);
            } else {
                pm.setComponentEnabledSetting(new ComponentName(packagename, "com.android.inputmethod.latin.BackupPro"), 2, 1);
            }
        }
        this.mVoiceOn = !prefs.getString(VOICE_SETTINGS_KEY, this.mVoiceModeOff).equals(this.mVoiceModeOff);
        this.mLongPressDelay = prefs.getInt(PREF_LONG_PRESS_DELAY, getResources().getInteger(R.integer.config_long_press_key_timeout));
        updateVoiceModeSummary();
        updateSettingsKeySummary();
        updateLongPressDelaySummary();
        HandlePopularDomain(prefs);
        HandleSmileys(prefs);
        HandlePunctuationPopup(prefs);
        HandlePunctuation(prefs);
    }

    private void updateSettingsKeySummary() {
        this.mSettingsKeyPreference.setSummary(getResources().getStringArray(R.array.settings_key_modes)[this.mSettingsKeyPreference.findIndexOfValue(this.mSettingsKeyPreference.getValue())]);
    }

    private void updateLongPressDelaySummary() {
        this.mLongPressDelayPreference.setSummary(String.format(getResources().getString(R.string.long_press_delay_summary), Integer.valueOf(this.mLongPressDelay)));
    }

    private void showVoiceConfirmation() {
        this.mOkClicked = false;
        showDialog(0);
    }

    private void updateVoiceModeSummary() {
        this.mVoicePreference.setSummary(getResources().getStringArray(R.array.voice_input_modes_summary)[this.mVoicePreference.findIndexOfValue(this.mVoicePreference.getValue())]);
    }

    @Override // android.app.Activity
    protected Dialog onCreateDialog(int id) {
        switch (id) {
            case 0:
                DialogInterface.OnClickListener listener = new DialogInterface.OnClickListener() { // from class: com.android.inputmethod.latin.DomainEditor.13
                    @Override // android.content.DialogInterface.OnClickListener
                    public void onClick(DialogInterface dialog, int whichButton) {
                        if (whichButton == -2) {
                            DomainEditor.this.mVoicePreference.setValue(DomainEditor.this.mVoiceModeOff);
                            DomainEditor.this.mLogger.settingsWarningDialogCancel();
                        } else if (whichButton == -1) {
                            DomainEditor.this.mOkClicked = true;
                            DomainEditor.this.mLogger.settingsWarningDialogOk();
                        }
                        DomainEditor.this.updateVoicePreference();
                    }
                };
                AlertDialog.Builder builder = new AlertDialog.Builder(this).setTitle(R.string.voice_warning_title).setPositiveButton(android.R.string.ok, listener).setNegativeButton(android.R.string.cancel, listener);
                String supportedLocalesString = SettingsUtil.getSettingsString(getContentResolver(), SettingsUtil.LATIN_IME_VOICE_INPUT_SUPPORTED_LOCALES, DictionaryEditor.DEFAULT_VOICE_INPUT_SUPPORTED_LOCALES);
                ArrayList<String> voiceInputSupportedLocales = DictionaryEditor.newArrayList(supportedLocalesString.split("\\s+"));
                boolean localeSupported = voiceInputSupportedLocales.contains(Locale.getDefault().toString());
                if (localeSupported) {
                    String message = String.valueOf(getString(R.string.voice_warning_may_not_understand)) + "\n\n" + getString(R.string.voice_hint_dialog_message);
                    builder.setMessage(message);
                } else {
                    String message2 = String.valueOf(getString(R.string.voice_warning_locale_not_supported)) + "\n\n" + getString(R.string.voice_warning_may_not_understand) + "\n\n" + getString(R.string.voice_hint_dialog_message);
                    builder.setMessage(message2);
                }
                AlertDialog dialog = builder.create();
                dialog.setOnDismissListener(this);
                this.mLogger.settingsWarningDialogShown();
                return dialog;
            default:
                Log.e(TAG, "unknown dialog " + id);
                return null;
        }
    }

    void doBackup() {
        DialogInterface.OnClickListener listener = new DialogInterface.OnClickListener() { // from class: com.android.inputmethod.latin.DomainEditor.14
            @Override // android.content.DialogInterface.OnClickListener
            public void onClick(DialogInterface dialog, int whichButton) {
                if (whichButton != -2 && whichButton == -1) {
                    DomainEditor.this.backupDbFiles();
                }
            }
        };
        File Sdcard = Environment.getExternalStorageDirectory();
        String backupdirPath = String.valueOf(Sdcard.getAbsolutePath()) + "/pkeyboard/";
        AlertDialog.Builder builder = new AlertDialog.Builder(this).setTitle(R.string.warning).setMessage(String.valueOf(getString(R.string.warning_will_erase_backup)) + " " + backupdirPath + " \n" + getString(R.string.warning_will_erase_backup_two)).setIcon(android.R.drawable.stat_sys_warning).setPositiveButton(android.R.string.ok, listener).setNegativeButton(android.R.string.cancel, listener);
        AlertDialog dialog = builder.create();
        dialog.show();
    }

    @Override // android.content.DialogInterface.OnDismissListener
    public void onDismiss(DialogInterface dialog) {
        this.mLogger.settingsWarningDialogDismissed();
        if (!this.mOkClicked) {
            this.mVoicePreference.setValue(this.mVoiceModeOff);
        }
    }

    /* JADX INFO: Access modifiers changed from: private */
    public void updateVoicePreference() {
        boolean isChecked = !this.mVoicePreference.getValue().equals(this.mVoiceModeOff);
        if (isChecked) {
            this.mLogger.voiceInputSettingEnabled();
        } else {
            this.mLogger.voiceInputSettingDisabled();
        }
    }

    private void HandlePopularDomain(SharedPreferences prefs) {
        for (int i = 0; i < 6; i++) {
            String DefaultString = getString(popular_domains_res[i]);
            String temp = prefs.getString(PREF_POPULAR_DOMAIN[i], getString(popular_domains_res[i]));
            this.popularDomains = (EditTextPreference) findPreference(PREF_POPULAR_DOMAIN[i]);
            if (temp.equals(LoggingEvents.EXTRA_CALLING_APP_NAME)) {
                temp = DefaultString;
            }
            this.popularDomains.setText(temp);
            this.popularDomains.setTitle(temp);
            LatinKeyboardBaseView.popularDomains[i] = this.popularDomains.getText();
        }
    }

    private void HandleSmileys(SharedPreferences prefs) {
        for (int i = 0; i < 44; i++) {
            String DefaultString = getString(popular_smileys_res[i]);
            String temp = prefs.getString(PREF_CUSTOME_SMILEYS[i], getString(popular_smileys_res[i]));
            this.CustomSmileys = (EditTextPreference) findPreference(PREF_CUSTOME_SMILEYS[i]);
            if (temp.equals(LoggingEvents.EXTRA_CALLING_APP_NAME)) {
                temp = DefaultString;
            }
            this.CustomSmileys.setText(temp);
            this.CustomSmileys.setTitle(temp);
            LatinKeyboardBaseView.CustomSmileys[i] = this.CustomSmileys.getText();
        }
    }

    private void HandlePunctuationPopup(SharedPreferences prefs) {
        for (int i = 0; i < 13; i++) {
            String DefaultString = getString(PunctuationPopup_res[i]);
            String temp = prefs.getString(PREF_CUSTOME_PUNCTUATION_POPUP[i], getString(PunctuationPopup_res[i]));
            this.CustomPunctuationPopup = (EditTextPreference) findPreference(PREF_CUSTOME_PUNCTUATION_POPUP[i]);
            if (temp.equals(LoggingEvents.EXTRA_CALLING_APP_NAME) || temp.length() != 1) {
                temp = DefaultString;
            }
            this.CustomPunctuationPopup.setText(temp);
            this.CustomPunctuationPopup.setTitle(temp);
            LatinKeyboardBaseView.CustomPunctuationPopup[i] = this.CustomPunctuationPopup.getText();
        }
    }

    private void HandlePunctuation(SharedPreferences prefs) {
        String temp = prefs.getString(PREF_PUNCTUATION_EDITOR, getString(R.string.suggested_punctuations));
        this.customePunctuation = (EditTextPreference) findPreference(PREF_PUNCTUATION_EDITOR);
        this.customePunctuation.setText(temp);
        this.customePunctuation.setTitle(temp);
    }

    void backupDbFiles() {
        boolean succeed = backupSingleDBfile(getDatabasePath("autotext.db"), "temp1.dat");
        if (succeed) {
            succeed = backupSingleDBfile(getDatabasePath("auto_dict.db"), "temp2.dat");
        }
        if (succeed) {
            succeed = backupSingleDBfile(getDatabasePath("userbigram_dict.db"), "temp3.dat");
        }
        if (succeed && getApplicationInfo().dataDir != null) {
            File shared_prefs = new File(String.valueOf(getApplicationInfo().dataDir) + "/shared_prefs/", String.valueOf(getPackageName()) + "_preferences.xml");
            succeed = backupSingleDBfile(shared_prefs, "temp4.dat");
        }
        new DialogInterface.OnClickListener() { // from class: com.android.inputmethod.latin.DomainEditor.15
            @Override // android.content.DialogInterface.OnClickListener
            public void onClick(DialogInterface dialog, int whichButton) {
            }
        };
        if (succeed) {
            Toast toast = Toast.makeText(this, getString(R.string.backup_succeed), 0);
            toast.show();
        } else {
            Toast toast2 = Toast.makeText(this, getString(R.string.backup_failed), 0);
            toast2.show();
        }
    }

    boolean backupSingleDBfile(File file, String BackupFile) {
        try {
            InputStream dbStream = new FileInputStream(file);
            try {
                File Sdcard = Environment.getExternalStorageDirectory();
                String backupdirPath = String.valueOf(Sdcard.getAbsolutePath()) + "/pkeyboard/";
                File backupDirectory = new File(backupdirPath);
                backupDirectory.mkdirs();
                File outputFile = new File(backupDirectory, BackupFile);
                FileOutputStream backupDbStream = new FileOutputStream(outputFile);
                byte[] buffer = new byte[MyMetaKeyKeyListener.META_SYM_LOCKED];
                while (true) {
                    try {
                        int length = dbStream.read(buffer);
                        if (length <= 0) {
                            return true;
                        }
                        backupDbStream.write(buffer, 0, length);
                    } catch (IOException e) {
                        e.printStackTrace();
                        return false;
                    }
                }
            } catch (FileNotFoundException e2) {
                e2.printStackTrace();
                return false;
            }
        } catch (IOException e3) {
            e3.printStackTrace();
            return false;
        }
    }

    void RestoreDbFiles() {
        String backupdirPath = getApplicationInfo().dataDir;
        File backupDirectory = new File(backupdirPath);
        backupDirectory.mkdirs();
        String backupdirPath2 = String.valueOf(getApplicationInfo().dataDir) + "/databases/";
        File backupDirectory2 = new File(backupdirPath2);
        backupDirectory2.mkdirs();
        String backupdirPath3 = String.valueOf(getApplicationInfo().dataDir) + "/shared_prefs/";
        File backupDirectory3 = new File(backupdirPath3);
        backupDirectory3.mkdirs();
        boolean succeed = RestoreSingleDBfile("temp1.dat", String.valueOf(getApplicationInfo().dataDir) + "/databases/", "autotext.db");
        if (succeed) {
            succeed = RestoreSingleDBfile("temp2.dat", String.valueOf(getApplicationInfo().dataDir) + "/databases/", "auto_dict.db");
        }
        if (succeed) {
            succeed = RestoreSingleDBfile("temp3.dat", String.valueOf(getApplicationInfo().dataDir) + "/databases/", "userbigram_dict.db");
        }
        if (succeed && getApplicationInfo().dataDir != null) {
            succeed = RestoreSingleDBfile("temp4.dat", String.valueOf(getApplicationInfo().dataDir) + "/shared_prefs/", String.valueOf(getPackageName()) + "_preferences.xml");
        }
        if (succeed) {
            Toast toast = Toast.makeText(this, getString(R.string.restore_succeed), 0);
            toast.show();
            Process.killProcess(Process.myPid());
        } else {
            Toast toast2 = Toast.makeText(this, getString(R.string.restore_failed), 1);
            toast2.show();
        }
    }

    boolean RestoreSingleDBfile(String Backupfile, String restoredFilePath, String restoredFileName) {
        File outputfile = new File(restoredFilePath, restoredFileName);
        try {
            FileOutputStream dbStream = new FileOutputStream(outputfile);
            File Sdcard = Environment.getExternalStorageDirectory();
            String backupdirPath = String.valueOf(Sdcard.getAbsolutePath()) + "/pkeyboard/";
            File backupDirectory = new File(backupdirPath);
            File InputFile = new File(backupDirectory, Backupfile);
            try {
                InputStream backupStream = new FileInputStream(InputFile);
                byte[] buffer = new byte[MyMetaKeyKeyListener.META_SYM_LOCKED];
                while (true) {
                    try {
                        int length = backupStream.read(buffer);
                        if (length > 0) {
                            dbStream.write(buffer, 0, length);
                        } else {
                            backupStream.close();
                            dbStream.flush();
                            dbStream.close();
                            return true;
                        }
                    } catch (IOException e) {
                        e.printStackTrace();
                        return false;
                    }
                }
            } catch (FileNotFoundException e2) {
                e2.printStackTrace();
                return false;
            }
        } catch (FileNotFoundException e3) {
            e3.printStackTrace();
            return false;
        }
    }

    @Override // android.preference.PreferenceActivity, android.app.Activity
    protected void onActivityResult(int requestCode, int resultCode, Intent imageReturnedIntent) {
        super.onActivityResult(requestCode, resultCode, imageReturnedIntent);
        switch (requestCode) {
            case 0:
                if (resultCode == -1) {
                    Uri selectedImage = imageReturnedIntent.getData();
                    SharedPreferences.Editor editor = PreferenceManager.getDefaultSharedPreferences(this).edit();
                    editor.putString(Calibration.PREF_URI_BACKGROUND_IMAGE, selectedImage.toString());
                    SharedPreferencesCompat.apply(editor);
                    return;
                }
                return;
            default:
                return;
        }
    }
}
