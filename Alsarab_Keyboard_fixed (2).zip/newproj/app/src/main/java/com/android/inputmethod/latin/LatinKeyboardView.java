package com.android.inputmethod.latin;

import android.content.Context;
import android.graphics.Canvas;
import android.graphics.Paint;
import android.inputmethodservice.Keyboard;
import android.os.Handler;
import android.os.IBinder;
import android.text.TextUtils;
import android.util.AttributeSet;
import android.view.MotionEvent;
import com.android.inputmethod.latin.DictionaryEditorUtil;
import java.util.List;

/* loaded from: classes.dex */
public class LatinKeyboardView extends LatinKeyboardBaseView {
    static final boolean DEBUG_AUTO_PLAY = false;
    static final boolean DEBUG_LINE = false;
    static final int KEYCODE_DOWN_ARROW = 20;
    static final int KEYCODE_F1 = -103;
    static final int KEYCODE_HIDE_KEYBOARD = -12;
    static final int KEYCODE_LEFT_ARROW = 21;
    static final int KEYCODE_MODE_CHANGE_LONGPRESS = -108;
    static final int KEYCODE_NEXT_LANGUAGE = -104;
    static final int KEYCODE_OPTIONS = -100;
    static final int KEYCODE_OPTIONS_LONGPRESS = -101;
    static final int KEYCODE_PREV_LANGUAGE = -105;
    static final int KEYCODE_REPLACE = -9;
    static final int KEYCODE_RIGHT_ARROW = 22;
    static final int KEYCODE_SCROLL_CANDIDATE = -11;
    static final int KEYCODE_SECOND_SPACE = -13;
    static final int KEYCODE_T9 = -10;
    static final int KEYCODE_TOGLE_ARROW_OFF = -107;
    static final int KEYCODE_TOGLE_ARROW_ON = -106;
    static final int KEYCODE_UP_ARROW = 19;
    static final int KEYCODE_VOICE = -102;
    private static final int MSG_TOUCH_DOWN = 1;
    private static final int MSG_TOUCH_UP = 2;
    private Keyboard.Key[] mAsciiKeys;
    private boolean mDisableDisambiguation;
    private boolean mDownDelivered;
    private boolean mDroppingEvents;
    Handler mHandler2;
    private int mJumpThresholdSquare;
    private int mLastRowY;
    private int mLastX;
    private int mLastY;
    private Paint mPaint;
    private Keyboard mPhoneKeyboard;
    private boolean mPlaying;
    private int mStringIndex;
    private String mStringToPlay;

    public LatinKeyboardView(Context context, AttributeSet attrs) {
        this(context, attrs, 0);
    }

    public LatinKeyboardView(Context context, AttributeSet attrs, int defStyle) {
        super(context, attrs, defStyle);
        this.mJumpThresholdSquare = Integer.MAX_VALUE;
        this.mAsciiKeys = new Keyboard.Key[MyMetaKeyKeyListener.META_CAP_LOCKED];
    }

    public void setPhoneKeyboard(Keyboard phoneKeyboard) {
        this.mPhoneKeyboard = phoneKeyboard;
    }

    @Override // com.android.inputmethod.latin.LatinKeyboardBaseView
    public void setPreviewEnabled(boolean previewEnabled) {
        if (getKeyboard() == this.mPhoneKeyboard) {
            super.setPreviewEnabled(false);
        } else {
            super.setPreviewEnabled(previewEnabled);
        }
    }

    @Override // com.android.inputmethod.latin.LatinKeyboardBaseView
    public void setKeyboard(Keyboard newKeyboard) {
        Keyboard oldKeyboard = getKeyboard();
        if (oldKeyboard instanceof LatinKeyboard) {
            ((LatinKeyboard) oldKeyboard).keyReleased();
        }
        super.setKeyboard(newKeyboard);
        this.mJumpThresholdSquare = newKeyboard.getMinWidth() / 7;
        this.mJumpThresholdSquare *= this.mJumpThresholdSquare;
        if (LatinKeyboard.mode_arrows) {
            if (Calibration.isFourRowLayout) {
                this.mLastRowY = (newKeyboard.getHeight() * 5) / 6;
            } else {
                this.mLastRowY = (newKeyboard.getHeight() * 4) / 5;
            }
        } else if (Calibration.isFourRowLayout) {
            this.mLastRowY = (newKeyboard.getHeight() * 3) / 4;
        } else {
            this.mLastRowY = (newKeyboard.getHeight() * 4) / 5;
        }
        setKeyboardLocal(newKeyboard);
    }

    /* JADX INFO: Access modifiers changed from: protected */
    @Override // com.android.inputmethod.latin.LatinKeyboardBaseView
    public boolean onLongPress(Keyboard.Key key) {
        int primaryCode = key.codes[0];
        if (DictionaryEditor.mLongPressOn123ToSettings && primaryCode == -2) {
            return invokeOnKey(KEYCODE_MODE_CHANGE_LONGPRESS);
        }
        if (primaryCode == KEYCODE_OPTIONS) {
            return invokeOnKey(KEYCODE_OPTIONS_LONGPRESS);
        }
        if (primaryCode == 48 && getKeyboard() == this.mPhoneKeyboard) {
            return invokeOnKey(43);
        }
        if (primaryCode != 1) {
            if (primaryCode == 46) {
                return invokeOnKey(6);
            }
            if (primaryCode == 1604) {
                return invokeOnKey(7);
            }
            return super.onLongPress(key);
        }
        return invokeOnKey(2);
    }

    private boolean invokeOnKey(int primaryCode) {
        getOnKeyboardActionListener().onKey(primaryCode, null, -1, -1);
        return true;
    }

    @Override // com.android.inputmethod.latin.LatinKeyboardBaseView
    protected CharSequence adjustCase(CharSequence label) {
        Keyboard keyboard = getKeyboard();
        if (keyboard.isShifted() && (keyboard instanceof LatinKeyboard) && ((LatinKeyboard) keyboard).isAlphaKeyboard() && !TextUtils.isEmpty(label) && label.length() < 5 && Character.isLowerCase(label.charAt(0))) {
            return label.toString().toUpperCase();
        }
        return label;
    }

    public boolean setShiftLocked(boolean shiftLocked) {
        Keyboard keyboard = getKeyboard();
        if (!(keyboard instanceof LatinKeyboard)) {
            return false;
        }
        ((LatinKeyboard) keyboard).setShiftLocked(shiftLocked);
        invalidateAllKeys();
        return true;
    }

    private boolean handleSuddenJump(MotionEvent me) {
        int action = me.getAction();
        int x = (int) me.getX();
        int y = (int) me.getY();
        boolean result = false;
        if (me.getPointerCount() > 1) {
            this.mDisableDisambiguation = true;
        }
        if (this.mDisableDisambiguation) {
            if (action != 1) {
                return false;
            }
            this.mDisableDisambiguation = false;
            return false;
        }
        switch (action) {
            case 0:
                this.mDroppingEvents = false;
                this.mDisableDisambiguation = false;
                break;
            case 1:
                if (this.mDroppingEvents) {
                    MotionEvent translated = MotionEvent.obtain(me.getEventTime(), me.getEventTime(), 0, x, y, me.getMetaState());
                    super.onTouchEvent(translated);
                    translated.recycle();
                    this.mDroppingEvents = false;
                    break;
                }
                break;
            case 2:
                int i = ((this.mLastX - x) * (this.mLastX - x)) + ((this.mLastY - y) * (this.mLastY - y));
                if (this.mDroppingEvents) {
                    result = true;
                    break;
                }
                break;
        }
        this.mLastX = x;
        this.mLastY = y;
        return result;
    }

    @Override // com.android.inputmethod.latin.LatinKeyboardBaseView, android.view.View
    public boolean onTouchEvent(MotionEvent me) {
        LatinKeyboard keyboard = (LatinKeyboard) getKeyboard();
        if (handleSuddenJump(me)) {
            return true;
        }
        if (me.getAction() == 0) {
            keyboard.keyReleased();
        }
        if (me.getAction() == 1) {
            int languageDirection = keyboard.getLanguageChangeDirection();
            if (languageDirection != 0) {
                getOnKeyboardActionListener().onKey(languageDirection == 1 ? KEYCODE_NEXT_LANGUAGE : KEYCODE_PREV_LANGUAGE, null, this.mLastX, this.mLastY);
                me.setAction(3);
                keyboard.keyReleased();
                return super.onTouchEvent(me);
            }
            int ArrayDirection = keyboard.getArraoyChangeDirection();
            if (ArrayDirection != 0) {
                getOnKeyboardActionListener().onKey(ArrayDirection == 1 ? KEYCODE_TOGLE_ARROW_OFF : KEYCODE_TOGLE_ARROW_ON, null, this.mLastX, this.mLastY);
                me.setAction(3);
                keyboard.keyReleased();
                return super.onTouchEvent(me);
            }
        }
        return super.onTouchEvent(me);
    }

    private void setKeyboardLocal(Keyboard k) {
    }

    private void findKeys() {
        List<Keyboard.Key> keys = getKeyboard().getKeys();
        for (int i = 0; i < keys.size(); i++) {
            int code = keys.get(i).codes[0];
            if (code >= 0 && code <= 255) {
                this.mAsciiKeys[code] = keys.get(i);
            }
        }
    }

    public void startPlaying(String s) {
    }

    @Override // android.view.View
    public void draw(Canvas c) {
        DictionaryEditorUtil.GCUtils.getInstance().reset();
        boolean tryGC = true;
        for (int i = 0; i < 5 && tryGC; i++) {
            try {
                super.draw(c);
                tryGC = false;
            } catch (OutOfMemoryError e) {
                tryGC = DictionaryEditorUtil.GCUtils.getInstance().tryGCOrWait("LatinKeyboardView", e);
            }
        }
    }

    public void requestShiftKeyRedraw() {
        if (canInteractWithUi()) {
            super.invalidate();
        }
    }

    protected boolean canInteractWithUi() {
        IBinder ib = getWindowToken();
        return ib != null && ib.isBinderAlive() && getWidth() > 0;
    }
}
