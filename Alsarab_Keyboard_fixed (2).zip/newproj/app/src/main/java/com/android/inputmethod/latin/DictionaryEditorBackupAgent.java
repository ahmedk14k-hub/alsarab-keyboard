package com.android.inputmethod.latin;

import android.app.backup.BackupAgentHelper;
import android.app.backup.SharedPreferencesBackupHelper;

/* loaded from: classes.dex */
public class DictionaryEditorBackupAgent extends BackupAgentHelper {
    @Override // android.app.backup.BackupAgent
    public void onCreate() {
        addHelper("shared_pref", new SharedPreferencesBackupHelper(this, String.valueOf(getPackageName()) + "_preferences"));
    }
}
