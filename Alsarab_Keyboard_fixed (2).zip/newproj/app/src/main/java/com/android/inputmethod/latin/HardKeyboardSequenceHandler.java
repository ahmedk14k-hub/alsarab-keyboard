package com.android.inputmethod.latin;

import java.security.InvalidParameterException;
import java.util.HashMap;

/* loaded from: classes.dex */
public class HardKeyboardSequenceHandler {
    private static final int[] msQwerty = {45, 51, 33, 46, 48, 53, 49, 37, 43, 44, 29, 47, 32, 34, 35, 36, 38, 39, 40, 54, 52, 31, 50, 30, 42, 41};
    private static final long msSequenceLivingTime = 600;
    private final HashMap<KeyEventSequence, KeyEventSequence> mSequences = new HashMap<>();
    private final HashMap<Integer, Character> mAltMapping = new HashMap<>();
    private final HashMap<Integer, Character> mShiftMapping = new HashMap<>();
    private final KeyEventSequenceHolder mCurrentTypedSequence = new KeyEventSequenceHolder();
    private long mLastTypedKeyEventTime = System.currentTimeMillis();

    /* loaded from: classes.dex */
    private static abstract class KeyEventSequenceBase {
        protected abstract int getIntAt(int i);

        public abstract int getSequenceLength();

        protected KeyEventSequenceBase() {
        }

        public boolean equals(Object o) {
            if (o instanceof KeyEventSequenceBase) {
                KeyEventSequenceBase other = (KeyEventSequenceBase) o;
                if (other.hashCode() != hashCode() || other.getSequenceLength() != getSequenceLength()) {
                    return false;
                }
                for (int i = 0; i < getSequenceLength(); i++) {
                    if (other.getIntAt(i) != getIntAt(i)) {
                        return false;
                    }
                }
                return true;
            }
            return super.equals(o);
        }
    }

    /* JADX INFO: Access modifiers changed from: private */
    /* loaded from: classes.dex */
    public static class KeyEventSequence extends KeyEventSequenceBase {
        private final int mHashCode;
        private final int[] mSequence;
        private final char mTarget;

        public KeyEventSequence(int[] keyEventSequence, char target) {
            this.mTarget = target;
            this.mSequence = keyEventSequence;
            int hashCode = 0;
            for (int i = 0; i < this.mSequence.length; i++) {
                hashCode += this.mSequence[i];
            }
            this.mHashCode = hashCode;
        }

        public char getTarget() {
            return this.mTarget;
        }

        @Override // com.android.inputmethod.latin.HardKeyboardSequenceHandler.KeyEventSequenceBase
        public int getSequenceLength() {
            return this.mSequence.length;
        }

        public int hashCode() {
            return this.mHashCode;
        }

        @Override // com.android.inputmethod.latin.HardKeyboardSequenceHandler.KeyEventSequenceBase
        protected int getIntAt(int i) {
            return this.mSequence[i];
        }
    }

    /* JADX INFO: Access modifiers changed from: private */
    /* loaded from: classes.dex */
    public static class KeyEventSequenceHolder extends KeyEventSequenceBase {
        private int mDeletedCharactersTillNow;
        private final int[] mSequence = new int[10];
        private int mHashCode = 0;
        private int mCurrentSequenceLength = 0;

        public void appendKeyEvent(int keyEvent) {
            this.mSequence[this.mCurrentSequenceLength % this.mSequence.length] = keyEvent;
            this.mCurrentSequenceLength++;
            this.mHashCode += keyEvent;
        }

        public void reset() {
            this.mCurrentSequenceLength = 0;
            this.mHashCode = 0;
            this.mDeletedCharactersTillNow = 0;
        }

        @Override // com.android.inputmethod.latin.HardKeyboardSequenceHandler.KeyEventSequenceBase
        public int getSequenceLength() {
            return this.mCurrentSequenceLength;
        }

        public int getDeletedCharactersCountTillNow() {
            return this.mDeletedCharactersTillNow;
        }

        public int hashCode() {
            return this.mHashCode;
        }

        @Override // com.android.inputmethod.latin.HardKeyboardSequenceHandler.KeyEventSequenceBase
        protected int getIntAt(int i) {
            return this.mSequence[i % this.mSequence.length];
        }

        public void setDeletedCharactersCountAtInput(int charactersToDelete) {
            this.mDeletedCharactersTillNow = charactersToDelete;
        }
    }

    public void addQwertyTranslation(String targetCharacters) {
        if (msQwerty.length != targetCharacters.length()) {
            throw new InvalidParameterException("'targetCharacters' should be the same lenght as the latin QWERTY keys strings: " + msQwerty);
        }
        for (int qwertyIndex = 0; qwertyIndex < msQwerty.length; qwertyIndex++) {
            char latinCharacter = (char) msQwerty[qwertyIndex];
            char otherCharacter = targetCharacters.charAt(qwertyIndex);
            if (otherCharacter > 0) {
                addSequence(new int[]{latinCharacter}, otherCharacter);
            }
        }
    }

    public void addSequence(int[] sequence, char result) {
        for (int sequenceLength = 1; sequenceLength < sequence.length; sequenceLength++) {
            int[] subSequence = new int[sequenceLength];
            for (int i = 0; i < sequenceLength; i++) {
                subSequence[i] = sequence[i];
            }
            KeyEventSequence keysSequence = new KeyEventSequence(subSequence, (char) 0);
            if (!this.mSequences.containsKey(keysSequence)) {
                this.mSequences.put(keysSequence, keysSequence);
            }
        }
        KeyEventSequence actualSequence = new KeyEventSequence(sequence, result);
        if (this.mSequences.containsKey(actualSequence)) {
            this.mSequences.remove(actualSequence);
        }
        this.mSequences.put(actualSequence, actualSequence);
    }

    public void addAltMapping(int keyEvent, char result) {
        if (this.mAltMapping.containsKey(Integer.valueOf(keyEvent))) {
            this.mAltMapping.remove(Integer.valueOf(keyEvent));
        }
        this.mAltMapping.put(Integer.valueOf(keyEvent), Character.valueOf(result));
    }

    public void addShiftMapping(int keyEvent, char result) {
        if (this.mShiftMapping.containsKey(Integer.valueOf(keyEvent))) {
            this.mShiftMapping.remove(Integer.valueOf(keyEvent));
        }
        this.mShiftMapping.put(Integer.valueOf(keyEvent), Character.valueOf(result));
    }

    public char getAltCharacter(int keyEvent) {
        this.mCurrentTypedSequence.reset();
        if (this.mAltMapping.containsKey(Integer.valueOf(keyEvent))) {
            return this.mAltMapping.get(Integer.valueOf(keyEvent)).charValue();
        }
        return (char) 0;
    }

    public char getShiftCharacter(int keyEvent) {
        this.mCurrentTypedSequence.reset();
        if (this.mShiftMapping.containsKey(Integer.valueOf(keyEvent))) {
            return this.mShiftMapping.get(Integer.valueOf(keyEvent)).charValue();
        }
        return (char) 0;
    }

    public char getSequenceCharacter(int currentKeyEvent, DictionaryEditor inputHandler) {
        long currentTime = System.currentTimeMillis();
        if (currentTime - this.mLastTypedKeyEventTime >= msSequenceLivingTime) {
            this.mCurrentTypedSequence.reset();
        }
        this.mLastTypedKeyEventTime = currentTime;
        this.mCurrentTypedSequence.appendKeyEvent(currentKeyEvent);
        if (this.mSequences.containsKey(this.mCurrentTypedSequence)) {
            KeyEventSequence mappedSequence = this.mSequences.get(this.mCurrentTypedSequence);
            char mappedChar = mappedSequence.getTarget();
            if (mappedChar == 0) {
                return (char) 0;
            }
            int charactersToDelete = mappedSequence.getSequenceLength() - 1;
            inputHandler.deleteLastCharactersFromInput(charactersToDelete - this.mCurrentTypedSequence.getDeletedCharactersCountTillNow());
            this.mCurrentTypedSequence.setDeletedCharactersCountAtInput(charactersToDelete);
            return mappedChar;
        }
        int lastSequenceLength = this.mCurrentTypedSequence.getSequenceLength();
        this.mCurrentTypedSequence.reset();
        if (lastSequenceLength > 1) {
            return getSequenceCharacter(currentKeyEvent, inputHandler);
        }
        return (char) 0;
    }
}
