package com.android.common.colorPicker;

import android.app.AlertDialog;
import android.content.Context;
import android.content.DialogInterface;
import android.content.res.XmlResourceParser;
import android.graphics.Color;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.MotionEvent;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AbsoluteLayout;
import android.widget.ImageView;
import inputmethod.latin.perfectkeyboard.R;
import org.xmlpull.v1.XmlPullParser;

/* loaded from: classes.dex */
public class AmbilWarnaDialog {
    private static final String TAG = AmbilWarnaDialog.class.getSimpleName();
    AlertDialog dialog;
    float hue;
    OnAmbilWarnaListener listener;
    ImageView panah;
    float sat;
    float satudp;
    float ukuranUiPx;
    float val;
    View viewHue;
    ImageView viewKeker;
    AmbilWarnaKotak viewKotak;
    View viewWarnaBaru;
    View viewWarnaLama;
    int warnaBaru;
    int warnaLama;
    float ukuranUiDp = 240.0f;
    float[] tmp01 = new float[3];

    /* loaded from: classes.dex */
    public interface OnAmbilWarnaListener {
        void onCancel(AmbilWarnaDialog ambilWarnaDialog);

        void onOk(AmbilWarnaDialog ambilWarnaDialog, int i);
    }

    public AmbilWarnaDialog(Context context, int color, OnAmbilWarnaListener listener) {
        this.listener = listener;
        this.warnaLama = color;
        this.warnaBaru = color;
        Color.colorToHSV(color, this.tmp01);
        this.hue = this.tmp01[0];
        this.sat = this.tmp01[1];
        this.val = this.tmp01[2];
        this.satudp = context.getResources().getDimension(R.dimen.ambilwarna_satudp);
        this.ukuranUiPx = this.ukuranUiDp * this.satudp;
        Log.d(TAG, "satudp = " + this.satudp + ", ukuranUiPx=" + this.ukuranUiPx);
        LayoutInflater inflater = (LayoutInflater) context.getSystemService("layout_inflater");
        XmlResourceParser parser = context.getResources().getLayout(R.layout.ambilwarna_dialog);
        View view = inflater.inflate((XmlPullParser) parser, (ViewGroup) null, false);
        this.viewHue = view.findViewById(R.id.ambilwarna_viewHue);
        this.viewKotak = (AmbilWarnaKotak) view.findViewById(R.id.ambilwarna_viewKotak);
        this.panah = (ImageView) view.findViewById(R.id.ambilwarna_panah);
        this.viewWarnaLama = view.findViewById(R.id.ambilwarna_warnaLama);
        this.viewWarnaBaru = view.findViewById(R.id.ambilwarna_warnaBaru);
        this.viewKeker = (ImageView) view.findViewById(R.id.ambilwarna_keker);
        letakkanPanah();
        letakkanKeker();
        this.viewKotak.setHue(this.hue);
        this.viewWarnaLama.setBackgroundColor(color);
        this.viewWarnaBaru.setBackgroundColor(color);
        this.viewHue.setOnTouchListener(new View.OnTouchListener() { // from class: com.android.common.colorPicker.AmbilWarnaDialog.1
            @Override // android.view.View.OnTouchListener
            public boolean onTouch(View v, MotionEvent event) {
                if (event.getAction() != 2 && event.getAction() != 0 && event.getAction() != 1) {
                    return false;
                }
                float y = event.getY();
                if (y < 0.0f) {
                    y = 0.0f;
                }
                if (y > AmbilWarnaDialog.this.ukuranUiPx) {
                    y = AmbilWarnaDialog.this.ukuranUiPx - 0.001f;
                }
                AmbilWarnaDialog.this.hue = 360.0f - ((360.0f / AmbilWarnaDialog.this.ukuranUiPx) * y);
                if (AmbilWarnaDialog.this.hue == 360.0f) {
                    AmbilWarnaDialog.this.hue = 0.0f;
                }
                AmbilWarnaDialog.this.warnaBaru = AmbilWarnaDialog.this.hitungWarna();
                AmbilWarnaDialog.this.viewKotak.setHue(AmbilWarnaDialog.this.hue);
                AmbilWarnaDialog.this.letakkanPanah();
                AmbilWarnaDialog.this.viewWarnaBaru.setBackgroundColor(AmbilWarnaDialog.this.warnaBaru);
                return true;
            }
        });
        this.viewKotak.setOnTouchListener(new View.OnTouchListener() { // from class: com.android.common.colorPicker.AmbilWarnaDialog.2
            @Override // android.view.View.OnTouchListener
            public boolean onTouch(View v, MotionEvent event) {
                if (event.getAction() != 2 && event.getAction() != 0 && event.getAction() != 1) {
                    return false;
                }
                float x = event.getX();
                float y = event.getY();
                if (x < 0.0f) {
                    x = 0.0f;
                }
                if (x > AmbilWarnaDialog.this.ukuranUiPx) {
                    x = AmbilWarnaDialog.this.ukuranUiPx;
                }
                if (y < 0.0f) {
                    y = 0.0f;
                }
                if (y > AmbilWarnaDialog.this.ukuranUiPx) {
                    y = AmbilWarnaDialog.this.ukuranUiPx;
                }
                AmbilWarnaDialog.this.sat = (1.0f / AmbilWarnaDialog.this.ukuranUiPx) * x;
                AmbilWarnaDialog.this.val = 1.0f - ((1.0f / AmbilWarnaDialog.this.ukuranUiPx) * y);
                AmbilWarnaDialog.this.warnaBaru = AmbilWarnaDialog.this.hitungWarna();
                AmbilWarnaDialog.this.letakkanKeker();
                AmbilWarnaDialog.this.viewWarnaBaru.setBackgroundColor(AmbilWarnaDialog.this.warnaBaru);
                return true;
            }
        });
        this.dialog = new AlertDialog.Builder(context).setView(view).setPositiveButton(R.string.ambilwarna_ok, new DialogInterface.OnClickListener() { // from class: com.android.common.colorPicker.AmbilWarnaDialog.3
            @Override // android.content.DialogInterface.OnClickListener
            public void onClick(DialogInterface dialog, int which) {
                if (AmbilWarnaDialog.this.listener != null) {
                    AmbilWarnaDialog.this.listener.onOk(AmbilWarnaDialog.this, AmbilWarnaDialog.this.warnaBaru);
                }
            }
        }).setNegativeButton(R.string.ambilwarna_cancel, new DialogInterface.OnClickListener() { // from class: com.android.common.colorPicker.AmbilWarnaDialog.4
            @Override // android.content.DialogInterface.OnClickListener
            public void onClick(DialogInterface dialog, int which) {
                if (AmbilWarnaDialog.this.listener != null) {
                    AmbilWarnaDialog.this.listener.onCancel(AmbilWarnaDialog.this);
                }
            }
        }).create();
    }

    protected void letakkanPanah() {
        float y = this.ukuranUiPx - ((this.hue * this.ukuranUiPx) / 360.0f);
        if (y == this.ukuranUiPx) {
            y = 0.0f;
        }
        AbsoluteLayout.LayoutParams layoutParams = (AbsoluteLayout.LayoutParams) this.panah.getLayoutParams();
        layoutParams.y = (int) (4.0f + y);
        this.panah.setLayoutParams(layoutParams);
    }

    protected void letakkanKeker() {
        float x = this.sat * this.ukuranUiPx;
        float y = (1.0f - this.val) * this.ukuranUiPx;
        AbsoluteLayout.LayoutParams layoutParams = (AbsoluteLayout.LayoutParams) this.viewKeker.getLayoutParams();
        layoutParams.x = (int) (x + 3.0f);
        layoutParams.y = (int) (y + 3.0f);
        this.viewKeker.setLayoutParams(layoutParams);
    }

    /* JADX INFO: Access modifiers changed from: private */
    public int hitungWarna() {
        this.tmp01[0] = this.hue;
        this.tmp01[1] = this.sat;
        this.tmp01[2] = this.val;
        return Color.HSVToColor(this.tmp01);
    }

    public void show() {
        this.dialog.show();
    }
}
