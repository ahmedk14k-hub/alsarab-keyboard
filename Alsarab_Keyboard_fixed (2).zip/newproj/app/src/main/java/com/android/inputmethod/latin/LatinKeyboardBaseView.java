package com.android.inputmethod.latin;

import android.R;
import android.content.Context;
import android.content.res.Resources;
import android.content.res.TypedArray;
import android.graphics.Bitmap;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.LightingColorFilter;
import android.graphics.Paint;
import android.graphics.PorterDuff;
import android.graphics.Rect;
import android.graphics.Region;
import android.graphics.Typeface;
import android.graphics.drawable.Drawable;
import android.inputmethodservice.Keyboard;
import android.os.Handler;
import android.os.Message;
import android.os.SystemClock;
import android.util.AttributeSet;
import android.util.Log;
import android.view.GestureDetector;
import android.view.LayoutInflater;
import android.view.MotionEvent;
import android.view.View;
import android.view.ViewGroup;
import android.widget.PopupWindow;
import android.widget.TextView;
import com.android.inputmethod.latin.PointerTracker;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Iterator;
import java.util.LinkedList;
import java.util.List;
import java.util.WeakHashMap;

/* loaded from: classes.dex */
public class LatinKeyboardBaseView extends View implements PointerTracker.UIProxy {
    private static final boolean DEBUG = false;
    static final int NOT_A_KEY = -1;
    public static final int NOT_A_TOUCH_COORDINATE = -1;
    private static final int NUMBER_HINT_VERTICAL_ADJUSTMENT_PIXEL = -1;
    private static final String TAG = "LatinKeyboardBaseView";
    private static int mColorButton;
    private static boolean mShowTouchPoints;
    public static int mSwipeThreshold;
    public static long mSwipeThresholdMul;
    public static int mTextSize;
    private final String KEY_LABEL_HEIGHT_REFERENCE_CHAR;
    private final float KEY_LABEL_VERTICAL_ADJUSTMENT_FACTOR;
    private float mBackgroundDimAmount;
    private Bitmap mBuffer;
    private Canvas mCanvas;
    private final Rect mClipRegion;
    private final int mDelayAfterPreview;
    private final int mDelayBeforePreview;
    private final Rect mDirtyRect;
    private final boolean mDisambiguateSwipe;
    private boolean mDrawPending;
    private GestureDetector mGestureDetector;
    private final UIHandler mHandler;
    private final boolean mHasDistinctMultitouch;
    private Keyboard.Key mInvalidatedKey;
    public Drawable mKeyBackground;
    protected KeyDetector mKeyDetector;
    private float mKeyHysteresisDistance;
    private final int mKeyRepeatInterval;
    private int mKeyTextColor;
    private int mKeyTextSize;
    private Typeface mKeyTextStyle;
    private Keyboard mKeyboard;
    private OnKeyboardActionListener mKeyboardActionListener;
    private boolean mKeyboardChanged;
    private int mKeyboardVerticalGap;
    private Keyboard.Key[] mKeys;
    private int mLabelTextSize;
    private int mLongPressDelay;
    private LatinKeyboardBaseView mMiniKeyboard;
    private final WeakHashMap<Keyboard.Key, View> mMiniKeyboardCache;
    private int mMiniKeyboardOriginX;
    private int mMiniKeyboardOriginY;
    private View mMiniKeyboardParent;
    private PopupWindow mMiniKeyboardPopup;
    private long mMiniKeyboardPopupTime;
    private final float mMiniKeyboardSlideAllowance;
    private int mMiniKeyboardTrackerId;
    private int[] mOffsetInWindow;
    private int mOldPointerCount;
    private int mOldPreviewKeyIndex;
    private final Rect mPadding;
    private final Paint mPaint;
    private final PointerQueue mPointerQueue;
    private final ArrayList<PointerTracker> mPointerTrackers;
    private int mPopupLayout;
    private int mPopupPreviewDisplayedY;
    private int mPopupPreviewOffsetX;
    private int mPopupPreviewOffsetY;
    private int mPreviewHeight;
    private int mPreviewOffset;
    private PopupWindow mPreviewPopup;
    private TextView mPreviewText;
    private int mPreviewTextSizeLarge;
    private int mShadowColor;
    private float mShadowRadius;
    private boolean mShowPreview;
    private final SwipeTracker mSwipeTracker;
    private final HashMap<Integer, Integer> mTextHeightCache;
    private float mVerticalCorrection;
    private int[] mWindowOffset;
    private int mWindowY;
    private static final int[] LONG_PRESSABLE_STATE_SET = {R.attr.state_long_pressable};
    static int mSymbolColorScheme = 0;
    public static String[] popularDomains = new String[6];
    public static String[] CustomSmileys = new String[44];
    public static String[] CustomPunctuationPopup = new String[14];

    /* loaded from: classes.dex */
    public interface OnKeyboardActionListener {
        void onCancel();

        void onKey(int i, int[] iArr, int i2, int i3);

        void onPress(int i);

        void onRelease(int i);

        void onText(CharSequence charSequence);

        void swipeDown();

        void swipeLeft();

        void swipeRight();

        void swipeUp();
    }

    /* JADX INFO: Access modifiers changed from: package-private */
    /* loaded from: classes.dex */
    public class UIHandler extends Handler {
        private static final int MSG_DISMISS_PREVIEW = 2;
        private static final int MSG_LONGPRESS_KEY = 4;
        private static final int MSG_POPUP_PREVIEW = 1;
        private static final int MSG_REPEAT_KEY = 3;
        private boolean mInKeyRepeat;

        UIHandler() {
        }

        @Override // android.os.Handler
        public void handleMessage(Message msg) {
            switch (msg.what) {
                case 1:
                    LatinKeyboardBaseView.this.showKey(msg.arg1, (PointerTracker) msg.obj);
                    return;
                case 2:
                    LatinKeyboardBaseView.this.mPreviewPopup.dismiss();
                    return;
                case 3:
                    PointerTracker tracker = (PointerTracker) msg.obj;
                    tracker.repeatKey(msg.arg1);
                    startKeyRepeatTimer(LatinKeyboardBaseView.this.mKeyRepeatInterval, msg.arg1, tracker);
                    return;
                case 4:
                    LatinKeyboardBaseView.this.openPopupIfRequired(msg.arg1, (PointerTracker) msg.obj);
                    return;
                default:
                    return;
            }
        }

        public void popupPreview(long delay, int keyIndex, PointerTracker tracker) {
            removeMessages(1);
            if (DictionaryEditor.mUseExternalSkin && DictionaryEditor.skinData != null && DictionaryEditor.skinData.keyboard_key_feedback != null) {
                LatinKeyboardBaseView.this.mPreviewText.setBackgroundDrawable(DictionaryEditor.skinData.keyboard_key_feedback);
            }
            if (!LatinKeyboardBaseView.this.mPreviewPopup.isShowing() || LatinKeyboardBaseView.this.mPreviewText.getVisibility() != 0) {
                sendMessageDelayed(obtainMessage(1, keyIndex, 0, tracker), delay);
            } else {
                LatinKeyboardBaseView.this.showKey(keyIndex, tracker);
            }
        }

        public void cancelPopupPreview() {
            removeMessages(1);
        }

        public void dismissPreview(long delay) {
            if (LatinKeyboardBaseView.this.mPreviewPopup.isShowing()) {
                sendMessageDelayed(obtainMessage(2), delay);
            }
        }

        public void cancelDismissPreview() {
            removeMessages(2);
        }

        public void startKeyRepeatTimer(long delay, int keyIndex, PointerTracker tracker) {
            this.mInKeyRepeat = true;
            sendMessageDelayed(obtainMessage(3, keyIndex, 0, tracker), delay);
        }

        public void cancelKeyRepeatTimer() {
            this.mInKeyRepeat = false;
            removeMessages(3);
        }

        public boolean isInKeyRepeat() {
            return this.mInKeyRepeat;
        }

        public void startLongPressTimer(long delay, int keyIndex, PointerTracker tracker) {
            removeMessages(4);
            sendMessageDelayed(obtainMessage(4, keyIndex, 0, tracker), delay);
        }

        public void cancelLongPressTimer() {
            removeMessages(4);
        }

        public void cancelKeyTimers() {
            cancelKeyRepeatTimer();
            cancelLongPressTimer();
        }

        public void cancelAllMessages() {
            cancelKeyTimers();
            cancelPopupPreview();
            cancelDismissPreview();
        }
    }

    /* JADX INFO: Access modifiers changed from: package-private */
    /* loaded from: classes.dex */
    public static class PointerQueue {
        private LinkedList<PointerTracker> mQueue = new LinkedList<>();

        PointerQueue() {
        }

        public void add(PointerTracker tracker) {
            this.mQueue.add(tracker);
        }

        public int lastIndexOf(PointerTracker tracker) {
            LinkedList<PointerTracker> queue = this.mQueue;
            for (int index = queue.size() - 1; index >= 0; index--) {
                PointerTracker t = queue.get(index);
                if (t == tracker) {
                    return index;
                }
            }
            return -1;
        }

        public void releaseAllPointersOlderThan(PointerTracker tracker, long eventTime) {
            LinkedList<PointerTracker> queue = this.mQueue;
            int oldestPos = 0;
            PointerTracker t = queue.get(0);
            while (t != tracker) {
                if (t.isModifier()) {
                    oldestPos++;
                } else {
                    t.onUpEvent(t.getLastX(), t.getLastY(), eventTime);
                    t.setAlreadyProcessed();
                    queue.remove(oldestPos);
                }
                PointerTracker t2 = queue.get(oldestPos);
                t = t2;
            }
        }

        public void releaseAllPointersExcept(PointerTracker tracker, long eventTime) {
            Iterator<PointerTracker> it = this.mQueue.iterator();
            while (it.hasNext()) {
                PointerTracker t = it.next();
                if (t != tracker) {
                    t.onUpEvent(t.getLastX(), t.getLastY(), eventTime);
                    t.setAlreadyProcessed();
                }
            }
            this.mQueue.clear();
            if (tracker != null) {
                this.mQueue.add(tracker);
            }
        }

        public void releaseAllPointersExceptDontSend(PointerTracker tracker, long eventTime) {
            Iterator<PointerTracker> it = this.mQueue.iterator();
            while (it.hasNext()) {
                PointerTracker t = it.next();
                if (t != tracker) {
                    t.setAlreadyProcessed();
                }
            }
            this.mQueue.clear();
            if (tracker != null) {
                this.mQueue.add(tracker);
            }
        }

        public void remove(PointerTracker tracker) {
            this.mQueue.remove(tracker);
        }

        public boolean isInSlidingKeyInput() {
            Iterator<PointerTracker> it = this.mQueue.iterator();
            while (it.hasNext()) {
                PointerTracker tracker = it.next();
                if (tracker.isInSlidingKeyInput()) {
                    return true;
                }
            }
            return false;
        }
    }

    public LatinKeyboardBaseView(Context context, AttributeSet attrs) {
        this(context, attrs, inputmethod.latin.perfectkeyboard.R.attr.keyboardViewStyle);
    }

    public LatinKeyboardBaseView(Context context, AttributeSet attrs, int defStyle) {
        super(context, attrs, defStyle);
        this.mKeyTextStyle = Typeface.DEFAULT;
        this.mOldPreviewKeyIndex = -1;
        this.mShowPreview = true;
        this.mMiniKeyboardCache = new WeakHashMap<>();
        this.mPointerTrackers = new ArrayList<>();
        this.mPointerQueue = new PointerQueue();
        this.mOldPointerCount = 1;
        this.mKeyDetector = new ProximityKeyDetector();
        this.mSwipeTracker = new SwipeTracker();
        this.mDirtyRect = new Rect();
        this.mClipRegion = new Rect(0, 0, 0, 0);
        this.mTextHeightCache = new HashMap<>();
        this.KEY_LABEL_VERTICAL_ADJUSTMENT_FACTOR = 0.55f;
        this.KEY_LABEL_HEIGHT_REFERENCE_CHAR = "H";
        this.mHandler = new UIHandler();
        TypedArray a = context.obtainStyledAttributes(attrs, inputmethod.latin.perfectkeyboard.R.styleable.LatinKeyboardBaseView, defStyle, inputmethod.latin.perfectkeyboard.R.style.LatinKeyboardBaseView);
        LayoutInflater inflate = (LayoutInflater) context.getSystemService("layout_inflater");
        int previewLayout = 0;
        int n = a.getIndexCount();
        for (int i = 0; i < n; i++) {
            int attr = a.getIndex(i);
            switch (attr) {
                case 1:
                    this.mKeyBackground = a.getDrawable(attr);
                    break;
                case 2:
                    this.mKeyTextSize = a.getDimensionPixelSize(attr, 18);
                    break;
                case 3:
                    this.mLabelTextSize = a.getDimensionPixelSize(attr, 14);
                    break;
                case 4:
                    this.mKeyTextColor = a.getColor(attr, -16777216);
                    break;
                case 5:
                    previewLayout = a.getResourceId(attr, 0);
                    break;
                case 6:
                    this.mPreviewOffset = a.getDimensionPixelOffset(attr, 0);
                    break;
                case 7:
                    this.mPreviewHeight = a.getDimensionPixelSize(attr, 80);
                    break;
                case 8:
                    this.mKeyHysteresisDistance = a.getDimensionPixelOffset(attr, 0);
                    break;
                case 9:
                    this.mVerticalCorrection = a.getDimensionPixelOffset(attr, 0);
                    break;
                case 10:
                    this.mPopupLayout = a.getResourceId(attr, 0);
                    break;
                case 11:
                    this.mShadowColor = a.getColor(attr, 0);
                    break;
                case 12:
                    this.mShadowRadius = a.getFloat(attr, 0.0f);
                    break;
                case 13:
                    this.mBackgroundDimAmount = a.getFloat(attr, 0.5f);
                    break;
                case 14:
                    int textStyle = a.getInt(attr, 0);
                    switch (textStyle) {
                        case 0:
                            this.mKeyTextStyle = Typeface.DEFAULT;
                            break;
                        case 1:
                            this.mKeyTextStyle = Typeface.DEFAULT_BOLD;
                            break;
                        default:
                            this.mKeyTextStyle = Typeface.defaultFromStyle(textStyle);
                            break;
                    }
            }
        }
        Resources res = getResources();
        this.mPreviewPopup = new PopupWindow(context);
        if (previewLayout != 0) {
            this.mPreviewText = (TextView) inflate.inflate(previewLayout, (ViewGroup) null);
            this.mPreviewTextSizeLarge = (int) res.getDimension(inputmethod.latin.perfectkeyboard.R.dimen.key_preview_text_size_large);
            this.mPreviewPopup.setContentView(this.mPreviewText);
            this.mPreviewPopup.setBackgroundDrawable(null);
        } else {
            this.mShowPreview = false;
        }
        this.mPreviewPopup.setTouchable(false);
        this.mPreviewPopup.setAnimationStyle(inputmethod.latin.perfectkeyboard.R.style.KeyPreviewAnimation);
        this.mDelayBeforePreview = res.getInteger(inputmethod.latin.perfectkeyboard.R.integer.config_delay_before_preview);
        this.mDelayAfterPreview = res.getInteger(inputmethod.latin.perfectkeyboard.R.integer.config_delay_after_preview);
        this.mMiniKeyboardParent = this;
        this.mMiniKeyboardPopup = new PopupWindow(context);
        this.mMiniKeyboardPopup.setBackgroundDrawable(null);
        this.mMiniKeyboardPopup.setAnimationStyle(inputmethod.latin.perfectkeyboard.R.style.MiniKeyboardAnimation);
        this.mPaint = new Paint();
        this.mPaint.setAntiAlias(true);
        this.mPaint.setTextSize(0);
        this.mPaint.setTextAlign(Paint.Align.CENTER);
        this.mPaint.setAlpha(255);
        this.mPadding = new Rect(0, 0, 0, 0);
        this.mKeyBackground.getPadding(this.mPadding);
        mSwipeThreshold = (int) (500.0f * res.getDisplayMetrics().density);
        this.mDisambiguateSwipe = res.getBoolean(inputmethod.latin.perfectkeyboard.R.bool.config_swipeDisambiguation);
        this.mMiniKeyboardSlideAllowance = res.getDimension(inputmethod.latin.perfectkeyboard.R.dimen.mini_keyboard_slide_allowance);
        GestureDetector.SimpleOnGestureListener listener = new GestureDetector.SimpleOnGestureListener() { // from class: com.android.inputmethod.latin.LatinKeyboardBaseView.1
            @Override // android.view.GestureDetector.SimpleOnGestureListener, android.view.GestureDetector.OnGestureListener
            public boolean onFling(MotionEvent me1, MotionEvent me2, float velocityX, float velocityY) {
                float absX = Math.abs(velocityX);
                float absY = Math.abs(velocityY);
                float deltaX = me2.getX() - me1.getX();
                float deltaY = me2.getY() - me1.getY();
                long travelX = (long) ((LatinKeyboardBaseView.this.getWidth() * LatinKeyboardBaseView.mSwipeThresholdMul) / 100.0d);
                long travelY = (long) ((LatinKeyboardBaseView.this.getHeight() * LatinKeyboardBaseView.mSwipeThresholdMul) / 100.0d);
                LatinKeyboardBaseView.this.mSwipeTracker.computeCurrentVelocity(1000);
                float endingVelocityX = LatinKeyboardBaseView.this.mSwipeTracker.getXVelocity();
                float endingVelocityY = LatinKeyboardBaseView.this.mSwipeTracker.getYVelocity();
                if (velocityX <= LatinKeyboardBaseView.mSwipeThreshold || absY >= absX || deltaX <= ((float) travelX)) {
                    if (velocityX >= (-LatinKeyboardBaseView.mSwipeThreshold) || absY >= absX || deltaX >= ((float) (-travelX))) {
                        if (velocityY >= (-LatinKeyboardBaseView.mSwipeThreshold) || absX >= absY || deltaY >= ((float) (-travelY))) {
                            if (velocityY > LatinKeyboardBaseView.mSwipeThreshold && absX < absY / 2.0f && deltaY > ((float) travelY) && LatinKeyboardBaseView.this.mDisambiguateSwipe && endingVelocityY >= velocityY / 4.0f) {
                                LatinKeyboardBaseView.this.swipeDown();
                                return true;
                            }
                        } else if (LatinKeyboardBaseView.this.mDisambiguateSwipe && endingVelocityY <= velocityY / 4.0f) {
                            LatinKeyboardBaseView.this.swipeUp();
                            return true;
                        }
                    } else if (LatinKeyboardBaseView.this.mDisambiguateSwipe && endingVelocityX <= velocityX / 4.0f) {
                        LatinKeyboardBaseView.this.swipeLeft();
                        return true;
                    }
                } else if (LatinKeyboardBaseView.this.mDisambiguateSwipe && endingVelocityX >= velocityX / 4.0f) {
                    LatinKeyboardBaseView.this.swipeRight();
                    return true;
                }
                return false;
            }
        };
        this.mGestureDetector = new GestureDetector(getContext(), listener, null, true);
        this.mGestureDetector.setIsLongpressEnabled(false);
        this.mHasDistinctMultitouch = context.getPackageManager().hasSystemFeature("android.hardware.touchscreen.multitouch.distinct");
        this.mKeyRepeatInterval = res.getInteger(inputmethod.latin.perfectkeyboard.R.integer.config_key_repeat_interval);
    }

    public void setOnKeyboardActionListener(OnKeyboardActionListener listener) {
        this.mKeyboardActionListener = listener;
        Iterator<PointerTracker> it = this.mPointerTrackers.iterator();
        while (it.hasNext()) {
            PointerTracker tracker = it.next();
            tracker.setOnKeyboardActionListener(listener);
        }
    }

    /* JADX INFO: Access modifiers changed from: protected */
    public OnKeyboardActionListener getOnKeyboardActionListener() {
        return this.mKeyboardActionListener;
    }

    public void setKeyboard(Keyboard keyboard) {
        if (this.mKeyboard != null) {
            dismissKeyPreview();
        }
        this.mHandler.cancelKeyTimers();
        this.mHandler.cancelPopupPreview();
        this.mKeyboard = keyboard;
        LatinImeLogger.onSetKeyboard(keyboard);
        this.mKeys = this.mKeyDetector.setKeyboard(keyboard, -getPaddingLeft(), (-getPaddingTop()) + this.mVerticalCorrection);
        this.mKeyboardVerticalGap = (int) getResources().getDimension(inputmethod.latin.perfectkeyboard.R.dimen.key_bottom_gap);
        Iterator<PointerTracker> it = this.mPointerTrackers.iterator();
        while (it.hasNext()) {
            PointerTracker tracker = it.next();
            tracker.setKeyboard(this.mKeys, this.mKeyHysteresisDistance);
        }
        requestLayout();
        this.mKeyboardChanged = true;
        invalidateAllKeys();
        computeProximityThreshold(keyboard);
        this.mMiniKeyboardCache.clear();
    }

    public Keyboard getKeyboard() {
        return this.mKeyboard;
    }

    @Override // com.android.inputmethod.latin.PointerTracker.UIProxy
    public boolean hasDistinctMultitouch() {
        return this.mHasDistinctMultitouch;
    }

    public boolean setShifted(boolean shifted) {
        if (this.mKeyboard == null || !this.mKeyboard.setShifted(shifted)) {
            return false;
        }
        invalidateAllKeys();
        return true;
    }

    public boolean isShifted() {
        if (this.mKeyboard != null) {
            return this.mKeyboard.isShifted();
        }
        return false;
    }

    public void setPreviewEnabled(boolean previewEnabled) {
        this.mShowPreview = previewEnabled;
    }

    public boolean isPreviewEnabled() {
        return this.mShowPreview;
    }

    public void setLongPressDelay(int longPressDelay) {
        this.mLongPressDelay = longPressDelay;
        Iterator<PointerTracker> it = this.mPointerTrackers.iterator();
        while (it.hasNext()) {
            PointerTracker tracker = it.next();
            tracker.setLongPressKeyTimeout(this.mLongPressDelay);
        }
    }

    public int getSymbolColorScheme() {
        return mSymbolColorScheme;
    }

    public static void setSymbolColorScheme(int SymbolColorScheme) {
        mSymbolColorScheme = SymbolColorScheme;
    }

    public void setPopupParent(View v) {
        this.mMiniKeyboardParent = v;
    }

    public void setPopupOffset(int x, int y) {
        this.mPopupPreviewOffsetX = x;
        this.mPopupPreviewOffsetY = y;
        this.mPreviewPopup.dismiss();
    }

    public void setProximityCorrectionEnabled(boolean enabled) {
        this.mKeyDetector.setProximityCorrectionEnabled(enabled);
    }

    public boolean isProximityCorrectionEnabled() {
        return this.mKeyDetector.isProximityCorrectionEnabled();
    }

    protected CharSequence adjustCase(CharSequence label) {
        if (this.mKeyboard.isShifted() && label != null && label.length() < 3 && Character.isLowerCase(label.charAt(0))) {
            return label.toString().toUpperCase();
        }
        return label;
    }

    @Override // android.view.View
    public void onMeasure(int widthMeasureSpec, int heightMeasureSpec) {
        if (this.mKeyboard == null) {
            setMeasuredDimension(getPaddingLeft() + getPaddingRight(), getPaddingTop() + getPaddingBottom());
            return;
        }
        int width = this.mKeyboard.getMinWidth() + getPaddingLeft() + getPaddingRight();
        if (View.MeasureSpec.getSize(widthMeasureSpec) < width + 10) {
            width = View.MeasureSpec.getSize(widthMeasureSpec);
        }
        setMeasuredDimension(width, this.mKeyboard.getHeight() + getPaddingTop() + getPaddingBottom());
    }

    private void computeProximityThreshold(Keyboard keyboard) {
        Keyboard.Key[] keys;
        if (keyboard != null && (keys = this.mKeys) != null) {
            int length = keys.length;
            int dimensionSum = 0;
            for (Keyboard.Key key : keys) {
                dimensionSum += Math.min(key.width, key.height + this.mKeyboardVerticalGap) + key.gap;
            }
            if (dimensionSum >= 0 && length != 0) {
                this.mKeyDetector.setProximityThreshold((int) ((dimensionSum * 1.4f) / length));
            }
        }
    }

    @Override // android.view.View
    public void onSizeChanged(int w, int h, int oldw, int oldh) {
        super.onSizeChanged(w, h, oldw, oldh);
        this.mBuffer = null;
    }

    @Override // android.view.View
    public void onDraw(Canvas canvas) {
        super.onDraw(canvas);
        if (this.mDrawPending || this.mBuffer == null || this.mKeyboardChanged || this.mBuffer.isRecycled()) {
            onBufferDraw();
        }
        canvas.drawBitmap(this.mBuffer, 0.0f, 0.0f, (Paint) null);
    }

    private void onBufferDraw() {
        int drawableWidth;
        int drawableHeight;
        int drawableX;
        int drawableY;
        int labelSize;
        int labelHeight;
        String symbol;
        int modedColor = 0;
        boolean toMultiple = false;
        getResources();
        int mFontColor = DictionaryEditor.mUseCustomBackgrounColors ? Calibration.mFontSymbolColors : this.mKeyTextColor;
        if (this.mBuffer == null || this.mKeyboardChanged) {
            if (this.mBuffer == null || (this.mKeyboardChanged && (this.mBuffer.getWidth() != getWidth() || this.mBuffer.getHeight() != getHeight()))) {
                if (this.mBuffer != null) {
                    this.mBuffer.recycle();
                }
                int width = Math.max(1, getWidth());
                int height = Math.max(1, getHeight());
                this.mBuffer = Bitmap.createBitmap(width, height, Bitmap.Config.ARGB_8888);
                this.mCanvas = new Canvas(this.mBuffer);
            }
            invalidateAllKeys();
            this.mKeyboardChanged = false;
        }
        Canvas canvas = this.mCanvas;
        canvas.clipRect(this.mDirtyRect, Region.Op.REPLACE);
        if (this.mKeyboard != null) {
            Paint paint = this.mPaint;
            Drawable keyBackground = this.mKeyBackground;
            Rect clipRegion = this.mClipRegion;
            Rect padding = this.mPadding;
            int kbdPaddingLeft = getPaddingLeft();
            int kbdPaddingTop = getPaddingTop();
            Keyboard.Key[] keys = this.mKeys;
            Keyboard.Key invalidKey = this.mInvalidatedKey;
            int ShadowColor = this.mShadowColor;
            if (keys.length >= 16) {
                paint.setColor(mFontColor);
                ShadowColor = Calibration.mFontSymbolColors == -1 ? this.mShadowColor : 0;
            } else {
                paint.setColor(this.mKeyTextColor);
            }
            boolean drawSingleKey = false;
            if (invalidKey != null && canvas.getClipBounds(clipRegion) && (invalidKey.x + kbdPaddingLeft) - 1 <= clipRegion.left && (invalidKey.y + kbdPaddingTop) - 1 <= clipRegion.top && invalidKey.x + invalidKey.width + kbdPaddingLeft + 1 >= clipRegion.right && invalidKey.y + invalidKey.height + kbdPaddingTop + 1 >= clipRegion.bottom) {
                drawSingleKey = true;
            }
            canvas.drawColor(0, PorterDuff.Mode.CLEAR);
            for (Keyboard.Key key : keys) {
                if (!drawSingleKey || invalidKey == key) {
                    String label = key.label == null ? null : adjustCase(key.label).toString();
                    if (keys.length >= 16) {
                        if (DictionaryEditor.mUseExternalSkin && DictionaryEditor.skinData != null) {
                            if (key.modifier && key.codes[0] != 32 && key.codes[0] != -13) {
                                if (DictionaryEditor.skinData.btn_keyboard_key_alt != null) {
                                    keyBackground = DictionaryEditor.skinData.btn_keyboard_key_alt;
                                    if (getSymbolColorScheme() != 1) {
                                        paint.setColor(-1);
                                    }
                                }
                            } else {
                                if (DictionaryEditor.skinData.btn_keyboard_key != null) {
                                    keyBackground = DictionaryEditor.skinData.btn_keyboard_key;
                                }
                                if (DictionaryEditor.skinData.text_color != -1 && !DictionaryEditor.mUseCustomBackgrounColors) {
                                    paint.setColor(DictionaryEditor.skinData.text_color);
                                }
                            }
                        } else if (key.codes[0] != 32 && key.codes[0] != -13 && !DictionaryEditor.mUseCustomBackgrounColors && key.modifier) {
                            paint.setColor(-1);
                        } else {
                            paint.setColor(mFontColor);
                        }
                    }
                    int[] drawableState = key.getCurrentDrawableState();
                    keyBackground.setState(drawableState);
                    if (keys.length < 16) {
                        keyBackground.setColorFilter(CandidateView.getColor(), PorterDuff.Mode.MULTIPLY);
                    }
                    if (DictionaryEditor.mUseCustomBackgrounColors) {
                        if (keys.length >= 16) {
                            if (0 == 0) {
                                int baseColor = getColor();
                                int R = Color.red(baseColor);
                                int G = Color.green(baseColor);
                                int B = Color.blue(baseColor);
                                float[] hsv = new float[3];
                                Color.RGBToHSV(R, G, B, hsv);
                                hsv[2] = 1.0f - hsv[2];
                                if (hsv[2] < 0.5d) {
                                    hsv[2] = hsv[2] * 2.0f;
                                    hsv[2] = 1.0f - hsv[2];
                                    modedColor = Color.HSVToColor(hsv);
                                } else {
                                    toMultiple = true;
                                    hsv[2] = (float) (hsv[2] - 0.5d);
                                    hsv[2] = hsv[2] * 2.0f;
                                    hsv[2] = 1.0f - hsv[2];
                                    modedColor = Color.HSVToColor(hsv);
                                }
                            }
                            if (toMultiple) {
                                keyBackground.setColorFilter(modedColor, PorterDuff.Mode.MULTIPLY);
                            } else {
                                LightingColorFilter lcf = new LightingColorFilter(-1, modedColor);
                                keyBackground.setColorFilter(lcf);
                            }
                        }
                    } else if (keys.length >= 16) {
                        keyBackground.clearColorFilter();
                    }
                    Rect bounds = keyBackground.getBounds();
                    if (key.width != bounds.right || key.height != bounds.bottom) {
                        keyBackground.setBounds(0, 0, key.width, key.height);
                    }
                    canvas.translate(key.x + kbdPaddingLeft, key.y + kbdPaddingTop);
                    keyBackground.draw(canvas);
                    boolean shouldDrawIcon = true;
                    if (label != null) {
                        if (label.length() > 1 && key.codes.length < 2) {
                            labelSize = this.mLabelTextSize;
                            paint.setTypeface(Typeface.DEFAULT);
                        } else {
                            if (Calibration.mSmallLabelText) {
                                labelSize = (((this.mKeyTextSize * mTextSize) / 100) * 80) / 100;
                            } else {
                                labelSize = (this.mKeyTextSize * mTextSize) / 100;
                            }
                            paint.setTypeface(this.mKeyTextStyle);
                        }
                        paint.setTextSize(labelSize);
                        Integer labelHeightValue = this.mTextHeightCache.get(Integer.valueOf(labelSize));
                        if (labelHeightValue != null) {
                            labelHeight = labelHeightValue.intValue();
                        } else {
                            Rect textBounds = new Rect();
                            paint.getTextBounds("H", 0, 1, textBounds);
                            labelHeight = textBounds.height();
                            this.mTextHeightCache.put(Integer.valueOf(labelSize), Integer.valueOf(labelHeight));
                        }
                        int centerX = ((key.width + padding.left) - padding.right) / 2;
                        int centerY = ((key.height + padding.top) - padding.bottom) / 2;
                        float baseline = centerY + (labelHeight * 0.55f);
                        if (Calibration.mDisplayAltLables && (label.equals(".") || (key.popupCharacters != null && key.popupCharacters.length() != 0))) {
                            paint.setTextSize((this.mKeyTextSize * mTextSize) / 200);
                            Typeface typefece = paint.getTypeface();
                            paint.setTypeface(Typeface.DEFAULT_BOLD);
                            paint.setShadowLayer(0.0f, 0.0f, 0.0f, 0);
                            int color = paint.getColor();
                            if (label.equals(".")) {
                                symbol = ",";
                                paint.setShadowLayer(0.0f, 0.0f, 0.0f, 0);
                                paint.setColor(-2130706433);
                            } else {
                                if (key.popupCharacters.length() > 1 && (this.mKeyboard.getMinWidth() - 10) / 2 > key.x) {
                                    symbol = key.popupCharacters.subSequence(0, 1).toString();
                                } else {
                                    int size = key.popupCharacters.length();
                                    symbol = key.popupCharacters.subSequence(size - 1, size).toString();
                                }
                                paint.setShadowLayer(0.0f, 0.0f, 0.0f, 0);
                                if (DictionaryEditor.mUseCustomBackgrounColors) {
                                    paint.setColor((-2130706433) & LatinKeyboard.mHintColor);
                                } else {
                                    paint.setColor((-2130706433) & mFontColor);
                                }
                            }
                            if (DictionaryEditor.mUseExternalSkin && DictionaryEditor.skinData != null) {
                                paint.setColor(DictionaryEditor.skinData.text_color2);
                                paint.setShadowLayer(this.mShadowRadius / 2.0f, 0.0f, 0.0f, DictionaryEditor.skinData.shadow_color2);
                            }
                            canvas.drawText(symbol, (centerX * 3) / 2, baseline / 2.0f, paint);
                            paint.setTypeface(typefece);
                            paint.setTextSize(labelSize);
                            paint.setColor(color);
                        }
                        paint.setShadowLayer(this.mShadowRadius, 0.0f, 0.0f, ShadowColor);
                        if (DictionaryEditor.mUseExternalSkin && keys.length >= 16 && DictionaryEditor.skinData != null) {
                            if (!key.modifier) {
                                paint.setShadowLayer(this.mShadowRadius, 0.0f, 0.0f, DictionaryEditor.skinData.shadow_color);
                            } else {
                                paint.setShadowLayer(this.mShadowRadius, 0.0f, 0.0f, -16777216);
                            }
                        }
                        canvas.drawText(label, centerX, baseline, paint);
                        paint.setShadowLayer(0.0f, 0.0f, 0.0f, 0);
                        shouldDrawIcon = shouldDrawLabelAndIcon(key);
                    }
                    if (key.icon != null && shouldDrawIcon) {
                        if (shouldDrawIconFully(key)) {
                            drawableWidth = key.width;
                            drawableHeight = key.height;
                            drawableX = 0;
                            drawableY = -1;
                        } else {
                            drawableWidth = key.icon.getIntrinsicWidth();
                            drawableHeight = key.icon.getIntrinsicHeight();
                            drawableX = (((key.width + padding.left) - padding.right) - drawableWidth) / 2;
                            drawableY = (((key.height + padding.top) - padding.bottom) - drawableHeight) / 2;
                        }
                        canvas.translate(drawableX, drawableY);
                        key.icon.setBounds(0, 0, drawableWidth, drawableHeight);
                        key.icon.draw(canvas);
                        canvas.translate(-drawableX, -drawableY);
                    }
                    canvas.translate((-key.x) - kbdPaddingLeft, (-key.y) - kbdPaddingTop);
                }
            }
            this.mInvalidatedKey = null;
            if (this.mMiniKeyboard != null) {
                paint.setColor(((int) (this.mBackgroundDimAmount * 255.0f)) << 24);
                canvas.drawRect(0.0f, 0.0f, getWidth(), getHeight(), paint);
            }
            if (mShowTouchPoints) {
                Iterator<PointerTracker> it = this.mPointerTrackers.iterator();
                while (it.hasNext()) {
                    PointerTracker tracker = it.next();
                    int startX = tracker.getStartX();
                    int startY = tracker.getStartY();
                    int lastX = tracker.getLastX();
                    int lastY = tracker.getLastY();
                    paint.setAlpha(128);
                    paint.setColor(-65536);
                    canvas.drawCircle(startX, startY, 3.0f, paint);
                    canvas.drawLine(startX, startY, lastX, lastY, paint);
                    paint.setColor(-16776961);
                    canvas.drawCircle(lastX, lastY, 3.0f, paint);
                    paint.setColor(-16711936);
                    canvas.drawCircle((startX + lastX) / 2, (startY + lastY) / 2, 2.0f, paint);
                }
            }
            this.mDrawPending = false;
            this.mDirtyRect.setEmpty();
        }
    }

    private void dismissKeyPreview() {
        Iterator<PointerTracker> it = this.mPointerTrackers.iterator();
        while (it.hasNext()) {
            PointerTracker tracker = it.next();
            tracker.updateKey(-1);
        }
        showPreview(-1, null);
    }

    @Override // com.android.inputmethod.latin.PointerTracker.UIProxy
    public void showPreview(int keyIndex, PointerTracker tracker) {
        int oldKeyIndex = this.mOldPreviewKeyIndex;
        this.mOldPreviewKeyIndex = keyIndex;
        boolean isLanguageSwitchEnabled = (this.mKeyboard instanceof LatinKeyboard) && ((LatinKeyboard) this.mKeyboard).isLanguageSwitchEnabled();
        boolean hidePreviewOrShowSpaceKeyPreview = tracker == null || tracker.isSpaceKey(keyIndex) || tracker.isSpaceKey(oldKeyIndex);
        boolean ShowSpaceKeyPreview = !DictionaryEditor.mNoPopupOnSpace && tracker != null && tracker.isSpaceKey(keyIndex) && tracker.isSpaceKey(oldKeyIndex);
        if (oldKeyIndex != keyIndex || ShowSpaceKeyPreview) {
            if (this.mShowPreview || (hidePreviewOrShowSpaceKeyPreview && isLanguageSwitchEnabled)) {
                if (keyIndex == -1) {
                    this.mHandler.cancelPopupPreview();
                    this.mHandler.dismissPreview(this.mDelayAfterPreview);
                } else if (tracker != null) {
                    if (ShowSpaceKeyPreview || (this.mShowPreview && !tracker.isSpaceKey(keyIndex))) {
                        this.mHandler.popupPreview(this.mDelayBeforePreview, keyIndex, tracker);
                    }
                }
            }
        }
    }

    /* JADX INFO: Access modifiers changed from: private */
    public void showKey(int keyIndex, PointerTracker tracker) {
        Keyboard.Key key = tracker.getKey(keyIndex);
        if (key != null) {
            if (key.icon != null && (!shouldDrawLabelAndIcon(key) || key.text == "enter")) {
                this.mPreviewText.setCompoundDrawables(null, null, null, key.iconPreview != null ? key.iconPreview : key.icon);
                this.mPreviewText.setText((CharSequence) null);
            } else {
                this.mPreviewText.setCompoundDrawables(null, null, null, null);
                this.mPreviewText.setText(adjustCase(tracker.getPreviewText(key)));
                if (key.label != null && key.label.length() > 1 && key.codes != null && key.codes.length < 2) {
                    this.mPreviewText.setTextSize(0, this.mKeyTextSize);
                    this.mPreviewText.setTypeface(Typeface.DEFAULT_BOLD);
                } else {
                    this.mPreviewText.setTextSize(0, this.mPreviewTextSizeLarge);
                    this.mPreviewText.setTypeface(this.mKeyTextStyle);
                }
            }
            this.mPreviewText.measure(View.MeasureSpec.makeMeasureSpec(0, 0), View.MeasureSpec.makeMeasureSpec(0, 0));
            int popupWidth = Math.max(this.mPreviewText.getMeasuredWidth(), key.width + this.mPreviewText.getPaddingLeft() + this.mPreviewText.getPaddingRight());
            int popupHeight = this.mPreviewHeight;
            ViewGroup.LayoutParams lp = this.mPreviewText.getLayoutParams();
            if (lp != null) {
                lp.width = popupWidth;
                lp.height = popupHeight;
            }
            int popupPreviewX = key.x - ((popupWidth - key.width) / 2);
            int popupPreviewY = (key.y - popupHeight) + this.mPreviewOffset;
            this.mHandler.cancelDismissPreview();
            if (this.mOffsetInWindow == null) {
                this.mOffsetInWindow = new int[2];
                getLocationInWindow(this.mOffsetInWindow);
                int[] iArr = this.mOffsetInWindow;
                iArr[0] = iArr[0] + this.mPopupPreviewOffsetX;
                int[] iArr2 = this.mOffsetInWindow;
                iArr2[1] = iArr2[1] + this.mPopupPreviewOffsetY;
                int[] windowLocation = new int[2];
                getLocationOnScreen(windowLocation);
                this.mWindowY = windowLocation[1];
            }
            this.mPreviewText.getBackground().setState(key.popupResId != 0 ? LONG_PRESSABLE_STATE_SET : EMPTY_STATE_SET);
            int popupPreviewX2 = popupPreviewX + this.mOffsetInWindow[0];
            int popupPreviewY2 = popupPreviewY + this.mOffsetInWindow[1];
            if (this.mWindowY + popupPreviewY2 < 0) {
                if (key.x + key.width <= getWidth() / 2) {
                    popupPreviewX2 += (int) (key.width * 2.5d);
                } else {
                    popupPreviewX2 -= (int) (key.width * 2.5d);
                }
                popupPreviewY2 += popupHeight;
            }
            if (this.mPreviewPopup.isShowing()) {
                this.mPreviewPopup.update(popupPreviewX2, popupPreviewY2, popupWidth, popupHeight);
            } else {
                this.mPreviewPopup.setWidth(popupWidth);
                this.mPreviewPopup.setHeight(popupHeight);
                this.mPreviewPopup.showAtLocation(this.mMiniKeyboardParent, 0, popupPreviewX2, popupPreviewY2);
            }
            this.mPopupPreviewDisplayedY = popupPreviewY2;
            this.mPreviewText.setVisibility(0);
        }
    }

    public void invalidateAllKeys() {
        this.mDirtyRect.union(0, 0, getWidth(), getHeight());
        this.mDrawPending = true;
        invalidate();
    }

    @Override // com.android.inputmethod.latin.PointerTracker.UIProxy
    public void invalidateKey(Keyboard.Key key) {
        if (key != null) {
            this.mInvalidatedKey = key;
            this.mDirtyRect.union(key.x + getPaddingLeft(), key.y + getPaddingTop(), key.x + key.width + getPaddingLeft(), key.y + key.height + getPaddingTop());
            onBufferDraw();
            invalidate(key.x + getPaddingLeft(), key.y + getPaddingTop(), key.x + key.width + getPaddingLeft(), key.y + key.height + getPaddingTop());
        }
    }

    /* JADX INFO: Access modifiers changed from: private */
    public boolean openPopupIfRequired(int keyIndex, PointerTracker tracker) {
        Keyboard.Key popupKey;
        boolean result = false;
        if (this.mPopupLayout != 0 && (popupKey = tracker.getKey(keyIndex)) != null && (result = onLongPress(popupKey))) {
            dismissKeyPreview();
            this.mMiniKeyboardTrackerId = tracker.mPointerId;
            tracker.setAlreadyProcessed();
            this.mPointerQueue.remove(tracker);
        }
        return result;
    }

    private View inflateMiniKeyboardContainer(Keyboard.Key popupKey) {
        Keyboard keyboard;
        int popupKeyboardId = popupKey.popupResId;
        LayoutInflater inflater = (LayoutInflater) getContext().getSystemService("layout_inflater");
        View container = inflater.inflate(this.mPopupLayout, (ViewGroup) null);
        if (container == null) {
            throw new NullPointerException();
        }
        LatinKeyboardBaseView miniKeyboard = (LatinKeyboardBaseView) container.findViewById(inputmethod.latin.perfectkeyboard.R.id.LatinKeyboardBaseView);
        Drawable highlight = container.getBackground();
        highlight.setColorFilter(CandidateView.getColor(), PorterDuff.Mode.MULTIPLY);
        miniKeyboard.setOnKeyboardActionListener(new OnKeyboardActionListener() { // from class: com.android.inputmethod.latin.LatinKeyboardBaseView.2
            @Override // com.android.inputmethod.latin.LatinKeyboardBaseView.OnKeyboardActionListener
            public void onKey(int primaryCode, int[] keyCodes, int x, int y) {
                LatinKeyboardBaseView.this.mKeyboardActionListener.onKey(primaryCode, keyCodes, x, y);
                LatinKeyboardBaseView.this.dismissPopupKeyboard();
            }

            @Override // com.android.inputmethod.latin.LatinKeyboardBaseView.OnKeyboardActionListener
            public void onText(CharSequence text) {
                LatinKeyboardBaseView.this.mKeyboardActionListener.onText(text);
                LatinKeyboardBaseView.this.dismissPopupKeyboard();
            }

            @Override // com.android.inputmethod.latin.LatinKeyboardBaseView.OnKeyboardActionListener
            public void onCancel() {
                LatinKeyboardBaseView.this.mKeyboardActionListener.onCancel();
                LatinKeyboardBaseView.this.dismissPopupKeyboard();
            }

            @Override // com.android.inputmethod.latin.LatinKeyboardBaseView.OnKeyboardActionListener
            public void swipeLeft() {
            }

            @Override // com.android.inputmethod.latin.LatinKeyboardBaseView.OnKeyboardActionListener
            public void swipeRight() {
            }

            @Override // com.android.inputmethod.latin.LatinKeyboardBaseView.OnKeyboardActionListener
            public void swipeUp() {
            }

            @Override // com.android.inputmethod.latin.LatinKeyboardBaseView.OnKeyboardActionListener
            public void swipeDown() {
            }

            @Override // com.android.inputmethod.latin.LatinKeyboardBaseView.OnKeyboardActionListener
            public void onPress(int primaryCode) {
                LatinKeyboardBaseView.this.mKeyboardActionListener.onPress(primaryCode);
            }

            @Override // com.android.inputmethod.latin.LatinKeyboardBaseView.OnKeyboardActionListener
            public void onRelease(int primaryCode) {
                LatinKeyboardBaseView.this.mKeyboardActionListener.onRelease(primaryCode);
            }
        });
        miniKeyboard.mKeyDetector = new MiniKeyboardKeyDetector(this.mMiniKeyboardSlideAllowance);
        miniKeyboard.mGestureDetector = null;
        if (popupKey.popupCharacters != null) {
            keyboard = new Keyboard(getContext(), popupKeyboardId, popupKey.popupCharacters, -1, getPaddingLeft() + getPaddingRight());
        } else {
            keyboard = new Keyboard(getContext(), popupKeyboardId);
        }
        miniKeyboard.setKeyboard(keyboard);
        miniKeyboard.setPopupParent(this);
        container.measure(View.MeasureSpec.makeMeasureSpec(getWidth(), Integer.MIN_VALUE), View.MeasureSpec.makeMeasureSpec(getHeight(), Integer.MIN_VALUE));
        return container;
    }

    private static boolean isOneRowKeys(List<Keyboard.Key> keys) {
        if (keys.size() == 0) {
            return false;
        }
        int edgeFlags = keys.get(0).edgeFlags;
        return ((edgeFlags & 4) == 0 || (edgeFlags & 8) == 0) ? false : true;
    }

    /* JADX INFO: Access modifiers changed from: protected */
    public boolean onLongPress(Keyboard.Key popupKey) {
        int popupX;
        if (popupKey.popupResId == 0) {
            return false;
        }
        View container = this.mMiniKeyboardCache.get(popupKey);
        if (container == null) {
            container = inflateMiniKeyboardContainer(popupKey);
            this.mMiniKeyboardCache.put(popupKey, container);
        }
        this.mMiniKeyboard = (LatinKeyboardBaseView) container.findViewById(inputmethod.latin.perfectkeyboard.R.id.LatinKeyboardBaseView);
        if (this.mWindowOffset == null) {
            this.mWindowOffset = new int[2];
            getLocationInWindow(this.mWindowOffset);
        }
        List<Keyboard.Key> miniKeys = this.mMiniKeyboard.getKeyboard().getKeys();
        int miniKeyWidth = miniKeys.size() > 0 ? miniKeys.get(0).width : 0;
        if (popupKey.label != null && popupKey.label.equals("/")) {
            editPopularDomains(miniKeys);
        }
        int i = popupKey.popupResId;
        hasMultiplePopupChars(popupKey);
        int popupX2 = popupKey.x + this.mWindowOffset[0] + getPaddingLeft();
        if (popupX2 < (this.mKeyboard.getMinWidth() - 10) / 2) {
            popupX = (popupX2 + (popupKey.width - miniKeyWidth)) - container.getPaddingLeft();
        } else {
            popupX = ((popupX2 + miniKeyWidth) - container.getMeasuredWidth()) + container.getPaddingRight();
        }
        int popupY = popupKey.y + this.mWindowOffset[1];
        int x = popupX;
        int y = (this.mShowPreview && isOneRowKeys(miniKeys)) ? this.mPopupPreviewDisplayedY : ((popupY + getPaddingTop()) - container.getMeasuredHeight()) + container.getPaddingBottom();
        int adjustedX = x;
        if (x < 0) {
            adjustedX = 0;
        } else if (x > getMeasuredWidth() - container.getMeasuredWidth()) {
            adjustedX = getMeasuredWidth() - container.getMeasuredWidth();
        }
        this.mMiniKeyboardOriginX = (container.getPaddingLeft() + adjustedX) - this.mWindowOffset[0];
        this.mMiniKeyboardOriginY = (container.getPaddingTop() + y) - this.mWindowOffset[1];
        this.mMiniKeyboard.setPopupOffset(adjustedX, y);
        this.mMiniKeyboard.setShifted(isShifted());
        this.mMiniKeyboard.setPreviewEnabled(false);
        this.mMiniKeyboardPopup.setContentView(container);
        this.mMiniKeyboardPopup.setWidth(container.getMeasuredWidth());
        this.mMiniKeyboardPopup.setHeight(container.getMeasuredHeight());
        this.mMiniKeyboardPopup.showAtLocation(this, 0, x, y);
        long eventTime = SystemClock.uptimeMillis();
        this.mMiniKeyboardPopupTime = eventTime;
        MotionEvent downEvent = generateMiniKeyboardMotionEvent(0, (popupKey.width / 2) + popupKey.x, (popupKey.height / 2) + popupKey.y, eventTime);
        this.mMiniKeyboard.onTouchEvent(downEvent);
        downEvent.recycle();
        invalidateAllKeys();
        return true;
    }

    private static boolean hasMultiplePopupChars(Keyboard.Key key) {
        return key.popupCharacters != null && key.popupCharacters.length() > 1;
    }

    private boolean shouldDrawIconFully(Keyboard.Key key) {
        return isNumberAtEdgeOfPopupChars(key) || (isLatinF1Key(key) && key.text != "enter");
    }

    private boolean shouldDrawLabelAndIcon(Keyboard.Key key) {
        return isNumberAtEdgeOfPopupChars(key) || isNonMicLatinF1Key(key) || LatinKeyboard.hasPuncOrSmileysPopup(key);
    }

    private boolean isLatinF1Key(Keyboard.Key key) {
        return (this.mKeyboard instanceof LatinKeyboard) && ((LatinKeyboard) this.mKeyboard).isF1Key(key);
    }

    private boolean isNonMicLatinF1Key(Keyboard.Key key) {
        return isLatinF1Key(key) && key.label != null;
    }

    private static boolean isNumberAtEdgeOfPopupChars(Keyboard.Key key) {
        return isNumberAtLeftmostPopupChar(key) || isNumberAtRightmostPopupChar(key);
    }

    /* JADX INFO: Access modifiers changed from: package-private */
    public static boolean isNumberAtLeftmostPopupChar(Keyboard.Key key) {
        return key.popupCharacters != null && key.popupCharacters.length() > 0 && isAsciiDigit(key.popupCharacters.charAt(0));
    }

    /* JADX INFO: Access modifiers changed from: package-private */
    public static boolean isNumberAtRightmostPopupChar(Keyboard.Key key) {
        return key.popupCharacters != null && key.popupCharacters.length() > 0 && isAsciiDigit(key.popupCharacters.charAt(key.popupCharacters.length() + (-1)));
    }

    private static boolean isAsciiDigit(char c) {
        return c < 128 && Character.isDigit(c);
    }

    private MotionEvent generateMiniKeyboardMotionEvent(int action, int x, int y, long eventTime) {
        return MotionEvent.obtain(this.mMiniKeyboardPopupTime, eventTime, action, x - this.mMiniKeyboardOriginX, y - this.mMiniKeyboardOriginY, 0);
    }

    private PointerTracker getPointerTracker(int id) {
        ArrayList<PointerTracker> pointers = this.mPointerTrackers;
        Keyboard.Key[] keys = this.mKeys;
        OnKeyboardActionListener listener = this.mKeyboardActionListener;
        for (int i = pointers.size(); i <= id; i++) {
            PointerTracker tracker = new PointerTracker(i, this.mHandler, this.mKeyDetector, this, getResources(), this.mLongPressDelay);
            if (keys != null) {
                tracker.setKeyboard(keys, this.mKeyHysteresisDistance);
            }
            if (listener != null) {
                tracker.setOnKeyboardActionListener(listener);
            }
            pointers.add(tracker);
        }
        return pointers.get(id);
    }

    public static void setColor(int color) {
        mColorButton = color;
    }

    public static int getColor() {
        return mColorButton;
    }

    public boolean isInSlidingKeyInput() {
        return this.mMiniKeyboard != null ? this.mMiniKeyboard.isInSlidingKeyInput() : this.mPointerQueue.isInSlidingKeyInput();
    }

    public int getPointerCount() {
        return this.mOldPointerCount;
    }

    @Override // android.view.View
    public boolean onTouchEvent(MotionEvent me) {
        int action = me.getActionMasked();
        int pointerCount = me.getPointerCount();
        int oldPointerCount = this.mOldPointerCount;
        this.mOldPointerCount = pointerCount;
        if (!this.mHasDistinctMultitouch && pointerCount > 1 && oldPointerCount > 1) {
            return true;
        }
        this.mSwipeTracker.addMovement(me);
        if (this.mMiniKeyboard == null && this.mGestureDetector != null && this.mGestureDetector.onTouchEvent(me)) {
            dismissKeyPreview();
            this.mHandler.cancelKeyTimers();
            return true;
        }
        long eventTime = me.getEventTime();
        int index = me.getActionIndex();
        int id = me.getPointerId(index);
        int x = (int) me.getX(index);
        int y = (int) me.getY(index);
        if (this.mMiniKeyboard != null) {
            int miniKeyboardPointerIndex = me.findPointerIndex(this.mMiniKeyboardTrackerId);
            if (miniKeyboardPointerIndex >= 0 && miniKeyboardPointerIndex < pointerCount) {
                int miniKeyboardX = (int) me.getX(miniKeyboardPointerIndex);
                int miniKeyboardY = (int) me.getY(miniKeyboardPointerIndex);
                MotionEvent translated = generateMiniKeyboardMotionEvent(action, miniKeyboardX, miniKeyboardY, eventTime);
                this.mMiniKeyboard.onTouchEvent(translated);
                translated.recycle();
            }
            return true;
        }
        if (this.mHandler.isInKeyRepeat()) {
            if (action == 2) {
                return true;
            }
            PointerTracker tracker = getPointerTracker(id);
            if (pointerCount > 1 && !tracker.isModifier()) {
                this.mHandler.cancelKeyRepeatTimer();
            }
        }
        if (!this.mHasDistinctMultitouch) {
            PointerTracker tracker2 = getPointerTracker(0);
            if (pointerCount == 1 && oldPointerCount == 2) {
                tracker2.onDownEvent(x, y, eventTime);
            } else if (pointerCount == 2 && oldPointerCount == 1) {
                tracker2.onUpEvent(tracker2.getLastX(), tracker2.getLastY(), eventTime);
            } else if (pointerCount == 1 && oldPointerCount == 1) {
                tracker2.onTouchEvent(action, x, y, eventTime);
            } else {
                Log.w(TAG, "Unknown touch panel behavior: pointer count is " + pointerCount + " (old " + oldPointerCount + ")");
            }
            return true;
        }
        if (action == 2) {
            for (int i = 0; i < pointerCount; i++) {
                getPointerTracker(me.getPointerId(i)).onMoveEvent((int) me.getX(i), (int) me.getY(i), eventTime);
            }
        } else {
            PointerTracker tracker3 = getPointerTracker(id);
            switch (action) {
                case 0:
                case 5:
                    onDownEvent(tracker3, x, y, eventTime);
                    break;
                case 1:
                case 6:
                    onUpEvent(tracker3, x, y, eventTime);
                    break;
                case 3:
                    onCancelEvent(tracker3, x, y, eventTime);
                    break;
            }
        }
        return true;
    }

    private void onDownEvent(PointerTracker tracker, int x, int y, long eventTime) {
        if (tracker.isOnModifierKey(x, y)) {
            this.mPointerQueue.releaseAllPointersExceptDontSend(null, eventTime);
        }
        tracker.onDownEvent(x, y, eventTime);
        this.mPointerQueue.add(tracker);
    }

    private void onUpEvent(PointerTracker tracker, int x, int y, long eventTime) {
        if (tracker.isModifier()) {
            this.mPointerQueue.releaseAllPointersExcept(tracker, eventTime);
        } else {
            int index = this.mPointerQueue.lastIndexOf(tracker);
            if (index >= 0) {
                this.mPointerQueue.releaseAllPointersOlderThan(tracker, eventTime);
            } else {
                Log.w(TAG, "onUpEvent: corresponding down event not found for pointer " + tracker.mPointerId);
            }
        }
        tracker.onUpEvent(x, y, eventTime);
        this.mPointerQueue.remove(tracker);
    }

    private void onCancelEvent(PointerTracker tracker, int x, int y, long eventTime) {
        tracker.onCancelEvent(x, y, eventTime);
        this.mPointerQueue.remove(tracker);
    }

    protected void swipeRight() {
        this.mKeyboardActionListener.swipeRight();
    }

    protected void swipeLeft() {
        this.mKeyboardActionListener.swipeLeft();
    }

    protected void swipeUp() {
        this.mKeyboardActionListener.swipeUp();
    }

    protected void swipeDown() {
        this.mKeyboardActionListener.swipeDown();
    }

    public void closing() {
        this.mPreviewPopup.dismiss();
        this.mHandler.cancelAllMessages();
        dismissPopupKeyboard();
        if (this.mBuffer != null) {
            this.mBuffer.recycle();
            this.mBuffer = null;
        }
        this.mCanvas = null;
        this.mMiniKeyboardCache.clear();
    }

    @Override // android.view.View
    public void onDetachedFromWindow() {
        super.onDetachedFromWindow();
        closing();
    }

    /* JADX INFO: Access modifiers changed from: private */
    public void dismissPopupKeyboard() {
        if (this.mMiniKeyboardPopup.isShowing()) {
            this.mMiniKeyboardPopup.dismiss();
            this.mMiniKeyboard = null;
            this.mMiniKeyboardOriginX = 0;
            this.mMiniKeyboardOriginY = 0;
            invalidateAllKeys();
        }
    }

    public boolean handleBack() {
        if (!this.mMiniKeyboardPopup.isShowing()) {
            return false;
        }
        dismissPopupKeyboard();
        return true;
    }

    public int ColorBrightness(int color) {
        int Brightness = (int) Math.sqrt((Color.red(color) * Color.red(color) * 0.241d) + (Color.green(color) * Color.green(color) * 0.691d) + (Color.blue(color) * Color.blue(color) * 0.068d));
        return Brightness;
    }

    public boolean isColorGray(int color) {
        int R = Color.red(color);
        int G = Color.green(color);
        int B = Color.blue(color);
        int avrg = ((R + G) + B) / 3;
        return Math.abs(R - avrg) < 10 && Math.abs(G - avrg) < 10 && Math.abs(B - avrg) < 10;
    }

    public static void setShowTouchPoints(boolean show) {
        mShowTouchPoints = show;
    }

    private void editPopularDomains(List<Keyboard.Key> miniKeys) {
        for (int i = 0; i < 6; i++) {
            miniKeys.get(i).label = popularDomains[i];
            miniKeys.get(i).text = popularDomains[i];
        }
    }

    private void editCustomSmile(List<Keyboard.Key> miniKeys) {
        for (int i = 0; i < 15; i++) {
            miniKeys.get(i).label = CustomSmileys[i];
            miniKeys.get(i).text = CustomSmileys[i];
        }
    }

    private void editPunctuationPopup(List<Keyboard.Key> miniKeys) {
        for (int i = 0; i < 13; i++) {
            miniKeys.get(i).codes[0] = Character.codePointAt(CustomPunctuationPopup[i], 0);
            miniKeys.get(i).label = CustomPunctuationPopup[i];
            miniKeys.get(i).text = null;
        }
    }
}
