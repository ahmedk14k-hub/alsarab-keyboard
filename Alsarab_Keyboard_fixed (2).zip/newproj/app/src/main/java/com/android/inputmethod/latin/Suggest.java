package com.android.inputmethod.latin;

import DictionaryPackage.DicatinaryPackage;
import android.content.Context;
import android.content.res.Resources;
import android.text.AutoText;
import android.text.TextUtils;
import android.util.Log;
import android.view.View;
import com.android.common.speech.LoggingEvents;
import com.android.inputmethod.latin.Dictionary;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.Locale;

/* loaded from: classes.dex */
public class Suggest implements Dictionary.WordCallback {
    public static final int APPROX_MAX_WORD_LENGTH = 32;
    public static final double BIGRAM_MULTIPLIER_MAX = 1.5d;
    public static final double BIGRAM_MULTIPLIER_MIN = 1.2d;
    public static final int CORRECTION_BASIC = 1;
    public static final int CORRECTION_FULL = 2;
    public static final int CORRECTION_FULL_BIGRAM = 3;
    public static final int CORRECTION_NONE = 0;
    public static final int DIC_AUTO = 3;
    public static final int DIC_CONTACTS = 4;
    public static final int DIC_MAIN = 1;
    public static final int DIC_TYPE_LAST_ID = 4;
    public static final int DIC_USER = 2;
    public static final int DIC_USER_TYPED = 0;
    static final int LARGE_DICTIONARY_THRESHOLD = 50000;
    public static final int MAXIMUM_BIGRAM_FREQUENCY = 127;
    private static final int PREF_MAX_BIGRAMS = 60;
    private Dictionary mAutoDictionary;
    private AutoTextDictionary mAutoTextDictionary;
    private boolean mAutoTextEnabled;
    private Dictionary mContactsDictionary;
    private boolean mHaveAutoText;
    private boolean mHaveCorrection;
    private boolean mIsAllUpperCase;
    private boolean mIsFirstCharCapitalized;
    private Locale mLocale;
    private String mLowerOriginalWord;
    private Dictionary mMainDict;
    private CharSequence mOriginalWord;
    private Dictionary mUserBigramDictionary;
    private Dictionary mUserDictionary;
    private int mPrefMaxSuggestions = 12;
    private int[] mPriorities = new int[this.mPrefMaxSuggestions];
    private int[] mBigramPriorities = new int[PREF_MAX_BIGRAMS];
    private int[] mNextLettersFrequencies = new int[1280];
    private ArrayList<CharSequence> mSuggestions = new ArrayList<>();
    ArrayList<CharSequence> mBigramSuggestions = new ArrayList<>();
    private ArrayList<CharSequence> mStringPool = new ArrayList<>();
    private int mCorrectionMode = 1;

    public Suggest(Context context, ArrayList<DicatinaryPackage.DictionaryBuilder> dictionaries, Locale locale, Resources res) {
        this.mMainDict = null;
        this.mMainDict = DictionaryFactory.createDictionaryFromManager(context, locale, Utils.getMainDictionaryResourceId(res));
        this.mLocale = locale;
        initPool();
    }

    private void initPool() {
        for (int i = 0; i < this.mPrefMaxSuggestions; i++) {
            StringBuilder sb = new StringBuilder(getApproxMaxWordLength());
            this.mStringPool.add(sb);
        }
    }

    public void setAutoTextEnabled(boolean enabled) {
        this.mAutoTextEnabled = enabled;
    }

    public int getCorrectionMode() {
        return this.mCorrectionMode;
    }

    public void setCorrectionMode(int mode) {
        this.mCorrectionMode = mode;
    }

    public boolean hasMainDictionary() {
        return this.mMainDict != null;
    }

    public int getApproxMaxWordLength() {
        return 32;
    }

    public void setUserDictionary(Dictionary userDictionary) {
        this.mUserDictionary = userDictionary;
    }

    public void setContactsDictionary(Dictionary userDictionary) {
        this.mContactsDictionary = userDictionary;
    }

    public void setAutoTextDictionary(AutoTextDictionary autoTextDictionary) {
        this.mAutoTextDictionary = autoTextDictionary;
    }

    public void setAutoDictionary(Dictionary autoDictionary) {
        this.mAutoDictionary = autoDictionary;
    }

    public void setUserBigramDictionary(Dictionary userBigramDictionary) {
        this.mUserBigramDictionary = userBigramDictionary;
    }

    public void setMaxSuggestions(int maxSuggestions) {
        if (maxSuggestions < 1 || maxSuggestions > 100) {
            throw new IllegalArgumentException("maxSuggestions must be between 1 and 100");
        }
        this.mPrefMaxSuggestions = maxSuggestions;
        this.mPriorities = new int[this.mPrefMaxSuggestions];
        this.mBigramPriorities = new int[PREF_MAX_BIGRAMS];
        collectGarbage(this.mSuggestions, this.mPrefMaxSuggestions);
        while (this.mStringPool.size() < this.mPrefMaxSuggestions) {
            StringBuilder sb = new StringBuilder(getApproxMaxWordLength());
            this.mStringPool.add(sb);
        }
    }

    private boolean haveSufficientCommonality(String original, CharSequence suggestion) {
        int originalLength = original.length();
        int suggestionLength = suggestion.length();
        int minLength = Math.min(originalLength, suggestionLength);
        if (minLength <= 2) {
            return true;
        }
        int matching = 0;
        int lessMatching = 0;
        for (int i = 0; i < minLength; i++) {
            char origChar = ExpandableDictionary.toLowerCase(original.charAt(i));
            if (origChar == ExpandableDictionary.toLowerCase(suggestion.charAt(i))) {
                matching++;
                lessMatching++;
            } else if (i + 1 < suggestionLength && origChar == ExpandableDictionary.toLowerCase(suggestion.charAt(i + 1))) {
                lessMatching++;
            }
        }
        int matching2 = Math.max(matching, lessMatching);
        return minLength <= 4 ? matching2 >= 2 : matching2 > minLength / 2;
    }

    public List<CharSequence> getSuggestions(View view, WordComposer wordComposer, boolean includeTypedWordIfValid, CharSequence prevWordForBigram, ProximityInfo proximityInfo) {
        StringBuilder sb;
        int count;
        LatinImeLogger.onStartSuggestion(prevWordForBigram);
        this.mHaveCorrection = false;
        this.mIsFirstCharCapitalized = wordComposer.isFirstCharCapitalized();
        this.mIsAllUpperCase = wordComposer.isAllUpperCase();
        collectGarbage(this.mSuggestions, this.mPrefMaxSuggestions);
        Arrays.fill(this.mPriorities, 0);
        Arrays.fill(this.mNextLettersFrequencies, 0);
        this.mOriginalWord = wordComposer.getTypedWord();
        if (this.mOriginalWord != null) {
            String mOriginalWordString = this.mOriginalWord.toString();
            this.mOriginalWord = mOriginalWordString;
            this.mLowerOriginalWord = mOriginalWordString.toLowerCase();
            LatinImeLogger.onAddSuggestedWord(mOriginalWordString, 0, Dictionary.DataType.UNIGRAM);
        } else {
            this.mLowerOriginalWord = LoggingEvents.EXTRA_CALLING_APP_NAME;
        }
        if (DictionaryEditor.isT9Mode() && wordComposer.size() == 1) {
            int[] codes = wordComposer.getCodesAt(0);
            for (int i = 1; i < codes.length; i++) {
                if (codes[i] != -1) {
                    this.mSuggestions.add(i - 1, Character.toString((char) codes[i]));
                }
            }
            if (this.mLocale.getLanguage().equalsIgnoreCase("en")) {
                for (int i2 = 1; i2 < codes.length; i2++) {
                    if (codes[i2] == 105 || codes[i2] == 73) {
                        this.mSuggestions.add(0, "I");
                        this.mHaveCorrection = true;
                        break;
                    }
                    if (codes[i2] == 111 || codes[i2] == 79) {
                        this.mSuggestions.add(0, "O");
                        this.mHaveCorrection = true;
                        break;
                    }
                }
            }
        }
        if (wordComposer.size() == 1 && (this.mCorrectionMode == 3 || this.mCorrectionMode == 1)) {
            Arrays.fill(this.mBigramPriorities, 0);
            collectGarbage(this.mBigramSuggestions, PREF_MAX_BIGRAMS);
            if (!TextUtils.isEmpty(prevWordForBigram)) {
                CharSequence lowerPrevWord = prevWordForBigram.toString().toLowerCase();
                if (this.mMainDict != null && this.mMainDict.isValidWord(lowerPrevWord)) {
                    prevWordForBigram = lowerPrevWord;
                }
                if (this.mUserBigramDictionary != null) {
                    this.mUserBigramDictionary.getBigrams(wordComposer, prevWordForBigram, this);
                }
                if (this.mContactsDictionary != null) {
                    this.mContactsDictionary.getBigrams(wordComposer, prevWordForBigram, this);
                }
                if (this.mMainDict != null) {
                    this.mMainDict.getBigrams(wordComposer, prevWordForBigram, this);
                }
                char currentChar = wordComposer.getTypedWord().charAt(0);
                char currentCharUpper = Character.toUpperCase(currentChar);
                int bigramSuggestionSize = this.mBigramSuggestions.size();
                int i3 = 0;
                int count2 = 0;
                while (i3 < bigramSuggestionSize) {
                    if (this.mBigramSuggestions.get(i3).charAt(0) == currentChar || this.mBigramSuggestions.get(i3).charAt(0) == currentCharUpper) {
                        int poolSize = this.mStringPool.size();
                        if (poolSize > 0) {
                            sb = (StringBuilder) this.mStringPool.remove(poolSize - 1);
                        } else {
                            sb = new StringBuilder(getApproxMaxWordLength());
                        }
                        sb.setLength(0);
                        sb.append(this.mBigramSuggestions.get(i3));
                        count = count2 + 1;
                        this.mSuggestions.add(count2, sb);
                        if (count > this.mPrefMaxSuggestions) {
                            break;
                        }
                    } else {
                        count = count2;
                    }
                    i3++;
                    count2 = count;
                }
                if (bigramSuggestionSize > 0 && this.mCorrectionMode == 3) {
                    this.mHaveCorrection = true;
                }
            }
        } else if (wordComposer.size() > 1) {
            if (this.mUserDictionary != null || this.mContactsDictionary != null) {
                if (this.mUserDictionary != null) {
                    this.mUserDictionary.getWords(wordComposer, this, proximityInfo);
                }
                if (this.mContactsDictionary != null) {
                    this.mContactsDictionary.getWords(wordComposer, this, proximityInfo);
                }
                if (DictionaryEditor.isT9Mode() && this.mAutoDictionary != null) {
                    this.mAutoDictionary.getWords(wordComposer, this, proximityInfo);
                }
                if (this.mSuggestions.size() > 0 && isValidWord(this.mOriginalWord) && (this.mCorrectionMode == 2 || this.mCorrectionMode == 3 || DictionaryEditor.isT9Mode())) {
                    this.mHaveCorrection = true;
                }
            }
            if (this.mMainDict != null) {
                this.mMainDict.getWords(wordComposer, this, proximityInfo);
            }
            if ((this.mCorrectionMode == 2 || this.mCorrectionMode == 3 || DictionaryEditor.isT9Mode()) && this.mSuggestions.size() > 0) {
                this.mHaveCorrection = true;
            }
        }
        if (!DictionaryEditor.isT9Mode() && this.mOriginalWord != null) {
            this.mSuggestions.add(0, this.mOriginalWord.toString());
        }
        if (wordComposer.size() > 1 && this.mSuggestions.size() > 1 && ((this.mCorrectionMode == 2 || this.mCorrectionMode == 3 || DictionaryEditor.isT9Mode()) && !DictionaryEditor.isT9Mode() && !haveSufficientCommonality(this.mLowerOriginalWord, this.mSuggestions.get(1)))) {
            this.mHaveCorrection = false;
        }
        if (this.mAutoTextEnabled) {
            int i4 = 0;
            int max = this.mCorrectionMode == 1 ? 1 : 6;
            while (i4 < this.mSuggestions.size() && i4 < max) {
                String suggestedWord = this.mSuggestions.get(i4).toString().toLowerCase();
                CharSequence autoText = AutoText.get(suggestedWord, 0, suggestedWord.length(), view);
                boolean canAdd = (autoText != null) & (!TextUtils.equals(autoText, this.mSuggestions.get(i4)));
                if (canAdd && i4 + 1 < this.mSuggestions.size() && this.mCorrectionMode != 1) {
                    canAdd &= !TextUtils.equals(autoText, this.mSuggestions.get(i4 + 1));
                }
                if (canAdd) {
                    this.mHaveCorrection = true;
                    int place = i4;
                    if (DictionaryEditor.isT9Mode() && wordComposer.size() == 1) {
                        place = 0;
                    }
                    this.mSuggestions.add(place + 1, autoText);
                    i4++;
                }
                i4++;
            }
        }
        removeDupes();
        this.mHaveAutoText = false;
        if (DictionaryEditor.isT9Mode() && this.mOriginalWord != null && wordComposer.size() >= 1) {
            this.mSuggestions.add(0, this.mOriginalWord.toString());
        }
        if (this.mAutoTextDictionary.isValidWord(this.mLowerOriginalWord)) {
            ArrayList<CharSequence> autotexts = this.mAutoTextDictionary.getWords(this.mLowerOriginalWord);
            for (int i5 = 0; i5 < autotexts.size(); i5++) {
                this.mSuggestions.add(i5 + 1, autotexts.get(i5));
            }
            this.mHaveAutoText = true;
        }
        return this.mSuggestions;
    }

    public int[] getNextLettersFrequencies() {
        return this.mNextLettersFrequencies;
    }

    private void removeDupes() {
        ArrayList<CharSequence> suggestions = this.mSuggestions;
        if (suggestions.size() >= 2) {
            int i = 1;
            while (i < suggestions.size()) {
                CharSequence cur = suggestions.get(i);
                int j = 0;
                while (true) {
                    if (j >= i) {
                        break;
                    }
                    CharSequence previous = suggestions.get(j);
                    if (!TextUtils.equals(cur, previous)) {
                        j++;
                    } else {
                        removeFromSuggestions(i);
                        i--;
                        break;
                    }
                }
                i++;
            }
        }
    }

    private void removeFromSuggestions(int index) {
        CharSequence garbage = this.mSuggestions.remove(index);
        if (garbage != null && (garbage instanceof StringBuilder)) {
            this.mStringPool.add(garbage);
        }
    }

    public boolean hasMinimalCorrection() {
        return this.mHaveCorrection;
    }

    public boolean hasAutoText() {
        return this.mHaveAutoText;
    }

    private boolean compareCaseInsensitive(String mLowerOriginalWord, char[] word, int offset, int length) {
        int originalLength = mLowerOriginalWord.length();
        if (originalLength != length || !Character.isUpperCase(word[offset])) {
            return false;
        }
        for (int i = 0; i < originalLength; i++) {
            if (mLowerOriginalWord.charAt(i) != Character.toLowerCase(word[offset + i])) {
                return false;
            }
        }
        return true;
    }

    /* JADX WARN: Code restructure failed: missing block: B:15:0x003b, code lost:
    
        return true;
     */
    @Override // com.android.inputmethod.latin.Dictionary.WordCallback
    /*
        Code decompiled incorrectly, please refer to instructions dump.
    */
    public boolean addWord(char[] word, int offset, int length, int freq, int dicTypeId, Dictionary.DataType dataType) {
        ArrayList<CharSequence> suggestions;
        int[] priorities;
        int prefMaxSuggestions;
        int bigramSuggestion;
        Dictionary.DataType dataTypeForLog = dataType;
        if (DictionaryEditor.isT9Mode() && dicTypeId == 4) {
            freq /= 10;
        }
        if (dataType == Dictionary.DataType.BIGRAM) {
            suggestions = this.mBigramSuggestions;
            priorities = this.mBigramPriorities;
            prefMaxSuggestions = PREF_MAX_BIGRAMS;
        } else {
            suggestions = this.mSuggestions;
            priorities = this.mPriorities;
            prefMaxSuggestions = this.mPrefMaxSuggestions;
        }
        int pos = 0;
        if (DictionaryEditor.isT9Mode() || !compareCaseInsensitive(this.mLowerOriginalWord, word, offset, length)) {
            if (dataType == Dictionary.DataType.UNIGRAM && (bigramSuggestion = searchBigramSuggestion(word, offset, length)) >= 0) {
                dataTypeForLog = Dictionary.DataType.BIGRAM;
                double multiplier = ((this.mBigramPriorities[bigramSuggestion] / 127.0d) * 0.30000000000000004d) + 1.2d;
                freq = (int) Math.round(freq * multiplier);
            }
            if (priorities[prefMaxSuggestions - 1] >= freq) {
                return true;
            }
            while (pos < prefMaxSuggestions && priorities[pos] >= freq && (priorities[pos] != freq || length >= suggestions.get(pos).length())) {
                pos++;
            }
        } else {
            pos = 0;
        }
        System.arraycopy(priorities, pos, priorities, pos + 1, (prefMaxSuggestions - pos) - 1);
        priorities[pos] = freq;
        int poolSize = this.mStringPool.size();
        StringBuilder sb = poolSize > 0 ? (StringBuilder) this.mStringPool.remove(poolSize - 1) : new StringBuilder(getApproxMaxWordLength());
        sb.setLength(0);
        if (this.mIsAllUpperCase) {
            sb.append(new String(word, offset, length).toUpperCase());
        } else if (this.mIsFirstCharCapitalized) {
            sb.append(Character.toUpperCase(word[offset]));
            if (length > 1) {
                sb.append(word, offset + 1, length - 1);
            }
        } else {
            sb.append(word, offset, length);
        }
        suggestions.add(pos, sb);
        if (suggestions.size() > prefMaxSuggestions) {
            CharSequence garbage = suggestions.remove(prefMaxSuggestions);
            if (garbage instanceof StringBuilder) {
                this.mStringPool.add(garbage);
            }
        } else {
            LatinImeLogger.onAddSuggestedWord(sb.toString(), dicTypeId, dataTypeForLog);
        }
        return true;
    }

    private int searchBigramSuggestion(char[] word, int offset, int length) {
        int bigramSuggestSize = this.mBigramSuggestions.size();
        for (int i = 0; i < bigramSuggestSize; i++) {
            if (this.mBigramSuggestions.get(i).length() == length) {
                boolean chk = true;
                int j = 0;
                while (true) {
                    if (j >= length) {
                        break;
                    }
                    if (this.mBigramSuggestions.get(i).charAt(j) == word[offset + j]) {
                        j++;
                    } else {
                        chk = false;
                        break;
                    }
                }
                if (chk) {
                    return i;
                }
            }
        }
        return -1;
    }

    public boolean isValidWord(CharSequence word) {
        if (word == null || word.length() == 0) {
            return false;
        }
        return (this.mMainDict != null && this.mMainDict.isValidWord(word)) || (this.mUserDictionary != null && this.mUserDictionary.isValidWord(word)) || ((this.mAutoDictionary != null && this.mAutoDictionary.isValidWord(word)) || (this.mContactsDictionary != null && this.mContactsDictionary.isValidWord(word)));
    }

    private void collectGarbage(ArrayList<CharSequence> suggestions, int prefMaxSuggestions) {
        int poolSize = this.mStringPool.size();
        for (int garbageSize = suggestions.size(); poolSize < prefMaxSuggestions && garbageSize > 0; garbageSize--) {
            CharSequence garbage = suggestions.get(garbageSize - 1);
            if (garbage != null && (garbage instanceof StringBuilder)) {
                this.mStringPool.add(garbage);
                poolSize++;
            }
        }
        if (poolSize == prefMaxSuggestions + 1) {
            Log.w("Suggest", "String pool got too big: " + poolSize);
        }
        suggestions.clear();
    }

    public void close() {
        if (this.mMainDict != null) {
            this.mMainDict.close();
        }
    }
}
