package com.android.inputmethod.latin;

import android.content.Context;
import android.content.SharedPreferences;
import android.content.res.Configuration;
import android.content.res.Resources;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.PorterDuff;
import android.graphics.drawable.BitmapDrawable;
import android.graphics.drawable.Drawable;
import android.inputmethodservice.Keyboard;
import android.net.Uri;
import android.preference.PreferenceManager;
import android.view.InflateException;
import android.view.ViewGroup;
import com.android.common.speech.LoggingEvents;
import com.android.inputmethod.latin.DictionaryEditorUtil;
import inputmethod.latin.perfectkeyboard.R;
import java.io.FileNotFoundException;
import java.lang.ref.SoftReference;
import java.util.Arrays;
import java.util.HashMap;
import java.util.Locale;

/* loaded from: classes.dex */
public class Calibration implements SharedPreferences.OnSharedPreferenceChangeListener {
    private static final int AUTO_MODE_SWITCH_STATE_ALPHA = 0;
    private static final int AUTO_MODE_SWITCH_STATE_CHORDING = 4;
    private static final int AUTO_MODE_SWITCH_STATE_MOMENTARY = 3;
    private static final int AUTO_MODE_SWITCH_STATE_SYMBOL = 2;
    private static final int AUTO_MODE_SWITCH_STATE_SYMBOL_BEGIN = 1;
    private static final int CHAR_THEME_COLOR_BLACK = 1;
    private static final int CHAR_THEME_COLOR_WHITE = 0;
    public static final int DEFAULT_LADDSCAPE_MODE_NORMAL = 0;
    public static final int DEFAULT_LADDSCAPE_MODE_SPLIT = 1;
    public static final String DEFAULT_LAYOUT_ID = "8";
    public static final int DEFAULT_MODE_COMPACT = 2;
    public static final int DEFAULT_MODE_NORMAL = 0;
    public static final int DEFAULT_MODE_SPLIT = 3;
    public static final int DEFAULT_MODE_T9 = 1;
    private static final int DEFAULT_SETTINGS_KEY_MODE = 2131558461;
    public static final int KEYBOARDMODE_ARROWS = 2131230769;
    public static final int KEYBOARDMODE_EMAIL = 2131230761;
    public static final int KEYBOARDMODE_EMAIL_WITH_SETTINGS_KEY = 2131230766;
    public static final int KEYBOARDMODE_IM = 2131230762;
    public static final int KEYBOARDMODE_IM_WITH_SETTINGS_KEY = 2131230767;
    public static final int KEYBOARDMODE_NORMAL = 2131230759;
    public static final int KEYBOARDMODE_NORMAL_WITH_SETTINGS_KEY = 2131230764;
    public static final int KEYBOARDMODE_SYMBOLS = 2131230770;
    public static final int KEYBOARDMODE_SYMBOLS_WITH_SETTINGS_KEY = 2131230771;
    public static final int KEYBOARDMODE_URL = 2131230760;
    public static final int KEYBOARDMODE_URL_WITH_SETTINGS_KEY = 2131230765;
    public static final int KEYBOARDMODE_WEB = 2131230763;
    public static final int KEYBOARDMODE_WEB_WITH_SETTINGS_KEY = 2131230768;
    public static final int MODE_ARROWS = 8;
    public static final int MODE_EMAIL = 5;
    public static final int MODE_IM = 6;
    public static final int MODE_NONE = 0;
    public static final int MODE_NUMBERS = 9;
    public static final int MODE_PHONE = 3;
    public static final int MODE_SYMBOLS = 2;
    public static final int MODE_TEXT = 1;
    public static final int MODE_URL = 4;
    public static final int MODE_WEB = 7;
    private static final String PREF_ARROWS_KEY_HIGHT_HORIZONTAL = "arrows_keys_hight_horizontal";
    private static final String PREF_ARROWS_KEY_HIGHT_VERTICAL = "arrows_keys_hight_vertical";
    private static final String PREF_BACKGROUND_CUSTOM_KEY = "background_custom_key";
    private static final String PREF_BOTTOM_PADDING_HORIZONTAL = "bottom_padding_horizontal";
    private static final String PREF_BOTTOM_PADDING_VERTICAL = "bottom_padding_vertical";
    private static final String PREF_CZECH_FULL_LAYOUT = "czech_full_layout";
    private static final String PREF_DISPLAY_ALT_LABELS = "dispaly_alt_labels";
    private static final String PREF_ENABLE_NUMBER_KEYPAD = "enable_number_keypad";
    private static final String PREF_HEBREW_ALT_LAYOUT = "hebrew_alt_layout";
    private static final String PREF_KB_FONT_COLOR = "keyboard_font_symbol_color_new";
    private static final String PREF_KB_HINT_FONT_COLOR = "keyboard_hint_font_color_color";
    public static final String PREF_KEYBOARD_LAYOUT = "pref_keyboard_layout_20100902";
    private static final String PREF_KEY_HIGHT_HORIZONTAL = "key_hight_horizontal";
    private static final String PREF_KEY_HIGHT_VERTICAL = "key_hight_vertical";
    private static final String PREF_LANDSCAPE_LAYOUT = "pref_landscape_layout";
    private static final String PREF_PORTRAIT_LAYOUT = "pref_portrait_layout";
    private static final String PREF_ROW_GAP_HORIZONTAL = "row_gap_horizontal";
    private static final String PREF_ROW_GAP_VERTICAL = "row_gap_vertical";
    private static final String PREF_TEXT_SIZE_HORIZONTAL = "text_size_horizontal";
    private static final String PREF_TEXT_SIZE_VERTICAL = "text_size_vertical";
    public static final String PREF_URI_BACKGROUND_IMAGE = "background_image_uri";
    public static final String PREF_USE_CUSTOM_IMAGTE = "use_custom_image";
    private static final int SETTINGS_KEY_MODE_ALWAYS_HIDE = 2131558461;
    private static final int SETTINGS_KEY_MODE_ALWAYS_SHOW = 2131558460;
    private static final int SETTINGS_KEY_MODE_AUTO = 2131558459;
    public static boolean isFourRowLayout;
    public static boolean mDisplayAltLables;
    private static boolean mEnableNumberKeypad;
    public static int mFontSymbolColors;
    public static boolean mIsPortraitModeAndT9;
    public static boolean mSmallLabelText;
    private int mArrowsKeyHightHorizontal;
    private int mArrowsKeyHightVertical;
    private int mBottomPaddingHorizontal;
    private int mBottomPaddingVertical;
    private KeyboardId mCurrentId;
    private boolean mCzechFull;
    private boolean mHasSettingsKey;
    public boolean mHasVoice;
    private boolean mHebrewAlt;
    private int mImeOptions;
    private Locale mInputLocale;
    private DictionaryEditor mInputMethodService;
    private LatinKeyboardView mInputView;
    private boolean mIsAutoCompletionActive;
    private boolean mIsNumbers;
    private boolean mIsSymbols;
    private int mKeyHightHorizontal;
    private int mKeyHightVertical;
    private String mKeyboardLayout;
    private LanguageSwitcher mLanguageSwitcher;
    private int mLastDisplayWidth;
    private int mLayoutId;
    private boolean mPreferNumbers;
    private boolean mPreferSymbols;
    private int mRowGapHorizontal;
    private int mRowGapVertical;
    private KeyboardId mSymbolsId;
    private KeyboardId mSymbolsShiftedId;
    private int mTextSizeHorizontal;
    private int mTextSizeVertical;
    private String mUriImage;
    private boolean mUseCustomeImage;
    private boolean mVoiceOnPrimary;
    private static final int[] THEMES = {R.layout.input_basic, R.layout.input_basic_highcontrast, R.layout.input_honeycomb, R.layout.input_stone_normal, R.layout.input_gingerbread, R.layout.input_silicon_light, R.layout.input_htc, R.layout.input_iphone, R.layout.input_ics};
    private static final int[] KBD_PHONE = {R.xml.kbd_phone};
    private static final int[] KBD_PHONE_SYMBOLS = {R.xml.kbd_phone_symbols};
    private static final int[] KBD_SYMBOLS = {R.xml.kbd_symbols};
    private static final int[] KBD_SPLITTED_SYMBOLS = {R.xml.kbd_splitted_symbols};
    private static final int[] KBD_NUMBERS = {R.xml.kbd_numbers};
    private static final int[] KBD_SYMBOLS_SHIFT = {R.xml.kbd_symbols_shift};
    private static final int[] KBD_QWERTY = {R.xml.kbd_qwerty};
    private static final int[] KBD_QWERTY_SWISS = {R.xml.kbd_qwerty_swiss};
    private static final int[] KBD_QWERTY2 = {R.xml.kbd_qwerty2};
    private static final int[] KBD_QWERTZ = {R.xml.kbd_qwertz};
    private static final int[] KBD_AZERTY = {R.xml.kbd_azerty};
    private static final int[] KBD_DVORAK = {R.xml.kbd_dvorak};
    private static final int[] KBD_COLEMAX = {R.xml.kbd_colemak};
    private static final int[] KBD_QWERTY_ALT = {R.xml.kbd_qwerty_alt};
    private static final int[] KED_T9 = {R.xml.kbd_t9};
    private static final int[] KED_COMPACT = {R.xml.kbd_compact};
    private static final int[] KED_COMPACT_QWERTZ = {R.xml.kbd_compact_qwertz};
    private static final int[] KED_COMPACT_AZERTY = {R.xml.kbd_compact_azerty};
    private static final int[] KED_COMPACT_DVORAK = {R.xml.kbd_compact_dvorak};
    private static final int[] KED_COMPACT_QWERTY2 = {R.xml.kbd_compact_qwerty2};
    private static final int[] KED_QWERTY_UMLAUTE = {R.xml.kbd_qwerty_german_full};
    private static final int[] KED_SPLITTED = {R.xml.kbd_splitted_qwerty};
    private static final int[] KED_SPLITTED_AZERTY = {R.xml.kbd_splitted_azerty};
    private static final int[] KED_SPLITTED_QWERTZ = {R.xml.kbd_splitted_qwertz};
    private static final int[] KED_SPLITTED_QWERTY_SWISS = {R.xml.kbd_splitted_qwerty_swiss};
    private static final int[] KED_SPLITTED_QWERTY_UMLAUTE = {R.xml.kbd_splitted_qwerty_german_full};
    private static final int[] KED_SPLITTED_DVORAK = {R.xml.kbd_splitted_dvorak};
    private static final int[] KED_SPLITTED_QWERTY2 = {R.xml.kbd_splitted_qwerty2};
    private static final int[] KED_QWERTY_CZ_FULL = {R.xml.kbd_qwerty_cz_full};
    private static final int[] KED_QWERTZ_CZ_FULL = {R.xml.kbd_qwertz_cz_full};
    private static final int[] KED_SPLITTED_QWERTY_CZ_FULL = {R.xml.kbd_splitted_qwerty_cz_full};
    private static final int[] KED_SPLITTED_QWERTZ_CZ_FULL = {R.xml.kbd_splitted_qwertz_cz_full};
    public static int mPortaraitLayoutMode = 0;
    public static int mLandscapeLayoutMode = 0;
    private static final int[] ALPHABET_MODES = {R.id.mode_normal, R.id.mode_url, R.id.mode_email, R.id.mode_im, R.id.mode_webentry, R.id.mode_normal_with_settings_key, R.id.mode_url_with_settings_key, R.id.mode_email_with_settings_key, R.id.mode_im_with_settings_key, R.id.mode_webentry_with_settings_key};
    private static final Calibration sInstance = new Calibration();
    private final HashMap<KeyboardId, SoftReference<LatinKeyboard>> mKeyboards = new HashMap<>();
    public int mMode = 0;
    private int mAutoModeSwitchState = 0;

    public static Calibration getInstance() {
        return sInstance;
    }

    private Calibration() {
    }

    public static void init(DictionaryEditor ims) {
        sInstance.mInputMethodService = ims;
        SharedPreferences prefs = PreferenceManager.getDefaultSharedPreferences(ims);
        sInstance.mLayoutId = Integer.valueOf(prefs.getString(PREF_KEYBOARD_LAYOUT, DEFAULT_LAYOUT_ID)).intValue();
        sInstance.updateSettingsKeyState(prefs);
        prefs.registerOnSharedPreferenceChangeListener(sInstance);
        sInstance.mSymbolsId = sInstance.makeSymbolsId(false);
        sInstance.mSymbolsShiftedId = sInstance.makeSymbolsShiftedId(false);
    }

    public void setLanguageSwitcher(LanguageSwitcher languageSwitcher) {
        this.mLanguageSwitcher = languageSwitcher;
        this.mInputLocale = this.mLanguageSwitcher.getInputLocale();
    }

    private KeyboardId makeSymbolsId(boolean hasVoice) {
        int i = R.id.mode_symbols_with_settings_key;
        if ((mLandscapeLayoutMode == 1 && !isPortraitMode()) || (mPortaraitLayoutMode == 3 && isPortraitMode())) {
            int i2 = KBD_SPLITTED_SYMBOLS[getCharColorId()];
            if (!this.mHasSettingsKey) {
                i = R.id.mode_symbols;
            }
            return new KeyboardId(i2, i, false, hasVoice);
        }
        int i3 = KBD_SYMBOLS[getCharColorId()];
        if (!this.mHasSettingsKey) {
            i = R.id.mode_symbols;
        }
        return new KeyboardId(i3, i, false, hasVoice);
    }

    private KeyboardId makeSymbolsShiftedId(boolean hasVoice) {
        return new KeyboardId(KBD_SYMBOLS_SHIFT[getCharColorId()], this.mHasSettingsKey ? R.id.mode_symbols_with_settings_key : R.id.mode_symbols, false, hasVoice);
    }

    public void makeKeyboards(boolean forceCreate, String layout) {
        this.mKeyboardLayout = layout;
        this.mSymbolsId = makeSymbolsId(this.mHasVoice && !this.mVoiceOnPrimary);
        this.mSymbolsShiftedId = makeSymbolsShiftedId(this.mHasVoice && !this.mVoiceOnPrimary);
        if (forceCreate) {
            this.mKeyboards.clear();
        }
        int displayWidth = this.mInputMethodService.getMaxWidth();
        if (displayWidth != this.mLastDisplayWidth) {
            this.mLastDisplayWidth = displayWidth;
            if (!forceCreate) {
                this.mKeyboards.clear();
            }
        }
    }

    /* JADX INFO: Access modifiers changed from: private */
    /* loaded from: classes.dex */
    public static class KeyboardId {
        public final boolean mEnableShiftLock;
        public final boolean mHasVoice;
        private final int mHashCode;
        public final int mKeyboardMode;
        public final int mXml;

        public KeyboardId(int xml, int mode, boolean enableShiftLock, boolean hasVoice) {
            this.mXml = xml;
            this.mKeyboardMode = mode;
            this.mEnableShiftLock = enableShiftLock;
            this.mHasVoice = hasVoice;
            this.mHashCode = Arrays.hashCode(new Object[]{Integer.valueOf(xml), Integer.valueOf(mode), Boolean.valueOf(enableShiftLock), Boolean.valueOf(hasVoice)});
        }

        public KeyboardId(int xml, boolean hasVoice) {
            this(xml, 0, false, hasVoice);
        }

        public boolean equals(Object other) {
            return (other instanceof KeyboardId) && equals((KeyboardId) other);
        }

        /* JADX INFO: Access modifiers changed from: private */
        public boolean equals(KeyboardId other) {
            return other.mXml == this.mXml && other.mKeyboardMode == this.mKeyboardMode && other.mEnableShiftLock == this.mEnableShiftLock && other.mHasVoice == this.mHasVoice;
        }

        public int hashCode() {
            return this.mHashCode;
        }
    }

    public void setVoiceMode(boolean enableVoice, boolean voiceOnPrimary) {
        if (enableVoice != this.mHasVoice || voiceOnPrimary != this.mVoiceOnPrimary) {
            this.mKeyboards.clear();
        }
        this.mHasVoice = enableVoice;
        this.mVoiceOnPrimary = voiceOnPrimary;
        setKeyboardMode(this.mMode, this.mImeOptions, this.mHasVoice, this.mIsSymbols, this.mIsNumbers);
    }

    private boolean hasVoiceButton(boolean isSymbols) {
        return this.mHasVoice && isSymbols != this.mVoiceOnPrimary;
    }

    public void setKeyboardMode(int mode, int imeOptions, boolean enableVoice) {
        this.mAutoModeSwitchState = 0;
        this.mPreferSymbols = mode == 2;
        this.mPreferNumbers = mode == 9;
        if (mode == 2) {
            mode = 1;
        }
        try {
            setKeyboardMode(mode, imeOptions, enableVoice, this.mPreferSymbols, this.mPreferNumbers);
        } catch (RuntimeException e) {
            LatinImeLogger.logOnException(String.valueOf(mode) + "," + imeOptions + "," + this.mPreferSymbols, e);
        }
    }

    private void setKeyboardMode(int mode, int imeOptions, boolean enableVoice, boolean isSymbols, boolean isNumbers) {
        if (this.mInputView != null) {
            this.mMode = mode;
            this.mImeOptions = imeOptions;
            if (enableVoice != this.mHasVoice) {
                setVoiceMode(enableVoice, this.mVoiceOnPrimary);
            }
            this.mIsSymbols = isSymbols;
            this.mIsNumbers = isNumbers;
            this.mInputView.setPreviewEnabled(this.mInputMethodService.getPopupOn());
            KeyboardId id = getKeyboardId(mode, imeOptions, isSymbols, isNumbers);
            LatinKeyboard keyboard = getKeyboard(id);
            if (mode == 3) {
                this.mInputView.setPhoneKeyboard(keyboard);
            }
            this.mCurrentId = id;
            this.mInputView.setKeyboard(keyboard);
            keyboard.setShifted(false);
            keyboard.setShiftLocked(keyboard.isShiftLocked());
            keyboard.setImeOptions(this.mInputMethodService.getResources(), this.mMode, imeOptions);
            keyboard.setColorOfSymbolIcons(this.mIsAutoCompletionActive, isBlackSym());
            updateSettingsKeyState(PreferenceManager.getDefaultSharedPreferences(this.mInputMethodService));
        }
    }

    private LatinKeyboard getKeyboard(KeyboardId id) {
        SoftReference<LatinKeyboard> ref = this.mKeyboards.get(id);
        LatinKeyboard keyboard = ref == null ? null : ref.get();
        if (keyboard == null) {
            Resources orig = this.mInputMethodService.getResources();
            Configuration conf = orig.getConfiguration();
            Locale saveLocale = conf.locale;
            conf.locale = this.mInputLocale;
            orig.updateConfiguration(conf, null);
            keyboard = new LatinKeyboard(this.mInputMethodService, id.mXml, id.mKeyboardMode);
            keyboard.setVoiceMode(hasVoiceButton(id.mXml == R.xml.kbd_symbols || id.mXml == R.xml.kbd_splitted_symbols), this.mHasVoice);
            keyboard.setLanguageSwitcher(this.mLanguageSwitcher, this.mIsAutoCompletionActive, isBlackSym());
            if (id.mEnableShiftLock) {
                keyboard.enableShiftLock();
            }
            this.mKeyboards.put(id, new SoftReference<>(keyboard));
            conf.locale = saveLocale;
            orig.updateConfiguration(conf, null);
        }
        return keyboard;
    }

    private KeyboardId getKeyboardId(int mode, int imeOptions, boolean isSymbols, boolean isNumbers) {
        boolean hasVoice = hasVoiceButton(isSymbols);
        int charColorId = getCharColorId();
        int keyboardRowsResId = KBD_QWERTY[charColorId];
        mSmallLabelText = false;
        mIsPortraitModeAndT9 = false;
        isFourRowLayout = false;
        if (mPortaraitLayoutMode == 2 && isPortraitMode()) {
            mIsPortraitModeAndT9 = true;
            mSmallLabelText = true;
        }
        if (this.mKeyboardLayout.equals("qwerty")) {
            keyboardRowsResId = KBD_QWERTY[charColorId];
            if ((this.mInputLocale.getLanguage().equals("iw") || this.mInputLocale.getLanguage().equals("he")) && this.mHebrewAlt) {
                keyboardRowsResId = KBD_QWERTY_ALT[charColorId];
            }
            if (this.mInputLocale.getLanguage().equals("cs") && this.mCzechFull) {
                if (isAlphabetMode()) {
                    isFourRowLayout = true;
                }
                keyboardRowsResId = KED_QWERTY_CZ_FULL[charColorId];
            }
            if (mIsPortraitModeAndT9) {
                keyboardRowsResId = KED_COMPACT[charColorId];
            } else if ((mLandscapeLayoutMode == 1 && !isPortraitMode()) || (mPortaraitLayoutMode == 3 && isPortraitMode())) {
                keyboardRowsResId = KED_SPLITTED[charColorId];
                if (this.mInputLocale.getLanguage().equals("cs") && this.mCzechFull) {
                    keyboardRowsResId = KED_SPLITTED_QWERTY_CZ_FULL[charColorId];
                }
            }
        } else if (this.mKeyboardLayout.equals("qwertz")) {
            keyboardRowsResId = KBD_QWERTZ[charColorId];
            if (this.mInputLocale.getLanguage().equals("cs") && this.mCzechFull) {
                keyboardRowsResId = KED_QWERTZ_CZ_FULL[charColorId];
                if (isAlphabetMode()) {
                    isFourRowLayout = true;
                }
            }
            if (mIsPortraitModeAndT9) {
                keyboardRowsResId = KED_COMPACT_QWERTZ[charColorId];
            } else if ((mLandscapeLayoutMode == 1 && !isPortraitMode()) || (mPortaraitLayoutMode == 3 && isPortraitMode())) {
                keyboardRowsResId = KED_SPLITTED_QWERTZ[charColorId];
                if (this.mInputLocale.getLanguage().equals("cs") && this.mCzechFull) {
                    keyboardRowsResId = KED_SPLITTED_QWERTZ_CZ_FULL[charColorId];
                }
            }
        } else if (this.mKeyboardLayout.equals("colemax")) {
            keyboardRowsResId = KBD_COLEMAX[charColorId];
            if (mIsPortraitModeAndT9) {
                keyboardRowsResId = KED_COMPACT[charColorId];
            } else if ((mLandscapeLayoutMode == 1 && !isPortraitMode()) || (mPortaraitLayoutMode == 3 && isPortraitMode())) {
                keyboardRowsResId = KBD_COLEMAX[charColorId];
            }
        } else if (this.mKeyboardLayout.equals("qwerty2")) {
            keyboardRowsResId = KBD_QWERTY2[charColorId];
            if (mIsPortraitModeAndT9) {
                keyboardRowsResId = KED_COMPACT_QWERTY2[charColorId];
            } else if ((mLandscapeLayoutMode == 1 && !isPortraitMode()) || (mPortaraitLayoutMode == 3 && isPortraitMode())) {
                keyboardRowsResId = KED_SPLITTED_QWERTY2[charColorId];
            }
        } else if (this.mKeyboardLayout.equals("swiss")) {
            keyboardRowsResId = KBD_QWERTY_SWISS[charColorId];
            if (mIsPortraitModeAndT9) {
                keyboardRowsResId = KED_COMPACT[charColorId];
            } else if ((mLandscapeLayoutMode == 1 && !isPortraitMode()) || (mPortaraitLayoutMode == 3 && isPortraitMode())) {
                keyboardRowsResId = KED_SPLITTED_QWERTY_SWISS[charColorId];
            }
        } else if (this.mKeyboardLayout.equals("umlaute")) {
            keyboardRowsResId = KED_QWERTY_UMLAUTE[charColorId];
            if (mIsPortraitModeAndT9) {
                keyboardRowsResId = KED_COMPACT[charColorId];
            } else if ((mLandscapeLayoutMode == 1 && !isPortraitMode()) || (mPortaraitLayoutMode == 3 && isPortraitMode())) {
                keyboardRowsResId = KED_SPLITTED_QWERTY_UMLAUTE[charColorId];
            }
        } else if (this.mKeyboardLayout.equals("azerty")) {
            keyboardRowsResId = KBD_AZERTY[charColorId];
            if (mIsPortraitModeAndT9) {
                keyboardRowsResId = KED_COMPACT_AZERTY[charColorId];
            } else if ((mLandscapeLayoutMode == 1 && !isPortraitMode()) || (mPortaraitLayoutMode == 3 && isPortraitMode())) {
                keyboardRowsResId = KED_SPLITTED_AZERTY[charColorId];
            }
        } else if (this.mKeyboardLayout.equals("dvorak")) {
            keyboardRowsResId = KBD_DVORAK[charColorId];
            if (mIsPortraitModeAndT9) {
                keyboardRowsResId = KED_COMPACT_DVORAK[charColorId];
            } else if ((mLandscapeLayoutMode == 1 && !isPortraitMode()) || (mPortaraitLayoutMode == 3 && isPortraitMode())) {
                keyboardRowsResId = KED_SPLITTED_DVORAK[charColorId];
            }
        }
        if (mPortaraitLayoutMode == 1 && isPortraitMode()) {
            mIsPortraitModeAndT9 = true;
            keyboardRowsResId = KED_T9[charColorId];
            mSmallLabelText = true;
        }
        if (isSymbols) {
            if (mode == 3) {
                return new KeyboardId(KBD_PHONE_SYMBOLS[charColorId], hasVoice);
            }
            return makeSymbolsId(hasVoice);
        }
        if (isNumbers) {
            if (mode == 3) {
                return new KeyboardId(KBD_PHONE_SYMBOLS[charColorId], hasVoice);
            }
            return new KeyboardId(KBD_NUMBERS[charColorId], this.mHasSettingsKey ? R.id.mode_symbols_with_settings_key : R.id.mode_symbols, false, hasVoice);
        }
        switch (mode) {
            case 0:
                LatinImeLogger.logOnWarning("getKeyboardId:" + mode + "," + imeOptions + "," + isSymbols);
                break;
            case 1:
                break;
            case 2:
                return makeSymbolsId(hasVoice);
            case 3:
                return new KeyboardId(KBD_PHONE[charColorId], hasVoice);
            case 4:
                return new KeyboardId(keyboardRowsResId, this.mHasSettingsKey ? R.id.mode_url_with_settings_key : R.id.mode_url, true, hasVoice);
            case 5:
                return new KeyboardId(keyboardRowsResId, this.mHasSettingsKey ? R.id.mode_email_with_settings_key : R.id.mode_email, true, hasVoice);
            case 6:
                return new KeyboardId(keyboardRowsResId, this.mHasSettingsKey ? R.id.mode_im_with_settings_key : R.id.mode_im, true, hasVoice);
            case 7:
                return new KeyboardId(keyboardRowsResId, this.mHasSettingsKey ? R.id.mode_webentry_with_settings_key : R.id.mode_webentry, true, hasVoice);
            default:
                return null;
        }
        return new KeyboardId(keyboardRowsResId, this.mHasSettingsKey ? R.id.mode_normal_with_settings_key : R.id.mode_normal, true, hasVoice);
    }

    public int getKeyboardMode() {
        return this.mMode;
    }

    public int getKeyboardmImeOptions() {
        return this.mImeOptions;
    }

    public boolean isAlphabetMode() {
        if (this.mCurrentId == null) {
            return false;
        }
        int currentMode = this.mCurrentId.mKeyboardMode;
        for (int i : ALPHABET_MODES) {
            Integer mode = Integer.valueOf(i);
            if (currentMode == mode.intValue()) {
                return true;
            }
        }
        return false;
    }

    public void setShifted(boolean shifted) {
        if (this.mInputView != null) {
            this.mInputView.setShifted(shifted);
        }
    }

    public void setShiftLocked(boolean shiftLocked) {
        if (this.mInputView != null) {
            this.mInputView.setShiftLocked(shiftLocked);
        }
    }

    public void toggleShift() {
        if (!isAlphabetMode()) {
            if (this.mCurrentId.equals(this.mSymbolsId) || !this.mCurrentId.equals(this.mSymbolsShiftedId)) {
                LatinKeyboard symbolsShiftedKeyboard = getKeyboard(this.mSymbolsShiftedId);
                this.mCurrentId = this.mSymbolsShiftedId;
                this.mInputView.setKeyboard(symbolsShiftedKeyboard);
                symbolsShiftedKeyboard.enableShiftLock();
                symbolsShiftedKeyboard.setShiftLocked(true);
                symbolsShiftedKeyboard.setImeOptions(this.mInputMethodService.getResources(), this.mMode, this.mImeOptions);
                return;
            }
            LatinKeyboard symbolsKeyboard = getKeyboard(this.mSymbolsId);
            this.mCurrentId = this.mSymbolsId;
            this.mInputView.setKeyboard(symbolsKeyboard);
            symbolsKeyboard.enableShiftLock();
            symbolsKeyboard.setShifted(false);
            symbolsKeyboard.setImeOptions(this.mInputMethodService.getResources(), this.mMode, this.mImeOptions);
        }
    }

    public void onCancelInput() {
        if (this.mAutoModeSwitchState == 3 && getPointerCount() == 1) {
            this.mInputMethodService.changeKeyboardMode(true);
        }
    }

    public void toggleSymbols(boolean allowNumber) {
        if (this.mIsSymbols) {
            setKeyboardMode(this.mMode, this.mImeOptions, this.mHasVoice, false, false);
        } else if (this.mIsNumbers) {
            if (this.mAutoModeSwitchState == 2) {
                setKeyboardMode(this.mMode, this.mImeOptions, this.mHasVoice, false, false);
            } else {
                setKeyboardMode(this.mMode, this.mImeOptions, this.mHasVoice, true, false);
            }
        } else if (allowNumber && mEnableNumberKeypad && this.mMode != 3) {
            setKeyboardMode(this.mMode, this.mImeOptions, this.mHasVoice, false, true);
        } else {
            setKeyboardMode(this.mMode, this.mImeOptions, this.mHasVoice, true, false);
        }
        if ((this.mIsSymbols && !this.mPreferSymbols) || (this.mIsNumbers && !this.mPreferNumbers)) {
            this.mAutoModeSwitchState = 1;
        } else {
            this.mAutoModeSwitchState = 0;
        }
    }

    public boolean hasDistinctMultitouch() {
        return this.mInputView != null && this.mInputView.hasDistinctMultitouch();
    }

    public void setAutoModeSwitchStateMomentary() {
        this.mAutoModeSwitchState = 3;
    }

    public boolean isInMomentaryAutoModeSwitchState() {
        return this.mAutoModeSwitchState == 3;
    }

    public boolean isInChordingAutoModeSwitchState() {
        return this.mAutoModeSwitchState == 4;
    }

    public boolean isVibrateAndSoundFeedbackRequired() {
        return (this.mInputView == null || this.mInputView.isInSlidingKeyInput()) ? false : true;
    }

    private int getPointerCount() {
        if (this.mInputView == null) {
            return 0;
        }
        return this.mInputView.getPointerCount();
    }

    public void onKey(int key) {
        switch (this.mAutoModeSwitchState) {
            case 1:
                if (key != 32 && key != 10 && key >= 0) {
                    this.mAutoModeSwitchState = 2;
                    return;
                }
                return;
            case 2:
                if ((key == 10 || key == 32) && DictionaryEditor.mAutoBackToAlpha) {
                    this.mInputMethodService.changeKeyboardMode(true);
                    return;
                }
                return;
            case 3:
                if (key == -2) {
                    if (this.mIsSymbols || this.mIsNumbers) {
                        this.mAutoModeSwitchState = 1;
                        return;
                    } else {
                        this.mAutoModeSwitchState = 0;
                        return;
                    }
                }
                if (getPointerCount() == 1) {
                    this.mInputMethodService.changeKeyboardMode(true);
                    return;
                } else {
                    this.mAutoModeSwitchState = 4;
                    return;
                }
            default:
                return;
        }
    }

    public LatinKeyboardView getInputView() {
        return this.mInputView;
    }

    public void recreateInputView() {
        changeLatinKeyboardView(this.mLayoutId, true);
    }

    private void changeLatinKeyboardView(int newLayout, boolean forceReset) {
        if (this.mLayoutId != newLayout || this.mInputView == null || forceReset) {
            if (this.mInputView != null) {
                this.mInputView.closing();
            }
            SharedPreferences prefs = PreferenceManager.getDefaultSharedPreferences(this.mInputMethodService);
            LoadKeyboardLayout(prefs);
            if (THEMES.length <= newLayout || DictionaryEditor.mUseExternalSkin) {
                newLayout = Integer.valueOf(DEFAULT_LAYOUT_ID).intValue();
            }
            if (!DictionaryEditor.mUseCustomBackgrounColors && newLayout == THEMES.length - 1) {
                LatinKeyboard.mHintColor = -16777216;
            }
            DictionaryEditorUtil.GCUtils.getInstance().reset();
            boolean tryGC = true;
            for (int i = 0; i < 5 && tryGC; i++) {
                try {
                    this.mInputView = (LatinKeyboardView) this.mInputMethodService.getLayoutInflater().inflate(THEMES[newLayout], (ViewGroup) null);
                    tryGC = false;
                } catch (InflateException e) {
                    tryGC = DictionaryEditorUtil.GCUtils.getInstance().tryGCOrWait(String.valueOf(this.mLayoutId) + "," + newLayout, e);
                } catch (OutOfMemoryError e2) {
                    tryGC = DictionaryEditorUtil.GCUtils.getInstance().tryGCOrWait(String.valueOf(this.mLayoutId) + "," + newLayout, e2);
                }
            }
            Drawable d = getCustomBackdroundImage();
            if (d != null) {
                this.mInputView.setBackgroundDrawable(d);
                this.mInputView.getBackground().clearColorFilter();
            }
            if (DictionaryEditor.mUseExternalSkin) {
                if (d == null && DictionaryEditor.skinData.keyboard_background != null) {
                    this.mInputView.setBackgroundDrawable(DictionaryEditor.skinData.keyboard_background);
                }
                if (DictionaryEditor.skinData.btn_keyboard_key != null) {
                    this.mInputView.mKeyBackground = DictionaryEditor.skinData.btn_keyboard_key;
                }
            }
            if (d == null) {
                if (DictionaryEditor.mUseCustomBackgrounColors) {
                    this.mInputView.getBackground().setColorFilter(DictionaryEditor.getKeyboardBackgroundColor(), PorterDuff.Mode.MULTIPLY);
                } else {
                    if (!DictionaryEditor.mUseExternalSkin) {
                        PorterDuff.Mode mode = PorterDuff.Mode.MULTIPLY;
                    } else {
                        this.mInputView.getBackground().clearColorFilter();
                    }
                    LatinKeyboardBaseView.setSymbolColorScheme(0);
                }
            }
            if (this.mInputMethodService != null && this.mInputMethodService.mCandidateViewContainer != null) {
                if (!DictionaryEditor.mUseCustomSuggestionColors && DictionaryEditor.mUseExternalSkin && DictionaryEditor.skinData.candidate_background != null) {
                    this.mInputMethodService.mCandidateViewContainer.setBackgroundDrawable(DictionaryEditor.skinData.candidate_background);
                    this.mInputMethodService.mCandidateViewContainer.getBackground().clearColorFilter();
                } else if (DictionaryEditor.mUseCustomSuggestionColors) {
                    this.mInputMethodService.mCandidateViewContainer.getBackground().setColorFilter(DictionaryEditor.getSuggestionBarColor(), PorterDuff.Mode.MULTIPLY);
                } else {
                    this.mInputMethodService.mCandidateViewContainer.getBackground().setColorFilter(-16777216, PorterDuff.Mode.MULTIPLY);
                }
                this.mInputMethodService.mCandidateViewContainer.getBackground().invalidateSelf();
            }
            this.mInputView.setOnKeyboardActionListener(this.mInputMethodService);
            this.mLayoutId = newLayout;
        }
        this.mInputMethodService.mHandler.post(new Runnable() { // from class: com.android.inputmethod.latin.Calibration.1
            @Override // java.lang.Runnable
            public void run() {
                synchronized (Calibration.this.mInputMethodService) {
                    if (Calibration.this.mInputView != null && Calibration.this.mInputView.getParent() == null) {
                        Calibration.this.mInputMethodService.setInputView(Calibration.this.mInputView);
                    }
                }
                Calibration.this.mInputMethodService.updateInputViewShown();
            }
        });
    }

    @Override // android.content.SharedPreferences.OnSharedPreferenceChangeListener
    public void onSharedPreferenceChanged(SharedPreferences sharedPreferences, String key) {
        if (PREF_KEYBOARD_LAYOUT.equals(key)) {
            changeLatinKeyboardView(Integer.valueOf(sharedPreferences.getString(key, DEFAULT_LAYOUT_ID)).intValue(), false);
        } else if ("settings_key".equals(key)) {
            updateSettingsKeyState(sharedPreferences);
            recreateInputView();
        }
    }

    public boolean isBlackSym() {
        return this.mInputView != null && this.mInputView.getSymbolColorScheme() == 1;
    }

    private int getCharColorId() {
        return 0;
    }

    public void onAutoCompletionStateChanged(boolean isAutoCompletion) {
        if (isAutoCompletion != this.mIsAutoCompletionActive) {
            LatinKeyboardView keyboardView = getInputView();
            this.mIsAutoCompletionActive = isAutoCompletion;
            keyboardView.invalidateKey(((LatinKeyboard) keyboardView.getKeyboard()).onAutoCompletionStateChanged(isAutoCompletion));
        }
    }

    private void updateSettingsKeyState(SharedPreferences prefs) {
        Resources resources = this.mInputMethodService.getResources();
        String settingsKeyMode = prefs.getString("settings_key", resources.getString(R.string.settings_key_mode_always_hide));
        if (settingsKeyMode.equals(resources.getString(R.string.settings_key_mode_always_show)) || (settingsKeyMode.equals(resources.getString(R.string.settings_key_mode_auto)) && DictionaryEditorUtil.hasMultipleEnabledIMEs(this.mInputMethodService))) {
            this.mHasSettingsKey = true;
        } else {
            this.mHasSettingsKey = false;
        }
    }

    public void LoadKeyboardLayout(SharedPreferences sp) {
        this.mUriImage = sp.getString(PREF_URI_BACKGROUND_IMAGE, LoggingEvents.EXTRA_CALLING_APP_NAME);
        this.mUseCustomeImage = sp.getBoolean(PREF_USE_CUSTOM_IMAGTE, false);
        this.mRowGapHorizontal = sp.getInt(PREF_ROW_GAP_HORIZONTAL, 100);
        this.mRowGapVertical = sp.getInt(PREF_ROW_GAP_VERTICAL, 150);
        this.mKeyHightHorizontal = sp.getInt(PREF_KEY_HIGHT_HORIZONTAL, 100);
        this.mKeyHightVertical = sp.getInt(PREF_KEY_HIGHT_VERTICAL, 100);
        this.mArrowsKeyHightHorizontal = sp.getInt(PREF_ARROWS_KEY_HIGHT_HORIZONTAL, 100);
        this.mArrowsKeyHightVertical = sp.getInt(PREF_ARROWS_KEY_HIGHT_VERTICAL, 90);
        this.mTextSizeHorizontal = sp.getInt(PREF_TEXT_SIZE_HORIZONTAL, 100);
        this.mTextSizeVertical = sp.getInt(PREF_TEXT_SIZE_VERTICAL, 100);
        this.mBottomPaddingHorizontal = sp.getInt(PREF_BOTTOM_PADDING_HORIZONTAL, 100);
        this.mBottomPaddingVertical = sp.getInt(PREF_BOTTOM_PADDING_VERTICAL, 20);
        this.mHebrewAlt = sp.getBoolean(PREF_HEBREW_ALT_LAYOUT, this.mInputMethodService.getResources().getBoolean(R.bool.bool_hebrew_alt_layout));
        this.mCzechFull = sp.getBoolean(PREF_CZECH_FULL_LAYOUT, this.mInputMethodService.getResources().getBoolean(R.bool.bool_czech_full_layout));
        mEnableNumberKeypad = sp.getBoolean(PREF_ENABLE_NUMBER_KEYPAD, false);
        mDisplayAltLables = sp.getBoolean(PREF_DISPLAY_ALT_LABELS, true);
        String landscape_layout = sp.getString(PREF_LANDSCAPE_LAYOUT, this.mInputMethodService.getResources().getString(R.string.layout_landscape_default_mode_normal));
        mLandscapeLayoutMode = 0;
        if (landscape_layout.equals(this.mInputMethodService.getResources().getString(R.string.layout_landscape_default_mode_split))) {
            mLandscapeLayoutMode = 1;
        }
        String layout = sp.getString(PREF_PORTRAIT_LAYOUT, this.mInputMethodService.getResources().getString(R.string.layout_default_mode_normal));
        if (layout.equals(this.mInputMethodService.getResources().getString(R.string.layout_default_mode_normal))) {
            mPortaraitLayoutMode = 0;
            mIsPortraitModeAndT9 = false;
        } else if (layout.equals(this.mInputMethodService.getResources().getString(R.string.layout_default_mode_t9))) {
            mPortaraitLayoutMode = 1;
        } else if (layout.equals(this.mInputMethodService.getResources().getString(R.string.layout_default_mode_compact))) {
            mPortaraitLayoutMode = 2;
        } else if (layout.equals(this.mInputMethodService.getResources().getString(R.string.layout_default_mode_split))) {
            mPortaraitLayoutMode = 3;
        }
        LatinKeyboard.mHintColor = -1;
        boolean mUseCustomBackgrounColors = sp.getBoolean(PREF_BACKGROUND_CUSTOM_KEY, this.mInputMethodService.getResources().getBoolean(R.bool.pref_background_custom));
        if (mUseCustomBackgrounColors) {
            String fontHintColor = sp.getString(PREF_KB_HINT_FONT_COLOR, this.mInputMethodService.getResources().getString(R.string.hint_symbol_white));
            if (fontHintColor.equals(this.mInputMethodService.getResources().getString(R.string.hint_symbol_white))) {
                LatinKeyboard.mHintColor = -1;
            } else if (fontHintColor.equals(this.mInputMethodService.getResources().getString(R.string.hint_symbol_black))) {
                LatinKeyboard.mHintColor = -16777216;
            }
        }
        LatinKeyboardBaseView.setSymbolColorScheme(0);
        mFontSymbolColors = -1;
        if (mUseCustomBackgrounColors) {
            mFontSymbolColors = sp.getInt(PREF_KB_FONT_COLOR, -1);
            if (mFontSymbolColors != -1) {
                LatinKeyboardBaseView.setSymbolColorScheme(1);
            }
        }
        updateKeyboardConfiguration();
    }

    public void updateKeyboardConfiguration() {
        Configuration conf = this.mInputMethodService.getResources().getConfiguration();
        if (conf.orientation == 2) {
            LatinKeyboardBaseView.mTextSize = this.mTextSizeHorizontal;
            LatinKeyboard.mBottomPadding = this.mBottomPaddingHorizontal;
            LatinKeyboard.mKeyHight = Math.max(10, this.mKeyHightHorizontal);
            LatinKeyboard.mRowGap = this.mRowGapHorizontal;
            LatinKeyboard.mArrowsHight = this.mArrowsKeyHightHorizontal;
            mIsPortraitModeAndT9 = false;
        }
        if (conf.orientation == 1) {
            LatinKeyboardBaseView.mTextSize = this.mTextSizeVertical;
            LatinKeyboard.mBottomPadding = this.mBottomPaddingVertical;
            LatinKeyboard.mKeyHight = Math.max(10, this.mKeyHightVertical);
            LatinKeyboard.mRowGap = this.mRowGapVertical;
            LatinKeyboard.mArrowsHight = this.mArrowsKeyHightVertical;
        }
    }

    public boolean isPortraitMode() {
        Configuration conf = this.mInputMethodService.getResources().getConfiguration();
        return conf.orientation == 1;
    }

    public static boolean isT9orCompatMode() {
        return mIsPortraitModeAndT9 && mPortaraitLayoutMode != 0;
    }

    public boolean LoadKeyboardLayoutChanged(SharedPreferences sp, String key) {
        boolean changed = false;
        updateKeyboardConfiguration();
        if (key.equals(PREF_PORTRAIT_LAYOUT)) {
            String layout = sp.getString(PREF_PORTRAIT_LAYOUT, this.mInputMethodService.getResources().getString(R.string.layout_default_mode_normal));
            if (layout.equals(this.mInputMethodService.getResources().getString(R.string.layout_default_mode_normal))) {
                mPortaraitLayoutMode = 0;
                mIsPortraitModeAndT9 = false;
            } else if (layout.equals(this.mInputMethodService.getResources().getString(R.string.layout_default_mode_t9))) {
                mPortaraitLayoutMode = 1;
            } else if (layout.equals(this.mInputMethodService.getResources().getString(R.string.layout_default_mode_compact))) {
                mPortaraitLayoutMode = 2;
            } else if (layout.equals(this.mInputMethodService.getResources().getString(R.string.layout_default_mode_split))) {
                mPortaraitLayoutMode = 3;
            }
            changed = true;
        }
        if (key.equals(PREF_URI_BACKGROUND_IMAGE)) {
            this.mUriImage = sp.getString(PREF_URI_BACKGROUND_IMAGE, LoggingEvents.EXTRA_CALLING_APP_NAME);
            changed = true;
        }
        if (key.equals(PREF_USE_CUSTOM_IMAGTE)) {
            this.mUseCustomeImage = sp.getBoolean(PREF_USE_CUSTOM_IMAGTE, false);
            changed = true;
        }
        if (key.equals(PREF_LANDSCAPE_LAYOUT)) {
            String landscape_layout = sp.getString(PREF_LANDSCAPE_LAYOUT, this.mInputMethodService.getResources().getString(R.string.layout_landscape_default_mode_normal));
            mLandscapeLayoutMode = 0;
            if (landscape_layout.equals(this.mInputMethodService.getResources().getString(R.string.layout_landscape_default_mode_split))) {
                mLandscapeLayoutMode = 1;
            }
            changed = true;
        }
        if (key.equals(PREF_KB_HINT_FONT_COLOR)) {
            String fontHintColor = sp.getString(PREF_KB_HINT_FONT_COLOR, this.mInputMethodService.getResources().getString(R.string.hint_symbol_white));
            if (fontHintColor.equals(this.mInputMethodService.getResources().getString(R.string.hint_symbol_white))) {
                LatinKeyboard.mHintColor = -1;
            } else if (fontHintColor.equals(this.mInputMethodService.getResources().getString(R.string.hint_symbol_black))) {
                LatinKeyboard.mHintColor = -16777216;
            }
            changed = true;
        }
        if (key.equals(PREF_KB_FONT_COLOR)) {
            LatinKeyboardBaseView.setSymbolColorScheme(0);
            mFontSymbolColors = sp.getInt(PREF_KB_FONT_COLOR, -1);
            if (mFontSymbolColors != -1) {
                LatinKeyboardBaseView.setSymbolColorScheme(1);
            }
        }
        if (key.equals(PREF_ARROWS_KEY_HIGHT_HORIZONTAL)) {
            changed = true;
            this.mArrowsKeyHightHorizontal = sp.getInt(PREF_ARROWS_KEY_HIGHT_HORIZONTAL, 100);
        }
        if (key.equals(PREF_ARROWS_KEY_HIGHT_VERTICAL)) {
            changed = true;
            this.mArrowsKeyHightVertical = sp.getInt(PREF_ARROWS_KEY_HIGHT_VERTICAL, 90);
        }
        if (key.equals(PREF_ROW_GAP_HORIZONTAL)) {
            changed = true;
            this.mRowGapHorizontal = sp.getInt(PREF_ROW_GAP_HORIZONTAL, 100);
        } else if (key.equals(PREF_ROW_GAP_VERTICAL)) {
            changed = true;
            this.mRowGapVertical = sp.getInt(PREF_ROW_GAP_VERTICAL, 150);
        }
        if (key.equals(PREF_KEY_HIGHT_HORIZONTAL)) {
            changed = true;
            this.mKeyHightHorizontal = sp.getInt(PREF_KEY_HIGHT_HORIZONTAL, 100);
        }
        if (key.equals(PREF_KEY_HIGHT_VERTICAL)) {
            changed = true;
            this.mKeyHightVertical = sp.getInt(PREF_KEY_HIGHT_VERTICAL, 100);
        }
        if (key.equals(PREF_TEXT_SIZE_HORIZONTAL)) {
            changed = true;
            this.mTextSizeHorizontal = sp.getInt(PREF_TEXT_SIZE_HORIZONTAL, 100);
        }
        if (key.equals(PREF_TEXT_SIZE_VERTICAL)) {
            changed = true;
            this.mTextSizeVertical = sp.getInt(PREF_TEXT_SIZE_VERTICAL, 100);
        }
        if (key.equals(PREF_BOTTOM_PADDING_HORIZONTAL)) {
            changed = true;
            this.mBottomPaddingHorizontal = sp.getInt(PREF_BOTTOM_PADDING_HORIZONTAL, 100);
        }
        if (key.equals(PREF_BOTTOM_PADDING_VERTICAL)) {
            changed = true;
            this.mBottomPaddingVertical = sp.getInt(PREF_BOTTOM_PADDING_VERTICAL, 20);
        }
        if (key.equals(PREF_HEBREW_ALT_LAYOUT)) {
            this.mHebrewAlt = sp.getBoolean(PREF_HEBREW_ALT_LAYOUT, this.mInputMethodService.getResources().getBoolean(R.bool.bool_hebrew_alt_layout));
        }
        if (key.equals(PREF_CZECH_FULL_LAYOUT)) {
            this.mCzechFull = sp.getBoolean(PREF_CZECH_FULL_LAYOUT, this.mInputMethodService.getResources().getBoolean(R.bool.bool_czech_full_layout));
        }
        if (key.equals(PREF_ENABLE_NUMBER_KEYPAD)) {
            mEnableNumberKeypad = sp.getBoolean(PREF_ENABLE_NUMBER_KEYPAD, false);
        }
        if (key.equals(PREF_DISPLAY_ALT_LABELS)) {
            mDisplayAltLables = sp.getBoolean(PREF_DISPLAY_ALT_LABELS, true);
        }
        updateKeyboardConfiguration();
        return changed;
    }

    public Keyboard getCurrentKeyboard() {
        return getInputView().getKeyboard();
    }

    private Drawable getCustomBackdroundImage() {
        if (this.mUriImage == LoggingEvents.EXTRA_CALLING_APP_NAME || !this.mUseCustomeImage) {
            return null;
        }
        try {
            Bitmap bitmap = decodeUri(this.mUriImage);
            Drawable d = new BitmapDrawable(bitmap);
            return d;
        } catch (FileNotFoundException e) {
            e.printStackTrace();
            return null;
        }
    }

    private Bitmap decodeUri(String selectedImageString) throws FileNotFoundException {
        Uri selectedImage = Uri.parse(selectedImageString);
        BitmapFactory.Options o = new BitmapFactory.Options();
        o.inJustDecodeBounds = true;
        Context context = this.mInputMethodService.getApplicationContext();
        BitmapFactory.decodeStream(context.getContentResolver().openInputStream(selectedImage), null, o);
        int width_tmp = o.outWidth;
        int height_tmp = o.outHeight;
        int scale = 1;
        while (width_tmp / 2 >= 140 && height_tmp / 2 >= 140) {
            width_tmp /= 2;
            height_tmp /= 2;
            scale *= 2;
        }
        BitmapFactory.Options o2 = new BitmapFactory.Options();
        o2.inSampleSize = 1;
        try {
            Bitmap returnBitmap = BitmapFactory.decodeStream(context.getContentResolver().openInputStream(selectedImage), null, o2);
            return returnBitmap;
        } catch (OutOfMemoryError e) {
            o2.inSampleSize = scale;
            Bitmap returnBitmap2 = BitmapFactory.decodeStream(context.getContentResolver().openInputStream(selectedImage), null, o2);
            return returnBitmap2;
        }
    }

    public LatinKeyboard getKeyboard() {
        return getKeyboard(this.mCurrentId);
    }
}
