package com.android.inputmethod.latin;

import com.android.inputmethod.latin.Dictionary;
import java.util.Collection;
import java.util.Collections;
import java.util.List;
import java.util.concurrent.CopyOnWriteArrayList;

/* loaded from: classes.dex */
public class DictionaryCollection extends Dictionary {
    protected final List<Dictionary> mDictionaries;

    public DictionaryCollection() {
        this.mDictionaries = new CopyOnWriteArrayList();
    }

    public DictionaryCollection(Dictionary... dictionaries) {
        if (dictionaries == null) {
            this.mDictionaries = new CopyOnWriteArrayList();
        } else {
            this.mDictionaries = new CopyOnWriteArrayList(dictionaries);
            this.mDictionaries.removeAll(Collections.singleton(null));
        }
    }

    public DictionaryCollection(Collection<Dictionary> dictionaries) {
        this.mDictionaries = new CopyOnWriteArrayList(dictionaries);
        this.mDictionaries.removeAll(Collections.singleton(null));
    }

    @Override // com.android.inputmethod.latin.Dictionary
    public void getWords(WordComposer composer, Dictionary.WordCallback callback, ProximityInfo proximityInfo) {
        for (Dictionary dict : this.mDictionaries) {
            dict.getWords(composer, callback, proximityInfo);
        }
    }

    @Override // com.android.inputmethod.latin.Dictionary
    public void getBigrams(WordComposer composer, CharSequence previousWord, Dictionary.WordCallback callback) {
        for (Dictionary dict : this.mDictionaries) {
            dict.getBigrams(composer, previousWord, callback);
        }
    }

    @Override // com.android.inputmethod.latin.Dictionary
    public boolean isValidWord(CharSequence word) {
        for (int i = this.mDictionaries.size() - 1; i >= 0; i--) {
            if (this.mDictionaries.get(i).isValidWord(word)) {
                return true;
            }
        }
        return false;
    }

    @Override // com.android.inputmethod.latin.Dictionary
    public void close() {
        for (Dictionary dict : this.mDictionaries) {
            dict.close();
        }
    }

    public void addDictionary(Dictionary newDict) {
        if (newDict != null) {
            this.mDictionaries.add(newDict);
        }
    }
}
