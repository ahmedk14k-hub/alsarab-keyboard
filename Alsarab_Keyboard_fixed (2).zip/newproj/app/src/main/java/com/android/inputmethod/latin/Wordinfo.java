package com.android.inputmethod.latin;

import android.content.Context;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.content.pm.ResolveInfo;
import android.graphics.drawable.Drawable;
import android.util.Log;
import com.android.common.speech.LoggingEvents;
import java.util.ArrayList;
import java.util.List;

/* loaded from: classes.dex */
public class Wordinfo {
    public static final String RECEIVER_INTERFACE = "com.betterandroid.betterkeyboard.skins";
    private static final String TAG = "SkinLoader";
    private static String m;
    private static ArrayList<SkinInfo> skin_creators;

    /* compiled from: LoadSkins.java */
    /* loaded from: classes.dex */
    public static class SkinData {
        public Drawable candidate_background;
        public Drawable btn_keyboard_key = null;
        public Drawable btn_keyboard_key_alt = null;
        public Drawable keyboard_key_feedback = null;
        public Drawable keyboard_background = null;
        public int shadow_color2 = -1;
        public int text_color2 = 0;
        public int shadow_color = -1;
        public int text_color = 0;
        public int suggestion_color = 0;

        SkinData() {
        }
    }

    /* compiled from: LoadSkins.java */
    /* loaded from: classes.dex */
    public static class SkinInfo {
        private String mDescription;
        private Context mPackageContext;

        public String getSkinName() {
            return this.mDescription;
        }

        public Context getPackageContext() {
            return this.mPackageContext;
        }
    }

    private static synchronized SkinData getSkinByActivityInfo(Context context) {
        SkinData skin;
        String str = "btn_keyboard_key";
        String str2 = "btn_keyboard_key_alt";
        String str3 = "keyboard_background";
        int w = context.getResources().getIdentifier(LoggingEvents.EXTRA_APP_NAME, "string", context.getPackageName());
        String r = context.getResources().getString(w);
        if (r.startsWith("Alsarab")) {
            str = "btn_1";
            str2 = "btn_2";
            str3 = "kb";
        }
        synchronized (Wordinfo.class) {
            skin = new SkinData();
            int resid = context.getResources().getIdentifier(str, "drawable", context.getPackageName());
            if (resid != 0) {
                skin.btn_keyboard_key = context.getResources().getDrawable(resid);
            }
            int resid2 = context.getResources().getIdentifier(str2, "drawable", context.getPackageName());
            if (resid2 != 0) {
                skin.btn_keyboard_key_alt = context.getResources().getDrawable(resid2);
            }
            int resid3 = context.getResources().getIdentifier("keyboard_key_feedback", "drawable", context.getPackageName());
            if (resid3 != 0) {
                skin.keyboard_key_feedback = context.getResources().getDrawable(resid3);
            }
            int resid4 = context.getResources().getIdentifier(str3, "drawable", context.getPackageName());
            if (resid4 != 0) {
                skin.keyboard_background = context.getResources().getDrawable(resid4);
            }
            int resid5 = context.getResources().getIdentifier("keyboard_suggest_strip", "drawable", context.getPackageName());
            if (resid5 != 0) {
                skin.candidate_background = context.getResources().getDrawable(resid5);
            }
            int resid6 = context.getResources().getIdentifier("text_color", "color", context.getPackageName());
            if (resid6 != 0) {
                skin.text_color = context.getResources().getColor(resid6);
            }
            int resid7 = context.getResources().getIdentifier("shadow_color", "color", context.getPackageName());
            if (resid7 != 0) {
                skin.shadow_color = context.getResources().getColor(resid7);
            }
            int resid8 = context.getResources().getIdentifier("text_color2", "color", context.getPackageName());
            if (resid8 != 0) {
                skin.text_color2 = context.getResources().getColor(resid8);
            }
            int resid9 = context.getResources().getIdentifier("shadow_color2", "color", context.getPackageName());
            if (resid9 != 0) {
                skin.shadow_color2 = context.getResources().getColor(resid9);
            }
            int resid10 = context.getResources().getIdentifier("suggestion_color", "color", context.getPackageName());
            if (resid10 != 0) {
                skin.suggestion_color = context.getResources().getColor(resid10);
            }
        }
        return skin;
    }

    private static ArrayList<SkinInfo> getAllSkins(Context context) {
        List<ResolveInfo> broadcastReceivers = context.getPackageManager().queryIntentActivities(new Intent(m), 0);
        if (DictionaryEditor.DEBUG) {
            Log.d(TAG, "Number of potential external themes packages found: " + broadcastReceivers.size());
        }
        ArrayList<SkinInfo> externalSkins = new ArrayList<>();
        for (ResolveInfo receiver : broadcastReceivers) {
            if (receiver.activityInfo == null) {
                Log.e(TAG, "BroadcastReceiver has null ActivityInfo. Receiver's label is " + ((Object) receiver.loadLabel(context.getPackageManager())));
            } else {
                try {
                    Context externalPackageContext = context.createPackageContext(receiver.activityInfo.packageName, 0);
                    int resid = externalPackageContext.getResources().getIdentifier("newformat2", "bool", externalPackageContext.getPackageName());
                    if (resid != 0) {
                        boolean newFormat = externalPackageContext.getResources().getBoolean(resid);
                        if (!newFormat) {
                        }
                    }
                    SkinInfo skininfo = new SkinInfo();
                    skininfo.mPackageContext = externalPackageContext;
                    if (receiver.activityInfo.labelRes != 0) {
                        skininfo.mDescription = externalPackageContext.getResources().getString(receiver.activityInfo.labelRes);
                    }
                    externalSkins.add(skininfo);
                } catch (PackageManager.NameNotFoundException e) {
                    Log.e(TAG, "Did not find package: " + receiver.activityInfo.packageName);
                }
            }
        }
        if (DictionaryEditor.DEBUG) {
            Log.d(TAG, "Number of external dictionary builders successfully parsed: " + externalSkins.size());
        }
        return externalSkins;
    }

    public static SkinData getSkinDataByName(String skinName) {
        if (skin_creators != null) {
            int size = skin_creators.size();
            for (int i = 0; i < size; i++) {
                SkinInfo skininfo = skin_creators.get(i);
                if (skininfo.getSkinName().equals(skinName)) {
                    return getSkinByActivityInfo(skininfo.getPackageContext());
                }
            }
        }
        return null;
    }

    public static ArrayList<String> getSkinsNames() {
        ArrayList<String> skins = new ArrayList<>();
        int size = skin_creators.size();
        for (int i = 0; i < size; i++) {
            skins.add(skin_creators.get(i).mDescription);
        }
        return skins;
    }

    public static synchronized void resetBuildersCache() {
        synchronized (Wordinfo.class) {
            skin_creators = null;
        }
    }

    public static synchronized ArrayList<SkinInfo> getAllBuilders(Context context) {
        ArrayList<SkinInfo> arrayList;
        synchronized (Wordinfo.class) {
            if (skin_creators == null) {
                ArrayList<SkinInfo> skins = new ArrayList<>();
                m = RECEIVER_INTERFACE;
                skins.addAll(getAllSkins(context));
                m = "com.sarab.keyboard.skins";
                skins.addAll(getAllSkins(context));
                skin_creators = skins;
            }
            arrayList = skin_creators;
        }
        return arrayList;
    }
}
