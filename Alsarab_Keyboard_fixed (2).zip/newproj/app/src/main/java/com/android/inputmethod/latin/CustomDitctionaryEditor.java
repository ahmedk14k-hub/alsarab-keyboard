package com.android.inputmethod.latin;

import android.app.AlertDialog;
import android.app.ListActivity;
import android.content.ContentResolver;
import android.content.ContentValues;
import android.content.Context;
import android.content.DialogInterface;
import android.content.SharedPreferences;
import android.database.Cursor;
import android.os.Bundle;
import android.preference.PreferenceManager;
import android.provider.UserDictionary;
import android.view.ContextMenu;
import android.view.LayoutInflater;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AdapterView;
import android.widget.Filterable;
import android.widget.ListAdapter;
import android.widget.SimpleCursorAdapter;
import android.widget.TextView;
import com.android.common.speech.LoggingEvents;
import inputmethod.latin.perfectkeyboard.R;

/* loaded from: classes.dex */
public class CustomDitctionaryEditor extends ListActivity {
    private static final int ADD_ID = 2;
    private static final int DELETE_ID = 4;
    private static final int EDIT_ID = 3;
    private static final String[] PROJECTION = {"_id", "word", LoggingEvents.VoiceIme.EXTRA_START_LOCALE};
    private Cursor constantsCursor = null;

    @Override // android.app.Activity
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        ContentResolver cr = getContentResolver();
        this.constantsCursor = cr.query(UserDictionary.Words.CONTENT_URI, PROJECTION, null, null, "word");
        ListAdapter adapter = new AutoTextCursorAdapter(this, R.layout.row, this.constantsCursor, new String[]{"word", LoggingEvents.VoiceIme.EXTRA_START_LOCALE}, new int[]{R.id.theword, R.id.thelocale});
        setContentView(R.layout.edit_userdict_list);
        setListAdapter(adapter);
        registerForContextMenu(getListView());
    }

    @Override // android.app.Activity
    public void onPause() {
        super.onPause();
        this.constantsCursor.deactivate();
    }

    @Override // android.app.Activity
    protected void onResume() {
        this.constantsCursor.requery();
        super.onResume();
    }

    @Override // android.app.ListActivity, android.app.Activity
    public void onDestroy() {
        super.onDestroy();
    }

    @Override // android.app.Activity
    public boolean onCreateOptionsMenu(Menu menu) {
        menu.add(0, 2, 0, "اضافة").setIcon(android.R.drawable.ic_menu_add).setAlphabeticShortcut('a');
        return super.onCreateOptionsMenu(menu);
    }

    @Override // android.app.Activity
    public boolean onOptionsItemSelected(MenuItem item) {
        switch (item.getItemId()) {
            case 2:
                add();
                return true;
            default:
                return super.onOptionsItemSelected(item);
        }
    }

    @Override // android.app.Activity, android.view.View.OnCreateContextMenuListener
    public void onCreateContextMenu(ContextMenu menu, View v, ContextMenu.ContextMenuInfo menuInfo) {
        menu.add(0, 4, 0, "مسح").setAlphabeticShortcut('d');
        menu.add(0, 3, 0, "تحرير").setAlphabeticShortcut('e');
    }

    @Override // android.app.Activity
    public boolean onContextItemSelected(MenuItem item) {
        switch (item.getItemId()) {
            case 3:
                AdapterView.AdapterContextMenuInfo info = (AdapterView.AdapterContextMenuInfo) item.getMenuInfo();
                edit(info.id);
                return true;
            case 4:
                AdapterView.AdapterContextMenuInfo info2 = (AdapterView.AdapterContextMenuInfo) item.getMenuInfo();
                delete(info2.id);
                return true;
            default:
                return super.onOptionsItemSelected(item);
        }
    }

    private void add() {
        LayoutInflater inflater = LayoutInflater.from(this);
        View addView = inflater.inflate(R.layout.add_edit_userdict, (ViewGroup) null);
        final CustomDialogWrapper wrapper = new CustomDialogWrapper(addView);
        SharedPreferences sp = PreferenceManager.getDefaultSharedPreferences(this);
        String mSelectedLanguages = sp.getString(DictionaryEditor.PREF_INPUT_LANGUAGE, "en");
        new AlertDialog.Builder(this).setTitle(R.string.add_key).setView(addView).setPositiveButton(R.string.ok, new DialogInterface.OnClickListener() { // from class: com.android.inputmethod.latin.CustomDitctionaryEditor.1
            @Override // android.content.DialogInterface.OnClickListener
            public void onClick(DialogInterface dialog, int whichButton) {
                CustomDitctionaryEditor.this.processAdd(wrapper);
            }
        }).setNegativeButton(R.string.cancel, new DialogInterface.OnClickListener() { // from class: com.android.inputmethod.latin.CustomDitctionaryEditor.2
            @Override // android.content.DialogInterface.OnClickListener
            public void onClick(DialogInterface dialog, int whichButton) {
            }
        }).show();
        wrapper.localeField.setText(mSelectedLanguages);
    }

    private void edit(final long rowId) {
        LayoutInflater inflater = LayoutInflater.from(this);
        View editView = inflater.inflate(R.layout.add_edit_userdict, (ViewGroup) null);
        int keyCol = this.constantsCursor.getColumnIndex("word");
        int valueCol = this.constantsCursor.getColumnIndex(LoggingEvents.VoiceIme.EXTRA_START_LOCALE);
        String word = this.constantsCursor.getString(keyCol);
        String locale = this.constantsCursor.getString(valueCol);
        final CustomDialogWrapper wrapper = new CustomDialogWrapper(editView);
        new AlertDialog.Builder(this).setTitle(R.string.edit_key).setView(editView).setPositiveButton(R.string.ok, new DialogInterface.OnClickListener() { // from class: com.android.inputmethod.latin.CustomDitctionaryEditor.3
            @Override // android.content.DialogInterface.OnClickListener
            public void onClick(DialogInterface dialog, int whichButton) {
                CustomDitctionaryEditor.this.processEdit(wrapper, rowId);
            }
        }).setNegativeButton(R.string.cancel, new DialogInterface.OnClickListener() { // from class: com.android.inputmethod.latin.CustomDitctionaryEditor.4
            @Override // android.content.DialogInterface.OnClickListener
            public void onClick(DialogInterface dialog, int whichButton) {
            }
        }).show();
        wrapper.wordField.setText(word);
        wrapper.localeField.setText(locale);
    }

    /* JADX INFO: Access modifiers changed from: private */
    /* JADX WARN: Type inference failed for: r0v11, types: [com.android.inputmethod.latin.CustomDitctionaryEditor$5] */
    public void processEdit(CustomDialogWrapper wrapper, long rowId) {
        final String[] args = {String.valueOf(rowId)};
        if (!wrapper.getWord().equals(LoggingEvents.EXTRA_CALLING_APP_NAME)) {
            final ContentValues values = new ContentValues(5);
            values.put("word", wrapper.getWord());
            values.put("frequency", (Integer) 128);
            if (wrapper.getLocale().equals(LoggingEvents.EXTRA_CALLING_APP_NAME)) {
                values.putNull(LoggingEvents.VoiceIme.EXTRA_START_LOCALE);
            } else {
                values.put(LoggingEvents.VoiceIme.EXTRA_START_LOCALE, wrapper.getLocale());
            }
            values.put("appid", (Integer) 0);
            final ContentResolver contentResolver = getContentResolver();
            new Thread("editWord") { // from class: com.android.inputmethod.latin.CustomDitctionaryEditor.5
                @Override // java.lang.Thread, java.lang.Runnable
                public void run() {
                    contentResolver.update(UserDictionary.Words.CONTENT_URI, values, "_ID=?", args);
                }
            }.start();
        }
    }

    private void delete(long rowId) {
        if (rowId > 0) {
            processDelete(rowId);
        }
    }

    /* JADX INFO: Access modifiers changed from: private */
    /* JADX WARN: Type inference failed for: r2v9, types: [com.android.inputmethod.latin.CustomDitctionaryEditor$6] */
    public void processAdd(CustomDialogWrapper wrapper) {
        if (!wrapper.getWord().equals(LoggingEvents.EXTRA_CALLING_APP_NAME)) {
            final ContentValues values = new ContentValues(5);
            values.put("word", wrapper.getWord());
            values.put("frequency", (Integer) 128);
            if (wrapper.getLocale().equals(LoggingEvents.EXTRA_CALLING_APP_NAME)) {
                values.putNull(LoggingEvents.VoiceIme.EXTRA_START_LOCALE);
            } else {
                values.put(LoggingEvents.VoiceIme.EXTRA_START_LOCALE, wrapper.getLocale());
            }
            values.put("appid", (Integer) 0);
            final ContentResolver contentResolver = getContentResolver();
            new Thread("addWord") { // from class: com.android.inputmethod.latin.CustomDitctionaryEditor.6
                @Override // java.lang.Thread, java.lang.Runnable
                public void run() {
                    contentResolver.insert(UserDictionary.Words.CONTENT_URI, values);
                }
            }.start();
        }
    }

    /* JADX WARN: Type inference failed for: r2v2, types: [com.android.inputmethod.latin.CustomDitctionaryEditor$7] */
    private void processDelete(long rowId) {
        final String[] args = {String.valueOf(rowId)};
        final ContentResolver contentResolver = getContentResolver();
        new Thread("deleteWord") { // from class: com.android.inputmethod.latin.CustomDitctionaryEditor.7
            @Override // java.lang.Thread, java.lang.Runnable
            public void run() {
                contentResolver.delete(UserDictionary.Words.CONTENT_URI, "_ID=?", args);
            }
        }.start();
    }

    /* loaded from: classes.dex */
    public class AutoTextCursorAdapter extends SimpleCursorAdapter implements Filterable {
        private Context context;
        private int layout;

        public AutoTextCursorAdapter(Context context, int layout, Cursor c, String[] from, int[] to) {
            super(context, layout, c, from, to);
            this.context = context;
            this.layout = layout;
        }

        @Override // android.widget.ResourceCursorAdapter, android.widget.CursorAdapter
        public View newView(Context context, Cursor cursor, ViewGroup parent) {
            Cursor c = getCursor();
            LayoutInflater inflater = LayoutInflater.from(context);
            View v = inflater.inflate(this.layout, parent, false);
            int keyCol = c.getColumnIndex("word");
            int valueCol = c.getColumnIndex(LoggingEvents.VoiceIme.EXTRA_START_LOCALE);
            String string = String.valueOf(c.getString(keyCol)) + "->" + c.getString(valueCol);
            TextView name_text = (TextView) v.findViewById(R.id.theword);
            if (name_text != null) {
                name_text.setText(string);
            }
            return v;
        }

        @Override // android.widget.SimpleCursorAdapter, android.widget.CursorAdapter
        public void bindView(View v, Context context, Cursor c) {
            int keyCol = c.getColumnIndex("word");
            int valueCol = c.getColumnIndex(LoggingEvents.VoiceIme.EXTRA_START_LOCALE);
            String string = String.valueOf(c.getString(keyCol)) + " (" + c.getString(valueCol) + ")";
            TextView name_text = (TextView) v.findViewById(R.id.key);
            if (name_text != null) {
                name_text.setText(string);
            }
        }

        @Override // android.widget.CursorAdapter
        public Cursor runQueryOnBackgroundThread(CharSequence constraint) {
            if (getFilterQueryProvider() != null) {
                return getFilterQueryProvider().runQuery(constraint);
            }
            StringBuilder buffer = null;
            String[] args = null;
            if (constraint != null) {
                buffer = new StringBuilder();
                buffer.append("UPPER(");
                buffer.append(LoggingEvents.VoiceIme.EXTRA_START_LOCALE);
                buffer.append(") GLOB ?");
                args = new String[]{String.valueOf(constraint.toString().toUpperCase()) + "*"};
            }
            return this.context.getContentResolver().query(UserDictionary.Words.CONTENT_URI, null, buffer == null ? null : buffer.toString(), args, "word ASC");
        }
    }
}
