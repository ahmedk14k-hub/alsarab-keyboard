package com.google.android.voiceime;

import android.inputmethodservice.InputMethodService;
import android.os.Build;
import android.view.inputmethod.InputMethodInfo;
import android.view.inputmethod.InputMethodManager;
import android.view.inputmethod.InputMethodSubtype;
import java.util.List;
import java.util.Map;

/* loaded from: classes.dex */
class ImeTrigger implements Trigger {
    private static final String VOICE_IME_PACKAGE_PREFIX = "com.google.android";
    private static final String VOICE_IME_SUBTYPE_MODE = "voice";
    private final InputMethodService mInputMethodService;

    public ImeTrigger(InputMethodService inputMethodService) {
        this.mInputMethodService = inputMethodService;
    }

    @Override // com.google.android.voiceime.Trigger
    public void startVoiceRecognition(String language) {
        InputMethodManager inputMethodManager = getInputMethodManager(this.mInputMethodService);
        InputMethodInfo inputMethodInfo = getVoiceImeInputMethodInfo(inputMethodManager);
        if (inputMethodInfo != null) {
            inputMethodManager.setInputMethodAndSubtype(this.mInputMethodService.getWindow().getWindow().getAttributes().token, inputMethodInfo.getId(), getVoiceImeSubtype(inputMethodManager, inputMethodInfo));
        }
    }

    private static InputMethodManager getInputMethodManager(InputMethodService inputMethodService) {
        return (InputMethodManager) inputMethodService.getSystemService("input_method");
    }

    private InputMethodSubtype getVoiceImeSubtype(InputMethodManager inputMethodManager, InputMethodInfo inputMethodInfo) throws SecurityException, IllegalArgumentException {
        Map<InputMethodInfo, List<InputMethodSubtype>> map = inputMethodManager.getShortcutInputMethodsAndSubtypes();
        List<InputMethodSubtype> list = map.get(inputMethodInfo);
        if (list == null || list.size() <= 0) {
            return null;
        }
        return list.get(0);
    }

    private static InputMethodInfo getVoiceImeInputMethodInfo(InputMethodManager inputMethodManager) throws SecurityException, IllegalArgumentException {
        for (InputMethodInfo inputMethodInfo : inputMethodManager.getEnabledInputMethodList()) {
            for (int i = 0; i < inputMethodInfo.getSubtypeCount(); i++) {
                InputMethodSubtype subtype = inputMethodInfo.getSubtypeAt(i);
                if (VOICE_IME_SUBTYPE_MODE.equals(subtype.getMode()) && inputMethodInfo.getComponent().getPackageName().startsWith(VOICE_IME_PACKAGE_PREFIX)) {
                    return inputMethodInfo;
                }
            }
        }
        return null;
    }

    public static boolean isInstalled(InputMethodService inputMethodService) {
        InputMethodInfo inputMethodInfo;
        return Build.VERSION.SDK_INT >= 14 && (inputMethodInfo = getVoiceImeInputMethodInfo(getInputMethodManager(inputMethodService))) != null && inputMethodInfo.getSubtypeCount() > 0;
    }

    @Override // com.google.android.voiceime.Trigger
    public void onStartInputView() {
    }
}
