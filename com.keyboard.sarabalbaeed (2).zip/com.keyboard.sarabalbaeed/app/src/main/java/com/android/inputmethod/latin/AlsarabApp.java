package com.android.inputmethod.latin;

import android.app.Activity;
import android.app.Application;
import android.app.Dialog;
import android.graphics.Insets;
import android.os.Build;
import android.os.Bundle;
import android.util.TypedValue;
import android.view.View;
import android.view.ViewGroup;
import android.view.ViewTreeObserver;
import android.view.Window;
import android.view.WindowInsets;
import java.util.Map;
import java.util.WeakHashMap;

/** Keeps screens clear of the system bars on Android 15+ (edge-to-edge). */
public class AlsarabApp extends Application {
    private static final Map<Activity, Boolean> sDone = new WeakHashMap<Activity, Boolean>();

    @Override
    public void onCreate() {
        super.onCreate();
        if (Build.VERSION.SDK_INT >= 35) {
            registerActivityLifecycleCallbacks(new ActivityLifecycleCallbacks() {
                @Override public void onActivityStarted(Activity a) { applyInsets(a); }
                @Override public void onActivityCreated(Activity a, Bundle b) { }
                @Override public void onActivityResumed(Activity a) { }
                @Override public void onActivityPaused(Activity a) { }
                @Override public void onActivityStopped(Activity a) { }
                @Override public void onActivitySaveInstanceState(Activity a, Bundle b) { }
                @Override public void onActivityDestroyed(Activity a) { }
            });
        }
    }

    private static void applyInsets(final Activity a) {
        try {
            if (sDone.containsKey(a)) {
                return;
            }
            final ViewGroup content = (ViewGroup) a.findViewById(android.R.id.content);
            if (content == null) {
                return;
            }
            sDone.put(a, Boolean.TRUE);
            watch(a.getWindow(), a, content);
        } catch (Throwable ignored) {
        }
    }

    /** For sub-screens that Android shows as dialogs (nested preference screens). */
    public static void fixDialog(Dialog d) {
        try {
            if (Build.VERSION.SDK_INT < 35 || d == null || d.getWindow() == null) {
                return;
            }
            ViewGroup content = (ViewGroup) d.getWindow().getDecorView().findViewById(android.R.id.content);
            if (content != null) {
                watch(d.getWindow(), null, content);
            }
        } catch (Throwable ignored) {
        }
    }

    private static void watch(final Window window, final Activity act, final ViewGroup content) {
        final int[] changes = new int[1];
        content.getViewTreeObserver().addOnGlobalLayoutListener(new ViewTreeObserver.OnGlobalLayoutListener() {
            @Override
            public void onGlobalLayout() {
                if (changes[0] < 12 && fixPadding(window, act, content)) {
                    changes[0]++;
                }
            }
        });
        content.requestLayout();
    }

    /**
     * Moves the screen so its real first view (the list, or the root layout) starts right below the
     * title / action bar and ends above the navigation bar. It measures where the view really is,
     * so it works whatever the system did with the insets. Returns true if it changed anything.
     */
    private static boolean fixPadding(Window window, Activity act, ViewGroup content) {
        try {
            View decor = window.getDecorView();
            WindowInsets wi = decor.getRootWindowInsets();
            if (wi == null || content.getHeight() == 0 || content.getChildCount() == 0) {
                return false;
            }
            Insets bars = wi.getInsets(WindowInsets.Type.systemBars() | WindowInsets.Type.displayCutout());

            int topEdge = bars.top;
            if (act != null) {
                android.app.ActionBar bar = act.getActionBar();
                if (bar != null && bar.isShowing()) {
                    TypedValue tv = new TypedValue();
                    if (act.getTheme().resolveAttribute(android.R.attr.actionBarSize, tv, true)) {
                        topEdge = bars.top + TypedValue.complexToDimensionPixelSize(
                                tv.data, act.getResources().getDisplayMetrics());
                    } else {
                        topEdge = bars.top + (int) (56 * act.getResources().getDisplayMetrics().density);
                    }
                }
            }
            float dp = decor.getResources().getDisplayMetrics().density;
            int maxTop = bars.top + (int) (100 * dp);
            if (act == null) {
                View title = decor.findViewById(android.R.id.title);
                if (title != null && title.getVisibility() == View.VISIBLE && title.getHeight() > 0
                        && title.getParent() instanceof View) {
                    View box = (View) title.getParent();
                    if (box.getHeight() <= (int) (100 * dp)) {
                        int[] l = new int[2];
                        box.getLocationInWindow(l);
                        topEdge = Math.max(topEdge, l[1] + box.getHeight());
                    }
                }
            }
            int abId = decor.getResources().getIdentifier("action_bar_container", "id", "android");
            View ab = abId != 0 ? decor.findViewById(abId) : null;
            if (ab != null && ab.getVisibility() == View.VISIBLE && ab.getHeight() > 0) {
                int[] l = new int[2];
                ab.getLocationInWindow(l);
                topEdge = Math.max(topEdge, l[1] + ab.getHeight());
            }

            topEdge = Math.min(topEdge, maxTop);

            View target = content.findViewById(android.R.id.list);
            if (target == null || target.getHeight() == 0) {
                target = content.getChildAt(0);
            }
            int[] t = new int[2];
            target.getLocationInWindow(t);
            int targetTop = t[1];
            int targetBottom = targetTop + target.getHeight();

            int[] c = new int[2];
            content.getLocationInWindow(c);
            int cLeft = c[0];
            int cRight = cLeft + content.getWidth();

            int padTop = Math.max(0, content.getPaddingTop() + (topEdge - targetTop));
            int bottomEdge = decor.getHeight() - bars.bottom;
            int padBottom = Math.max(0, content.getPaddingBottom() + (targetBottom - bottomEdge));
            padTop = Math.min(padTop, maxTop);
            padBottom = Math.min(padBottom, bars.bottom + (int) (16 * dp));
            int padLeft = Math.max(0, bars.left - cLeft);
            int padRight = Math.max(0, cRight - (decor.getWidth() - bars.right));
            if (padLeft != content.getPaddingLeft() || padTop != content.getPaddingTop()
                    || padRight != content.getPaddingRight() || padBottom != content.getPaddingBottom()) {
                content.setPadding(padLeft, padTop, padRight, padBottom);
                return true;
            }
        } catch (Throwable ignored) {
        }
        return false;
    }
}
