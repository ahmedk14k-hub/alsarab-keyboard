package com.alsarab.keyboard;

import android.content.ClipboardManager;
import android.content.Context;
import android.inputmethodservice.InputMethodService;
import android.inputmethodservice.Keyboard;
import android.inputmethodservice.KeyboardView;
import android.view.View;
import android.view.inputmethod.InputConnection;

public class AlsarabIME extends InputMethodService implements KeyboardView.OnKeyboardActionListener {

    private static final int CODE_CLIPBOARD = -201;

    private KeyboardView keyboardView;
    private Keyboard arabicKeyboard;
    private Keyboard symbolsKeyboard;
    private boolean isSymbols = false;

    @Override
    public View onCreateInputView() {
        keyboardView = (KeyboardView) getLayoutInflater().inflate(R.layout.keyboard_view, null);
        arabicKeyboard = new Keyboard(this, R.xml.keyboard_arabic);
        symbolsKeyboard = new Keyboard(this, R.xml.keyboard_symbols);
        keyboardView.setKeyboard(arabicKeyboard);
        keyboardView.setOnKeyboardActionListener(this);
        return keyboardView;
    }

    @Override
    public void onKey(int primaryCode, int[] keyCodes) {
        InputConnection ic = getCurrentInputConnection();
        if (ic == null) {
            return;
        }

        switch (primaryCode) {
            case Keyboard.KEYCODE_DELETE:
                ic.deleteSurroundingText(1, 0);
                break;

            case Keyboard.KEYCODE_DONE:
                ic.commitText("\n", 1);
                break;

            case Keyboard.KEYCODE_MODE_CHANGE:
                isSymbols = !isSymbols;
                keyboardView.setKeyboard(isSymbols ? symbolsKeyboard : arabicKeyboard);
                break;

            case CODE_CLIPBOARD:
                ClipboardManager cm = (ClipboardManager) getSystemService(Context.CLIPBOARD_SERVICE);
                if (cm != null && cm.hasPrimaryClip() && cm.getPrimaryClip().getItemCount() > 0) {
                    CharSequence text = cm.getPrimaryClip().getItemAt(0).coerceToText(this);
                    if (text != null) {
                        ic.commitText(text, 1);
                    }
                }
                break;

            default:
                ic.commitText(String.valueOf((char) primaryCode), 1);
        }
    }

    @Override public void onPress(int primaryCode) { }
    @Override public void onRelease(int primaryCode) { }
    @Override public void onText(CharSequence text) { }
    @Override public void swipeLeft() { }
    @Override public void swipeRight() { }
    @Override public void swipeDown() { }
    @Override public void swipeUp() { }
}
