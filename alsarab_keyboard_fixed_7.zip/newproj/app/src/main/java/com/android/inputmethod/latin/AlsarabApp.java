package com.android.inputmethod.latin;

import android.app.Application;

/** Installs the crash recorder as early as possible (before any keyboard class is loaded). */
public class AlsarabApp extends Application {
    @Override
    public void onCreate() {
        super.onCreate();
        CrashGuard.install(this);
    }
}
