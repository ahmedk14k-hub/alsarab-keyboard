package com.android.inputmethod.latin;

import android.app.Activity;
import android.app.Application;
import android.graphics.Insets;
import android.os.Build;
import android.os.Bundle;
import android.view.View;
import android.view.WindowInsets;

/** Installs the crash recorder early, and keeps screens clear of the system bars on Android 15+ (edge-to-edge). */
public class AlsarabApp extends Application {
    @Override
    public void onCreate() {
        super.onCreate();
        CrashGuard.install(this);
        if (Build.VERSION.SDK_INT >= 35) {
            registerActivityLifecycleCallbacks(new ActivityLifecycleCallbacks() {
                @Override public void onActivityStarted(Activity a) { applyInsets(a); }
                @Override public void onActivityCreated(Activity a, Bundle b) { }
                @Override public void onActivityResumed(Activity a) { }
                @Override public void onActivityPaused(Activity a) { }
                @Override public void onActivityStopped(Activity a) { }
                @Override public void onActivitySaveInstanceState(Activity a, Bundle b) { }
                @Override public void onActivityDestroyed(Activity a) { }
            });
        }
    }

    private static void applyInsets(final Activity a) {
        try {
            View content = a.findViewById(android.R.id.content);
            if (content == null) {
                return;
            }
            final boolean hasActionBar = a.getActionBar() != null && a.getActionBar().isShowing();
            content.setOnApplyWindowInsetsListener(new View.OnApplyWindowInsetsListener() {
                @Override
                public WindowInsets onApplyWindowInsets(View v, WindowInsets insets) {
                    Insets i = insets.getInsets(WindowInsets.Type.systemBars() | WindowInsets.Type.displayCutout());
                    v.setPadding(i.left, hasActionBar ? 0 : i.top, i.right, i.bottom);
                    return WindowInsets.CONSUMED;
                }
            });
            content.requestApplyInsets();
        } catch (Throwable ignored) {
        }
    }
}
