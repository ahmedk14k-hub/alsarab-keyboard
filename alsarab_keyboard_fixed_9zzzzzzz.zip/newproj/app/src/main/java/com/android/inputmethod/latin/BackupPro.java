package com.android.inputmethod.latin;

import android.app.Activity;
import android.app.AlertDialog;
import android.content.DialogInterface;
import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.view.View;
import android.view.inputmethod.InputMethodManager;
import android.widget.TextView;
import inputmethod.latin.perfectkeyboard.R;

/* loaded from: classes.dex */
public class BackupPro extends Activity implements DialogInterface.OnClickListener {
    private View ChangeInputButton;
    private View enableKeyboardButton;
    private View removeiconButton;
    private View shareKeyboardButton;

    @Override // android.app.Activity
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.main_luncher);
        TextView textView1 = (TextView) findViewById(R.id.textView1);
        textView1.setText("كيبورد السراب البعيد  1.0 \n\n  ahmed dasem \n\n تلكرام: u200u \n\n رقمي: 07722927144");
        final String crash = CrashGuard.peek(this);
        if (crash != null) {
            TextView report = new TextView(this);
            report.setText(crash);
            report.setTextSize(10f);
            report.setTextIsSelectable(true);
            report.setPadding(24, 24, 24, 24);
            android.widget.ScrollView sv = new android.widget.ScrollView(this);
            sv.addView(report);
            new AlertDialog.Builder(this)
                    .setTitle("آخر خطأ بالكيبورد")
                    .setView(sv)
                    .setPositiveButton("مسح", new DialogInterface.OnClickListener() {
                        @Override
                        public void onClick(DialogInterface d, int w) {
                            CrashGuard.clear(BackupPro.this);
                        }
                    })
                    .setNegativeButton("إغلاق", null)
                    .show();
        }
        this.enableKeyboardButton = findViewById(R.id.enable_keyboard);
        this.enableKeyboardButton.setOnClickListener(new View.OnClickListener() { // from class: com.android.inputmethod.latin.BackupPro.1
            @Override // android.view.View.OnClickListener
            public void onClick(View v) {
                Intent intent = new Intent();
                intent.setClassName("com.android.settings", "com.android.settings.LanguageSettings");
                intent.setFlags(268435456);
                try {
                    BackupPro.this.startActivity(intent);
                } catch (Throwable th) {
                    try {
                        Intent intent2 = new Intent();
                        intent2.setClassName("com.android.settings.Settings$InputMethodConfigActivity", "com.android.settings.LanguageSettings");
                        intent2.setFlags(268435456);
                        BackupPro.this.startActivity(intent);
                    } catch (Throwable th2) {
                        AlertDialog.Builder builder = new AlertDialog.Builder(BackupPro.this);
                        builder.setMessage("Sorry,this shortcut doesn't work on your device.\nYou still can enable the keyboard by going to Settings / Language & keyboard / perfect Keyboard. \nWe will appreciate if you will let us know about this issue").setCancelable(false).setPositiveButton("Ok", new DialogInterface.OnClickListener() { // from class: com.android.inputmethod.latin.BackupPro.1.1
                            @Override // android.content.DialogInterface.OnClickListener
                            public void onClick(DialogInterface dialog, int id) {
                                dialog.cancel();
                            }
                        });
                        AlertDialog alert = builder.create();
                        alert.show();
                    }
                }
            }
        });
        this.ChangeInputButton = findViewById(R.id.switch_to_keyboard);
        this.ChangeInputButton.setOnClickListener(new View.OnClickListener() { // from class: com.android.inputmethod.latin.BackupPro.2
            @Override // android.view.View.OnClickListener
            public void onClick(View v) {
                ((InputMethodManager) BackupPro.this.getSystemService("input_method")).showInputMethodPicker();
            }
        });
        this.shareKeyboardButton = findViewById(R.id.share_keyboard);
        this.shareKeyboardButton.setOnClickListener(new View.OnClickListener() { // from class: com.android.inputmethod.latin.BackupPro.3
            @Override // android.view.View.OnClickListener
            public void onClick(View v) {
                Intent i = new Intent("android.intent.action.VIEW");
                i.setData(Uri.parse("https://ap9ap.com"));
                BackupPro.this.startActivity(i);
            }
        });
    }

    @Override // android.content.DialogInterface.OnClickListener
    public void onClick(DialogInterface arg0, int arg1) {
        for (int i = 0; i < 10; i = i + 1 + 1) {
        }
    }
}
