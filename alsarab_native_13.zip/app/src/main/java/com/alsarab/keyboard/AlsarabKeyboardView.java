package com.alsarab.keyboard;

import android.content.Context;
import android.graphics.Canvas;
import android.graphics.Paint;
import android.graphics.drawable.GradientDrawable;
import android.inputmethodservice.Keyboard;
import android.inputmethodservice.KeyboardView;
import android.os.Handler;
import android.os.Looper;
import android.os.SystemClock;
import android.util.AttributeSet;
import android.view.Gravity;
import android.view.HapticFeedbackConstants;
import android.view.MotionEvent;
import android.view.View;
import android.view.ViewGroup;
import android.widget.PopupWindow;
import android.widget.TextView;

import java.util.List;

/**
 * KeyboardView with extra gestures:
 *  - drag left/right on the space key: move the cursor
 *  - long-press the space key, then drag up/down: show / hide the numbers row
 *  - long-press the "." key: open the emoji panel
 */
public class AlsarabKeyboardView extends KeyboardView {

    public interface OnCursorDragListener {
        void onCursorMove(int steps);
    }

    public interface ExtraGestureListener {
        /** true = show numbers row (swipe up), false = hide it (swipe down). */
        void onNumbersRowToggle(boolean show);

        void onPeriodLongPress();

        /** Quick left/right swipe on the space key (like the language switch). */
        void onSpaceSwipe(boolean next);

        /** Small hint drawn at the corner of a key, or null. */
        String hintFor(int code);

        boolean hasAlternates(int code);

        /** Long press on a letter: x,y,w are the key rect in view coordinates. */
        void onKeyLongPress(int code, int x, int y, int w);
    }

    private static final int SPACE_CODE = 32;
    private static final int PERIOD_CODE = 46;
    private static final int DRAG_THRESHOLD_PX = 28;
    private int longPressMs = 400;

    private final Handler handler = new Handler(Looper.getMainLooper());
    private OnCursorDragListener dragListener;
    private ExtraGestureListener extraListener;

    private int pressedCode = 0;
    private Keyboard.Key pressedKey;
    private long downTime;
    private int netSteps = 0;
    private boolean swallowing = false;   // we cancelled the key; ignore the rest of the touch
    private boolean longPressed = false;
    private float downX, downY, lastX, lastY, refX, refRawY;

    private PopupWindow indicator;
    private int indW, indH;
    private Paint hintPaint;

    private final Runnable longPressRunnable = new Runnable() {
        @Override
        public void run() {
            if (pressedCode == 0 || swallowing) {
                return;
            }
            cancelKey(lastX, lastY);
            swallowing = true;
            longPressed = true;
            performHapticFeedback(HapticFeedbackConstants.LONG_PRESS);
            if (pressedCode == SPACE_CODE) {
                refX = lastX;
                showIndicator();
            } else if (pressedCode == PERIOD_CODE && extraListener != null) {
                extraListener.onPeriodLongPress();
            } else if (extraListener != null && pressedKey != null) {
                extraListener.onKeyLongPress(pressedCode, pressedKey.x, pressedKey.y, pressedKey.width);
            }
        }
    };

    public AlsarabKeyboardView(Context context, AttributeSet attrs) {
        super(context, attrs);
    }

    public void setCursorDragListener(OnCursorDragListener listener) {
        this.dragListener = listener;
    }

    public void setLongPressDelay(int ms) {
        this.longPressMs = Math.max(100, ms);
    }

    public void setExtraGestureListener(ExtraGestureListener listener) {
        this.extraListener = listener;
    }

    private int dp(int v) {
        return (int) (v * getResources().getDisplayMetrics().density + 0.5f);
    }

    private Keyboard.Key keyAt(float x, float y) {
        Keyboard kb = getKeyboard();
        if (kb == null) {
            return null;
        }
        List<Keyboard.Key> keys = kb.getKeys();
        for (Keyboard.Key k : keys) {
            if (x >= k.x && x <= k.x + k.width && y >= k.y && y <= k.y + k.height) {
                return k;
            }
        }
        return null;
    }

    private Keyboard.Key spaceKey() {
        Keyboard kb = getKeyboard();
        if (kb == null) {
            return null;
        }
        for (Keyboard.Key k : kb.getKeys()) {
            if (k.codes != null && k.codes.length > 0 && k.codes[0] == SPACE_CODE) {
                return k;
            }
        }
        return null;
    }

    /** Tell the underlying KeyboardView the touch was cancelled so it types nothing. */
    private void cancelKey(float x, float y) {
        long now = SystemClock.uptimeMillis();
        MotionEvent c = MotionEvent.obtain(now, now, MotionEvent.ACTION_CANCEL, x, y, 0);
        super.onTouchEvent(c);
        c.recycle();
    }

    private void resetTouch() {
        handler.removeCallbacks(longPressRunnable);
        pressedCode = 0;
        swallowing = false;
        longPressed = false;
        hideIndicator();
    }

    @Override
    public boolean onTouchEvent(MotionEvent me) {
        switch (me.getActionMasked()) {
            case MotionEvent.ACTION_DOWN: {
                resetTouch();
                downTime = SystemClock.uptimeMillis();
                netSteps = 0;
                downX = lastX = refX = me.getX();
                downY = lastY = me.getY();
                refRawY = me.getRawY();
                Keyboard.Key k = keyAt(downX, downY);
                if (k != null && k.codes != null && k.codes.length > 0
                        && (k.codes[0] == SPACE_CODE || k.codes[0] == PERIOD_CODE
                        || (extraListener != null && extraListener.hasAlternates(k.codes[0])))) {
                    pressedCode = k.codes[0];
                    pressedKey = k;
                    handler.postDelayed(longPressRunnable, longPressMs);
                }
                return super.onTouchEvent(me);
            }

            case MotionEvent.ACTION_MOVE: {
                lastX = me.getX();
                lastY = me.getY();
                if (!swallowing) {
                    if (pressedCode == SPACE_CODE && Math.abs(lastX - downX) > DRAG_THRESHOLD_PX) {
                        // horizontal drag before long-press: plain cursor movement
                        handler.removeCallbacks(longPressRunnable);
                        cancelKey(lastX, lastY);
                        swallowing = true;
                        refX = downX;
                    } else {
                        float dx = lastX - downX, dy = lastY - downY;
                        if (pressedCode != 0 && dx * dx + dy * dy > dp(16) * dp(16)) {
                            handler.removeCallbacks(longPressRunnable);
                        }
                        return super.onTouchEvent(me);
                    }
                }
                if (pressedCode == SPACE_CODE) {
                    handleSpaceGesture(me);
                }
                return true;
            }

            case MotionEvent.ACTION_UP:
            case MotionEvent.ACTION_CANCEL: {
                boolean wasSwallowing = swallowing;
                boolean fling = me.getActionMasked() == MotionEvent.ACTION_UP
                        && wasSwallowing && pressedCode == SPACE_CODE && !longPressed
                        && SystemClock.uptimeMillis() - downTime < 350
                        && Math.abs(me.getX() - downX) > dp(70);
                resetTouch();
                if (fling) {
                    // undo the cursor movement the swipe caused, then open decorations
                    if (netSteps != 0 && dragListener != null) {
                        dragListener.onCursorMove(-netSteps);
                    }
                    if (extraListener != null) {
                        extraListener.onSpaceSwipe(me.getX() > downX);
                    }
                    return true;
                }
                if (wasSwallowing) {
                    return true;
                }
                return super.onTouchEvent(me);
            }

            default:
                return super.onTouchEvent(me);
        }
    }

    private void handleSpaceGesture(MotionEvent me) {
        // Horizontal: move cursor.
        float dx = me.getX() - refX;
        while (dx > DRAG_THRESHOLD_PX) {
            netSteps++;
            if (dragListener != null) dragListener.onCursorMove(1);
            refX += DRAG_THRESHOLD_PX;
            dx = me.getX() - refX;
        }
        while (dx < -DRAG_THRESHOLD_PX) {
            netSteps--;
            if (dragListener != null) dragListener.onCursorMove(-1);
            refX -= DRAG_THRESHOLD_PX;
            dx = me.getX() - refX;
        }
        // Vertical (only after long-press). Raw coordinates: the view itself moves
        // when the numbers row appears/disappears, so local Y would jump.
        if (longPressed) {
            float dy = me.getRawY() - refRawY;
            int th = dp(30);
            if (Math.abs(dy) > th) {
                refRawY = me.getRawY();
                if (extraListener != null) {
                    extraListener.onNumbersRowToggle(dy < 0);
                }
            }
        }
    }

    // ---- ←↑↓→ indicator -------------------------------------------------

    private void showIndicator() {
        hideIndicator();
        TextView tv = new TextView(getContext());
        tv.setText("←  ↑  ↓  →");
        tv.setTextColor(0xFFFFFFFF);
        tv.setTextSize(22);
        tv.setGravity(Gravity.CENTER);
        tv.setPadding(dp(16), dp(8), dp(16), dp(8));
        GradientDrawable bg = new GradientDrawable();
        bg.setColor(0xF0303030);
        bg.setCornerRadius(dp(12));
        tv.setBackground(bg);
        tv.measure(View.MeasureSpec.UNSPECIFIED, View.MeasureSpec.UNSPECIFIED);
        indW = tv.getMeasuredWidth();
        indH = tv.getMeasuredHeight();
        indicator = new PopupWindow(tv, ViewGroup.LayoutParams.WRAP_CONTENT,
                ViewGroup.LayoutParams.WRAP_CONTENT, false);
        indicator.setTouchable(false);
        Keyboard.Key sk = spaceKey();
        if (sk == null) {
            return;
        }
        try {
            indicator.showAsDropDown(this, indicatorX(sk), indicatorY(sk), Gravity.START);
        } catch (RuntimeException ignored) {
            indicator = null;
        }
    }

    private int indicatorX(Keyboard.Key sk) {
        return sk.x + sk.width / 2 - indW / 2;
    }

    private int indicatorY(Keyboard.Key sk) {
        return sk.y - indH - dp(6) - getHeight();
    }

    private void updateIndicator() {
        if (indicator == null || !indicator.isShowing()) {
            return;
        }
        Keyboard.Key sk = spaceKey();
        if (sk != null) {
            indicator.update(this, indicatorX(sk), indicatorY(sk), -1, -1);
        }
    }

    private void hideIndicator() {
        if (indicator != null) {
            try {
                indicator.dismiss();
            } catch (RuntimeException ignored) {
            }
            indicator = null;
        }
    }

    @Override
    public void onDraw(Canvas canvas) {
        super.onDraw(canvas);
        Keyboard kb = getKeyboard();
        if (extraListener == null || kb == null) {
            return;
        }
        if (hintPaint == null) {
            hintPaint = new Paint(Paint.ANTI_ALIAS_FLAG);
            hintPaint.setColor(0xFF777777);
            hintPaint.setTextSize(dp(11));
            hintPaint.setTextAlign(Paint.Align.RIGHT);
        }
        for (Keyboard.Key key : kb.getKeys()) {
            if (key.codes == null || key.codes.length == 0) {
                continue;
            }
            String h = extraListener.hintFor(key.codes[0]);
            if (h != null) {
                canvas.drawText(h, key.x + key.width - dp(5), key.y + dp(14), hintPaint);
            }
        }
    }

    @Override
    protected void onLayout(boolean changed, int l, int t, int r, int b) {
        super.onLayout(changed, l, t, r, b);
        if (changed && indicator != null) {
            post(this::updateIndicator);
        }
    }

    @Override
    protected void onDetachedFromWindow() {
        resetTouch();
        super.onDetachedFromWindow();
    }
}
