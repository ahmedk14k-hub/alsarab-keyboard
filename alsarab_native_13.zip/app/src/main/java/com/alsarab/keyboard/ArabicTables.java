package com.alsarab.keyboard;

import java.util.HashMap;
import java.util.Map;

/** Tables extracted from the original Alsarab keyboard layouts. */
final class ArabicTables {
    private ArabicTables() { }

    static final Map<Integer, String> NORMAL = new HashMap<>();
    static final Map<Integer, String> TASHKEEL = new HashMap<>();
    static final Map<Integer, String> ZAKHRAFA = new HashMap<>();

    static {
        NORMAL.put(1590, "1\u0661");
        NORMAL.put(1589, "2\u0662");
        NORMAL.put(1602, "3\u0663");
        NORMAL.put(1601, "4\u0664");
        NORMAL.put(1594, "5\u0665");
        NORMAL.put(1593, "6\u0666");
        NORMAL.put(1607, "7\u0667");
        NORMAL.put(1582, "8\u0668");
        NORMAL.put(1581, "9\u0669");
        NORMAL.put(1580, "0\u0660");
        NORMAL.put(1610, "\u0649\u0626");
        NORMAL.put(1575, "\u0623\u0625\u0622\u0621");
        NORMAL.put(1592, "\u061f\u060c\u061b");
        NORMAL.put(1608, "\u0624");
        NORMAL.put(1600, "\u064e\u064b\u064f\u064c\u0650\u064d\u0651\u0652");
        TASHKEEL.put(1590, "\u0636\u064f");
        TASHKEEL.put(1589, "\u0635\u0651");
        TASHKEEL.put(1602, "\u0642\u064b");
        TASHKEEL.put(1601, "\u0641\u064e");
        TASHKEEL.put(1594, "\u063a\u064b");
        TASHKEEL.put(1593, "\u0652\u0639");
        TASHKEEL.put(1607, "\u064f\u0647");
        TASHKEEL.put(1582, "\u064c\u062e");
        TASHKEEL.put(1581, "\u062d\u064f");
        TASHKEEL.put(1580, "\u062c\u0652");
        TASHKEEL.put(1588, "\u0634\u0650");
        TASHKEEL.put(1587, "\u0633\u0650");
        TASHKEEL.put(1610, "\u064a\u064e");
        TASHKEEL.put(1576, "\u0628\u0651");
        TASHKEEL.put(1604, "\u0644\u064f");
        TASHKEEL.put(1575, "\u0627");
        TASHKEEL.put(1578, "\u062a\u0652");
        TASHKEEL.put(1606, "\u0646\u064e");
        TASHKEEL.put(1605, "\u0645\u064c");
        TASHKEEL.put(1603, "\u0643\u0650");
        TASHKEEL.put(1592, "\u0638\u064c");
        TASHKEEL.put(1591, "\u0637\u0650");
        TASHKEEL.put(1584, "\u0630\u064e");
        TASHKEEL.put(1583, "\u062f\u0650");
        TASHKEEL.put(1586, "\u0632\u064f");
        TASHKEEL.put(1585, "\u0631\u064e");
        TASHKEEL.put(1608, "\u0648\u064e");
        TASHKEEL.put(1577, "\u0629\u0650");
        TASHKEEL.put(1579, "\u062b\u064f");
        ZAKHRAFA.put(1590, "\u069e\ufebe\ufebf1\u0661");
        ZAKHRAFA.put(1589, "\u069d\ufeb9\ufebb2\u0662");
        ZAKHRAFA.put(1602, "\ufed8\ufed7\ufed5\ufb71\ufb70\ufb6f\ufb6e\u06a8\u06a7\u06a6\u14c63\u0663");
        ZAKHRAFA.put(1601, "\u14c54\u0664\u06a5\u06a4\u06a3\u06a2\u06a1\ufb6d\ufb6c\ufb6c\ufb6a");
        ZAKHRAFA.put(1594, "5\u0665\u06a0\u06fc\u06a0\u06fc\ufecd\ufece\ufecf\ufed0");
        ZAKHRAFA.put(1593, "6\u0666\u06f6\u03b6\u03be\ufec9\u060f\ufeca\ufecb\ufecc");
        ZAKHRAFA.put(1607, "7\u0667\ufba4\ufba5\ufba8\ufba9\ufbaa\ufbab\u0652\u06c1\u06c2\u14c7");
        ZAKHRAFA.put(1582, "8\u0668\u06bf\u0681\ufea5\ufea6\ufea8\u0681\u0682\u0685");
        ZAKHRAFA.put(1581, "9\u0669\u05d1\u03b6\ufea1\ufea2\ufea3\ufb81\ufb7f");
        ZAKHRAFA.put(1580, "0\u0660\ufe9d\ufe9e\ufe9f\ufb72\ufb73\ufb74\ufb76\ufb77\ufb78\ufb7a\ufb7b\ufb7c\ufb7e");
        ZAKHRAFA.put(1588, "\ufeb5\ufeb8\u069c\u06e3\u06dc\u06d6\u06d7\u06d8\u06d9\u06da\u06db\u06e3\u06e5\u06e6\u06e7\u06e8\ufdfd\ufdfa");
        ZAKHRAFA.put(1587, "\u0e5b\u06dc\ufeb3\u069a\u069b");
        ZAKHRAFA.put(1610, "\ufbb1\ufbb0\ufbaf\ufbae\ufbff\ufbfd\ufbfc\ufbe7\ufbe5\ufbe4\u0626\ufef2\u06d1\u06d0\u06ce\u06cd\ufef1\ufef0\ufeef\u0649");
        ZAKHRAFA.put(1576, "\u067b\ufb52\ufb54\ufb56\ufb58\ufb5a\ufb5c\ufe90\ufe91");
        ZAKHRAFA.put(1575, "\u0623\u0625\u0622\u0671\u0672\u0673\u0674\u0675\u06b5\u06b6\u06b7\u06b8\ufedd\ufedf\u03ea\u06fd\u0621");
        ZAKHRAFA.put(1578, "\u067a\u067c\ufb62\ufb64\ufb66\ufb68");
        ZAKHRAFA.put(1606, "\u06b9\u06bc\u06bd\ufee5\ufee7\ufb9e\u06ba\ufba0\u06bb\ufba2");
        ZAKHRAFA.put(1605, "\u06fe\ufee1\ufee3\u05dd\u14c4");
        ZAKHRAFA.put(1603, "\u0643\ufbd5\ufbd3\u06b4\u06b3\u06b2\u06b1\u06b0\u06af\u06ae\u06ad\u06ac\u06ab\u06aa\u06a9");
        ZAKHRAFA.put(1592, "\u061f\u060c\u061b\ufec8\u069f");
        ZAKHRAFA.put(1584, "\ufb88\ufb86\ufb84\u068c\u0688\u068b\u068e\u068f\u0690\ufeab");
        ZAKHRAFA.put(1583, "\ufea9\u0689\u068a\ufb82\u068d\u05e0");
        ZAKHRAFA.put(1586, "\u0698\u0691\u0692\u0697\u0698\u0699\ufeaf");
        ZAKHRAFA.put(1585, "\u0693\u0694\u0695\u0696\ufead");
        ZAKHRAFA.put(1608, "\ufeed\u06cb\u06ca\u06c5\u06c4\ufbe2\ufbe0\ufbde\ufbdd\ufbdb\ufbd9\ufbd7\u0624");
        ZAKHRAFA.put(1577, "\ufba4\ufba5\ufba8\ufba9\ufbaa\ufbab\u0652\u06c1\u06c2");
        ZAKHRAFA.put(1579, "\u067a\u067c\ufb62\ufb64\ufb66\ufb68");
        ZAKHRAFA.put(1600, "\u064e\u064b\u064f\u064c\u0650\u064d\u0651\u0652");
        NORMAL.put(1600, "\u064b\u064c\u064d\u064e\u064f\u0650\u0651\u0652");
    }
}
