package com.alsarab.keyboard;

import android.content.SharedPreferences;

import java.util.ArrayList;
import java.util.List;

/** Keeps the last few clipboard entries, persisted in SharedPreferences. */
public class ClipboardHistory {

    private static final String KEY = "clip_history";
    private static final String SEP = "\u0001\u0002\u0003";
    private static final int MAX_ITEMS = 8;

    public static void add(SharedPreferences prefs, String text) {
        if (text == null || text.trim().isEmpty()) {
            return;
        }
        List<String> items = getAll(prefs);
        items.remove(text);
        items.add(0, text);
        while (items.size() > MAX_ITEMS) {
            items.remove(items.size() - 1);
        }
        prefs.edit().putString(KEY, String.join(SEP, items)).apply();
    }

    public static List<String> getAll(SharedPreferences prefs) {
        String stored = prefs.getString(KEY, "");
        List<String> result = new ArrayList<>();
        if (stored != null && !stored.isEmpty()) {
            for (String s : stored.split(SEP)) {
                if (!s.isEmpty()) {
                    result.add(s);
                }
            }
        }
        return result;
    }

    public static void clear(SharedPreferences prefs) {
        prefs.edit().remove(KEY).apply();
    }
}
