package com.alsarab.keyboard;

import android.content.Context;
import android.content.res.TypedArray;
import android.preference.DialogPreference;
import android.util.AttributeSet;
import android.view.Gravity;
import android.view.View;
import android.widget.LinearLayout;
import android.widget.SeekBar;
import android.widget.TextView;

/** Slider dialog preference (the original's DialogSeekBarPreference). */
public class SeekBarPreference extends DialogPreference {

    private static final String ANDROID_NS = "http://schemas.android.com/apk/res/android";

    private final int min;
    private final int max;
    private final int step;
    private int value;
    private SeekBar bar;
    private TextView label;

    public SeekBarPreference(Context context, AttributeSet attrs) {
        super(context, attrs);
        min = attrs.getAttributeIntValue(ANDROID_NS, "min", 0);
        max = attrs.getAttributeIntValue(ANDROID_NS, "max", 100);
        step = (max - min) >= 500 ? 25 : 1;
        setPositiveButtonText(android.R.string.ok);
        setNegativeButtonText(android.R.string.cancel);
    }

    @Override
    protected Object onGetDefaultValue(TypedArray a, int index) {
        return a.getInt(index, min);
    }

    @Override
    protected void onSetInitialValue(boolean restore, Object defaultValue) {
        int def = defaultValue instanceof Integer ? (Integer) defaultValue : min;
        value = restore ? getPersistedInt(def) : def;
    }

    @Override
    protected View onCreateDialogView() {
        Context c = getContext();
        LinearLayout box = new LinearLayout(c);
        box.setOrientation(LinearLayout.VERTICAL);
        int pad = (int) (20 * c.getResources().getDisplayMetrics().density);
        box.setPadding(pad, pad, pad, pad);

        label = new TextView(c);
        label.setTextSize(20);
        label.setGravity(Gravity.CENTER);
        box.addView(label);

        bar = new SeekBar(c);
        bar.setMax((max - min) / step);
        bar.setProgress((value - min) / step);
        label.setText(String.valueOf(value));
        bar.setOnSeekBarChangeListener(new SeekBar.OnSeekBarChangeListener() {
            @Override
            public void onProgressChanged(SeekBar s, int p, boolean fromUser) {
                label.setText(String.valueOf(min + p * step));
            }

            @Override public void onStartTrackingTouch(SeekBar s) { }
            @Override public void onStopTrackingTouch(SeekBar s) { }
        });
        box.addView(bar);
        return box;
    }

    @Override
    protected void onDialogClosed(boolean positiveResult) {
        if (positiveResult && bar != null) {
            int v = min + bar.getProgress() * step;
            if (callChangeListener(v)) {
                value = v;
                persistInt(v);
            }
        }
    }
}
