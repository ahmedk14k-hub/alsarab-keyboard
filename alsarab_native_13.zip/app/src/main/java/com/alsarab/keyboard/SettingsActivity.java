package com.alsarab.keyboard;

import android.os.Bundle;
import android.preference.PreferenceActivity;

/** Settings screens, generated from the original keyboard's preference tree. */
public class SettingsActivity extends PreferenceActivity {

    public static final String PREFS = "alsarab_prefs";

    public static final String KEY_VIBRATE = "vibrate_on";
    public static final String KEY_VIBRATE_LEN = "vibration_length";
    public static final String KEY_SOUND = "sound_on";
    public static final String KEY_SOUND_VOLUME = "sound_volume";
    public static final String KEY_SOUND_NAME = "tap_sound_style_pref";
    public static final String KEY_NUMBERS_MODE = "enable_cursors";
    public static final String KEY_LONG_PRESS = "long_press_delay";
    public static final String KEY_ALT_LABELS = "dispaly_alt_labels";
    public static final String KEY_DARK = "dark_theme";

    @SuppressWarnings("deprecation")
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        getPreferenceManager().setSharedPreferencesName(PREFS);
        addPreferencesFromResource(R.xml.prefs);
    }
}
