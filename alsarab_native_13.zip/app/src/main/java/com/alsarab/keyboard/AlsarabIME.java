package com.alsarab.keyboard;

import android.content.ClipData;
import android.content.ClipboardManager;
import android.content.Context;
import android.content.SharedPreferences;
import android.inputmethodservice.InputMethodService;
import android.inputmethodservice.Keyboard;
import android.content.res.AssetFileDescriptor;
import android.media.AudioManager;
import android.media.SoundPool;
import android.os.Vibrator;
import android.view.Gravity;
import android.view.HapticFeedbackConstants;
import android.view.KeyEvent;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.view.inputmethod.InputConnection;
import android.widget.LinearLayout;
import android.widget.PopupWindow;
import android.widget.ScrollView;
import android.widget.TextView;

import java.util.List;

public class AlsarabIME extends InputMethodService
        implements android.inputmethodservice.KeyboardView.OnKeyboardActionListener {

    private static final int CODE_CLIPBOARD = -201;
    private static final int CODE_ALT = -202;
    private static final String KEY_NUMBERS_ROW = "show_numbers_row";

    private static final String[] EMOJIS = {
        "😄","😃","😀","😊","☺️","😉","😍","😘","😚","😗","😙","😜",
        "😝","😛","😳","😁","😔","😌","😒","😞","😣","😢","😂","😭",
        "😪","😥","😰","😅","😓","😩","😫","😨","😱","😠","😡","😤",
        "😖","😆","😋","😷","😎","😴","😵","😲","😟","😦","😧","😈",
        "😮","😬","😐","😕","😯","😶","😇","😏","😑","🙄","🤔","🤣",
        "👍","👎","👏","🙏","💪","👌","✌️","🤝","❤️","💔","🔥","✨",
        "🎉","🌹","💯","⭐","☕","🎁","🌙","☀️","🤲","🥰","😘","🥺"
    };

    private AlsarabKeyboardView keyboardView;
    private Keyboard arabicKeyboard;        // with numbers row
    private Keyboard arabicNoNumKeyboard;
    private Keyboard englishKeyboard;
    private Keyboard englishNoNumKeyboard;    // without numbers row
    private Keyboard symbolsKeyboard;        // ?123
    private Keyboard symbolsAltKeyboard;     // ALT page
    private int page = 0;                    // 0 = arabic, 1 = symbols, 2 = ALT symbols
    private boolean showNumbers = true;
    private PopupWindow emojiPopup;
    private SharedPreferences prefs;
    private Vibrator vibrator;
    private AudioManager audioManager;
    private ClipboardManager clipboardManager;
    private PopupWindow clipPopup;
    private SoundPool soundPool;
    private int clickSoundId = 0;

    private final ClipboardManager.OnPrimaryClipChangedListener clipListener =
            this::captureClipboardIntoHistory;

    @Override
    public void onCreate() {
        super.onCreate();
        prefs = getSharedPreferences(SettingsActivity.PREFS, MODE_PRIVATE);
        vibrator = (Vibrator) getSystemService(Context.VIBRATOR_SERVICE);
        audioManager = (AudioManager) getSystemService(Context.AUDIO_SERVICE);
        clipboardManager = (ClipboardManager) getSystemService(Context.CLIPBOARD_SERVICE);
        if (clipboardManager != null) {
            clipboardManager.addPrimaryClipChangedListener(clipListener);
        }
        loadClickSound();
    }

    private String loadedSound = null;

    private void loadClickSound() {
        String name = prefs.getString(SettingsActivity.KEY_SOUND_NAME, "Android").toLowerCase();
        if (name.equals("winphone")) {
            name = "tock";
        }
        if (name.equals(loadedSound)) {
            return;
        }
        loadedSound = name;
        clickSoundId = 0;
        if (soundPool != null) {
            soundPool.release();
            soundPool = null;
        }
        if (name.equals("none")) {
            return;
        }
        try {
            soundPool = new SoundPool.Builder().setMaxStreams(4)
                    .setAudioAttributes(new android.media.AudioAttributes.Builder()
                            .setUsage(android.media.AudioAttributes.USAGE_ASSISTANCE_SONIFICATION)
                            .setContentType(android.media.AudioAttributes.CONTENT_TYPE_SONIFICATION)
                            .build())
                    .build();
            AssetFileDescriptor afd = getAssets().openFd(name + ".ogg");
            clickSoundId = soundPool.load(afd, 1);
            afd.close();
        } catch (java.io.IOException | RuntimeException e) {
            clickSoundId = 0;
        }
    }

    @Override
    public void onStartInputView(android.view.inputmethod.EditorInfo info, boolean restarting) {
        super.onStartInputView(info, restarting);
        loadClickSound();
        if (keyboardView != null) {
            keyboardView.setLongPressDelay(prefs.getInt(SettingsActivity.KEY_LONG_PRESS, 400));
            boolean before = showNumbers;
            showNumbers = initialNumbersState();
            if (before != showNumbers) {
                applyKeyboard();
            } else {
                keyboardView.invalidateAllKeys();
            }
        }
    }

    @Override
    public void onDestroy() {
        if (soundPool != null) {
            soundPool.release();
            soundPool = null;
        }
        if (clipboardManager != null) {
            clipboardManager.removePrimaryClipChangedListener(clipListener);
        }
        super.onDestroy();
    }

    private void captureClipboardIntoHistory() {
        if (clipboardManager == null || !clipboardManager.hasPrimaryClip()) {
            return;
        }
        ClipData clip = clipboardManager.getPrimaryClip();
        if (clip == null || clip.getItemCount() == 0) {
            return;
        }
        CharSequence text = clip.getItemAt(0).coerceToText(this);
        if (text != null && prefs != null) {
            ClipboardHistory.add(prefs, text.toString());
        }
    }

    @Override
    public View onCreateInputView() {
        keyboardView = (AlsarabKeyboardView) getLayoutInflater().inflate(R.layout.keyboard_view, null);
        arabicKeyboard = new Keyboard(this, R.xml.keyboard_arabic);
        arabicNoNumKeyboard = new Keyboard(this, R.xml.keyboard_arabic_nonum);
        englishKeyboard = new Keyboard(this, R.xml.keyboard_english);
        englishNoNumKeyboard = new Keyboard(this, R.xml.keyboard_english_nonum);
        symbolsKeyboard = new Keyboard(this, R.xml.keyboard_symbols);
        symbolsAltKeyboard = new Keyboard(this, R.xml.keyboard_symbols_alt);
        page = 0;
        showNumbers = initialNumbersState();
        keyboardView.setLongPressDelay(prefs.getInt(SettingsActivity.KEY_LONG_PRESS, 400));
        applyKeyboard();
        keyboardView.setOnKeyboardActionListener(this);
        keyboardView.setCursorDragListener(this::moveCursor);
        keyboardView.setExtraGestureListener(new AlsarabKeyboardView.ExtraGestureListener() {
            @Override
            public void onNumbersRowToggle(boolean show) {
                setNumbersVisible(show);
            }

            @Override
            public void onPeriodLongPress() {
                showEmojiPanel();
            }

            @Override
            public void onSpaceSwipe(boolean next) {
                cycleMode(next);
            }

            @Override
            public String hintFor(int code) {
                if (page == 2 || !prefs.getBoolean(SettingsActivity.KEY_ALT_LABELS, true)) {
                    return null;
                }
                String alts = alternatesFor(code);
                if (alts == null) {
                    return null;
                }
                char h = alts.charAt(0);
                if (showNumbers && Character.isDigit(h)) {
                    return null;
                }
                return String.valueOf(h);
            }

            @Override
            public boolean hasAlternates(int code) {
                return page == 0 && alternatesFor(code) != null;
            }

            @Override
            public void onKeyLongPress(int code, int x, int y, int w) {
                showAlternates(alternatesFor(code), x, y, w);
            }
        });

        boolean dark = prefs.getBoolean(SettingsActivity.KEY_DARK, false);
        keyboardView.setBackgroundColor(dark ? 0xFF2B2B2B : 0xFFD9D9D9);

        return keyboardView;
    }

    private Keyboard currentKeyboard() {
        switch (page) {
            case 1: return symbolsKeyboard;
            case 2: return symbolsAltKeyboard;
            default:
                if (mode == 1) {
                    return showNumbers ? englishKeyboard : englishNoNumKeyboard;
                }
                return showNumbers ? arabicKeyboard : arabicNoNumKeyboard;
        }
    }

    private void applyKeyboard() {
        if (keyboardView != null) {
            Keyboard kb = currentKeyboard();
            setSpaceLabels(kb);
            keyboardView.setKeyboard(kb);
            keyboardView.setShifted(shiftOn);
            keyboardView.invalidateAllKeys();
        }
    }

    /** "صف الارقام": 0 = never, 1 = toggled by dragging the space key, 2 = always. */
    private String numbersMode() {
        return prefs.getString(SettingsActivity.KEY_NUMBERS_MODE, "1");
    }

    private boolean initialNumbersState() {
        String m = numbersMode();
        if (m.equals("2")) return true;
        if (m.equals("0")) return false;
        return prefs.getBoolean(KEY_NUMBERS_ROW, false);
    }

    private void setNumbersVisible(boolean show) {
        if (!numbersMode().equals("1")) {
            return;
        }
        if (show == showNumbers) {
            return;
        }
        showNumbers = show;
        prefs.edit().putBoolean(KEY_NUMBERS_ROW, show).apply();
        if (page == 0) {
            applyKeyboard();
        }
        keyboardView.performHapticFeedback(HapticFeedbackConstants.KEYBOARD_TAP);
    }

    /** Long-press shortcuts for Arabic letters: digits + related letters. */
    private String alternatesFor(int code) {
        if (code >= 0x600) {
            return (mode == 2 ? ArabicTables.ZAKHRAFA : ArabicTables.NORMAL).get(code);
        }
        switch (code) {
            case 45: return "_–—"; // -
            case 'q': return "1"; case 'w': return "2"; case 'e': return "3";
            case 'r': return "4"; case 't': return "5"; case 'y': return "6";
            case 'u': return "7"; case 'i': return "8"; case 'o': return "9";
            case 'p': return "0";
            case 'a': return "@"; case 's': return "#"; case 'd': return "$";
            case 'f': return "&"; case 'g': return "*"; case 'j': return "+";
            case 'k': return "("; case 'l': return ")";
            case 'z': return "!"; case 'x': return "\""; case 'c': return "'";
            case 'v': return ":"; case 'b': return ";"; case 'n': return "/";
            case 'm': return "?";
            default: return null;
        }
    }

    private void showAlternates(String alts, int keyX, int keyY, int keyW) {
        if (alts == null || keyboardView == null) {
            return;
        }
        float d = getResources().getDisplayMetrics().density;
        int cell = (int) (42 * d);
        int perRow = 8;
        java.util.List<String> items = new java.util.ArrayList<>();
        for (int i = 0; i < alts.length(); ) {
            int cp = alts.codePointAt(i);
            items.add(new String(Character.toChars(cp)));
            i += Character.charCount(cp);
        }
        final PopupWindow[] ref = new PopupWindow[1];
        LinearLayout box = new LinearLayout(this);
        box.setOrientation(LinearLayout.VERTICAL);
        box.setBackgroundColor(0xF0303030);
        LinearLayout row = null;
        for (int i = 0; i < items.size(); i++) {
            if (i % perRow == 0) {
                row = new LinearLayout(this);
                row.setOrientation(LinearLayout.HORIZONTAL);
                box.addView(row, new LinearLayout.LayoutParams(
                        ViewGroup.LayoutParams.WRAP_CONTENT, cell));
            }
            final String ch = items.get(i);
            TextView tv = new TextView(this);
            tv.setText(ch);
            tv.setTextSize(22);
            tv.setTextColor(0xFFFFFFFF);
            tv.setGravity(Gravity.CENTER);
            tv.setOnClickListener(v -> {
                InputConnection ic = getCurrentInputConnection();
                if (ic != null) {
                    ic.commitText(ch, 1);
                }
                if (ref[0] != null) {
                    ref[0].dismiss();
                }
            });
            row.addView(tv, new LinearLayout.LayoutParams(cell, cell));
        }
        int cols = Math.min(perRow, items.size());
        int rows = (items.size() + perRow - 1) / perRow;
        int w = cell * cols;
        int h = cell * rows;
        int x = keyX + keyW / 2 - w / 2;
        x = Math.max(0, Math.min(x, keyboardView.getWidth() - w));
        int y = keyY - h - (int) (4 * d) - keyboardView.getHeight();
        PopupWindow pw = new PopupWindow(box, w, h, true);
        pw.setOutsideTouchable(true);
        ref[0] = pw;
        pw.showAsDropDown(keyboardView, x, y, Gravity.START);
    }

    // ---- modes: 0 Arabic, 1 English, 2 Zakhrafa (decoration), 3 Tashkeel ----------

    private static final String[] MODE_NAMES = {"العربية", "الانجليزية", "الزخرفة", "التشكيل"};
    private int mode = 0;
    private boolean shiftOn = false;

    private static boolean isArabicLetter(int c) {
        return c >= 0x0621 && c <= 0x064A;
    }

    private void setSpaceLabels(Keyboard kb) {
        for (Keyboard.Key key : kb.getKeys()) {
            if (key.codes != null && key.codes.length > 0 && key.codes[0] == 32) {
                key.label = "◀ " + MODE_NAMES[mode] + " ▶";
            }
        }
    }

    private void cycleMode(boolean next) {
        mode = (mode + (next ? 1 : 3)) % 4;
        shiftOn = false;
        applyKeyboard();
        keyboardView.performHapticFeedback(HapticFeedbackConstants.KEYBOARD_TAP);
    }

    private void commitLetter(InputConnection ic, int code) {
        String ch = new String(Character.toChars(code));
        if (page == 0 && mode == 1 && code >= 'a' && code <= 'z') {
            ic.commitText(shiftOn ? ch.toUpperCase() : ch, 1);
            if (shiftOn) {
                shiftOn = false;
                keyboardView.setShifted(false);
            }
        } else if (page == 0 && mode == 3 && ArabicTables.TASHKEEL.containsKey(code)) {
            String t = ArabicTables.TASHKEEL.get(code);
            // some original entries put the mark before the letter; keep it after
            if (t.length() > 1 && t.charAt(0) >= 0x064B && t.charAt(0) <= 0x0652) {
                t = t.substring(1) + t.charAt(0);
            }
            ic.commitText(t, 1);
        } else {
            ic.commitText(ch, 1);
        }
    }

    private void showEmojiPanel() {
        if (keyboardView == null) {
            return;
        }
        float d = getResources().getDisplayMetrics().density;
        int cell = (int) (52 * d);
        int cols = 6;

        LinearLayout grid = new LinearLayout(this);
        grid.setOrientation(LinearLayout.VERTICAL);
        LinearLayout row = null;
        for (int i = 0; i < EMOJIS.length; i++) {
            if (i % cols == 0) {
                row = new LinearLayout(this);
                row.setOrientation(LinearLayout.HORIZONTAL);
                grid.addView(row, new LinearLayout.LayoutParams(
                        ViewGroup.LayoutParams.MATCH_PARENT, cell));
            }
            final String emoji = EMOJIS[i];
            TextView tv = new TextView(this);
            tv.setText(emoji);
            tv.setTextSize(26);
            tv.setGravity(Gravity.CENTER);
            tv.setOnClickListener(v -> {
                InputConnection ic = getCurrentInputConnection();
                if (ic != null) {
                    ic.commitText(emoji, 1);
                }
                if (emojiPopup != null) {
                    emojiPopup.dismiss();
                }
            });
            row.addView(tv, new LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.MATCH_PARENT, 1f));
        }
        ScrollView scroll = new ScrollView(this);
        scroll.addView(grid);
        scroll.setBackgroundColor(0xF0222222);
        scroll.setPadding(8, 8, 8, 8);

        int width = keyboardView.getWidth() - (int) (16 * d);
        int height = cell * 4 + 16;
        if (emojiPopup != null) {
            emojiPopup.dismiss();
        }
        emojiPopup = new PopupWindow(scroll, width, height, true);
        emojiPopup.setOutsideTouchable(true);
        emojiPopup.showAsDropDown(keyboardView, (int) (8 * d),
                -height - (int) (4 * d), Gravity.START);
    }

    private void moveCursor(int steps) {
        InputConnection ic = getCurrentInputConnection();
        if (ic == null) {
            return;
        }
        int code = steps > 0 ? KeyEvent.KEYCODE_DPAD_RIGHT : KeyEvent.KEYCODE_DPAD_LEFT;
        int count = Math.abs(steps);
        for (int i = 0; i < count; i++) {
            ic.sendKeyEvent(new KeyEvent(KeyEvent.ACTION_DOWN, code));
            ic.sendKeyEvent(new KeyEvent(KeyEvent.ACTION_UP, code));
        }
    }

    @Override
    public void onPress(int primaryCode) {
        boolean vibrateOn = prefs == null || prefs.getBoolean(SettingsActivity.KEY_VIBRATE, true);
        int vibMs = prefs == null ? 40 : prefs.getInt(SettingsActivity.KEY_VIBRATE_LEN, 40);
        if (vibrateOn && vibMs > 0 && vibrator != null) {
            vibrator.vibrate(android.os.VibrationEffect.createOneShot(vibMs,
                    android.os.VibrationEffect.DEFAULT_AMPLITUDE));
        }
        boolean soundOn = prefs == null || prefs.getBoolean(SettingsActivity.KEY_SOUND, true);
        if (soundOn) {
            if (soundPool != null && clickSoundId != 0) {
                float vol = prefs.getInt(SettingsActivity.KEY_SOUND_VOLUME, 100) / 100f;
                soundPool.play(clickSoundId, vol, vol, 1, 0, 1f);
            } else if (audioManager != null) {
                audioManager.playSoundEffect(AudioManager.FX_KEYPRESS_STANDARD);
            }
        }
    }

    @Override
    public void onKey(int primaryCode, int[] keyCodes) {
        InputConnection ic = getCurrentInputConnection();
        if (ic == null) {
            return;
        }

        switch (primaryCode) {
            case Keyboard.KEYCODE_DELETE:
                ic.deleteSurroundingText(1, 0);
                break;

            case Keyboard.KEYCODE_DONE:
                ic.commitText("\n", 1);
                break;

            case Keyboard.KEYCODE_MODE_CHANGE:
                page = (page == 0) ? 1 : 0;
                applyKeyboard();
                break;

            case Keyboard.KEYCODE_SHIFT:
                shiftOn = !shiftOn;
                keyboardView.setShifted(shiftOn);
                break;

            case CODE_ALT:
                page = (page == 1) ? 2 : 1;
                applyKeyboard();
                break;

            case CODE_CLIPBOARD:
                showClipboardHistory();
                break;

            default:
                commitLetter(ic, primaryCode);
        }
    }

    private void showClipboardHistory() {
        if (prefs == null || keyboardView == null) {
            return;
        }
        List<String> items = ClipboardHistory.getAll(prefs);

        LinearLayout container = new LinearLayout(this);
        container.setOrientation(LinearLayout.VERTICAL);
        container.setBackgroundColor(0xFFF4F4F4);
        container.setPadding(16, 16, 16, 16);

        if (items.isEmpty()) {
            TextView empty = new TextView(this);
            empty.setText("لا يوجد عناصر منسوخة بعد");
            empty.setTextColor(0xFF444444);
            empty.setPadding(24, 24, 24, 24);
            container.addView(empty);
        } else {
            for (String item : items) {
                TextView row = new TextView(this);
                String shown = item.length() > 40 ? item.substring(0, 40) + "…" : item;
                row.setText(shown);
                row.setTextColor(0xFF000000);
                row.setTextSize(15);
                row.setPadding(24, 20, 24, 20);
                row.setOnClickListener(v -> {
                    InputConnection ic = getCurrentInputConnection();
                    if (ic != null) {
                        ic.commitText(item, 1);
                    }
                    if (clipPopup != null) {
                        clipPopup.dismiss();
                    }
                });
                container.addView(row);

                View divider = new View(this);
                divider.setLayoutParams(new LinearLayout.LayoutParams(
                        ViewGroup.LayoutParams.MATCH_PARENT, 2));
                divider.setBackgroundColor(0x22000000);
                container.addView(divider);
            }
        }

        clipPopup = new PopupWindow(container,
                ViewGroup.LayoutParams.MATCH_PARENT,
                ViewGroup.LayoutParams.WRAP_CONTENT, true);
        clipPopup.setOutsideTouchable(true);
        clipPopup.showAtLocation(keyboardView, Gravity.BOTTOM, 0, keyboardView.getHeight());
    }

    @Override public void onRelease(int primaryCode) { }
    @Override public void onText(CharSequence text) { }
    @Override public void swipeLeft() { runGesture("swipe_left"); }
    @Override public void swipeRight() { runGesture("swipe_right"); }
    @Override public void swipeDown() { runGesture("swipe_down"); }
    @Override public void swipeUp() { runGesture("swipe_up"); }

    /** Runs the action chosen in "الايماءات" (values match the original's list). */
    private void runGesture(String prefKey) {
        int action;
        try {
            action = Integer.parseInt(prefs.getString(prefKey, "0"));
        } catch (NumberFormatException e) {
            return;
        }
        InputConnection ic = getCurrentInputConnection();
        switch (action) {
            case 1: // delete last word
                if (ic != null) {
                    CharSequence before = ic.getTextBeforeCursor(60, 0);
                    if (before != null) {
                        int end = before.length();
                        int i = end;
                        while (i > 0 && Character.isWhitespace(before.charAt(i - 1))) i--;
                        while (i > 0 && !Character.isWhitespace(before.charAt(i - 1))) i--;
                        if (end - i > 0) {
                            ic.deleteSurroundingText(end - i, 0);
                        }
                    }
                }
                break;
            case 2: // keyboard settings
                startActivity(new android.content.Intent(this, SettingsActivity.class)
                        .addFlags(android.content.Intent.FLAG_ACTIVITY_NEW_TASK));
                break;
            case 3: // close keyboard
                requestHideSelf(0);
                break;
            case 4: // paste
                if (ic != null) {
                    ic.performContextMenuAction(android.R.id.paste);
                }
                break;
            case 6: // next language/mode
                cycleMode(true);
                break;
            case 7: // previous language/mode
                cycleMode(false);
                break;
            case 8: sendDpad(KeyEvent.KEYCODE_DPAD_RIGHT); break;
            case 9: sendDpad(KeyEvent.KEYCODE_DPAD_LEFT); break;
            case 10: sendDpad(KeyEvent.KEYCODE_DPAD_UP); break;
            case 11: sendDpad(KeyEvent.KEYCODE_DPAD_DOWN); break;
            case 15: // toggle symbols
                onKey(Keyboard.KEYCODE_MODE_CHANGE, null);
                break;
            case 19: // caps
                shiftOn = !shiftOn;
                keyboardView.setShifted(shiftOn);
                break;
            default:
                break; // 0 = nothing; the remaining actions are not available
        }
    }

    private void sendDpad(int code) {
        InputConnection ic = getCurrentInputConnection();
        if (ic != null) {
            ic.sendKeyEvent(new KeyEvent(KeyEvent.ACTION_DOWN, code));
            ic.sendKeyEvent(new KeyEvent(KeyEvent.ACTION_UP, code));
        }
    }
}
