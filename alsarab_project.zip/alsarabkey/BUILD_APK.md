# بناء APK كيبورد السراب — خطوات أندرويد ستوديو

هذا مشروع **Expo (React Native)** وليس مشروع أندرويد عادي، ولذلك ما فيه مجلد `android`.
المجلد يتولد تلقائيًا بأمر `prebuild`، وهو اللي يحقن خدمة الكيبورد (Kotlin) داخل التطبيق.

## المتطلبات
- **Node.js** إصدار 20.19.4 أو أحدث (أو 22.13+، أو 24.3+). تأكد بـ `node -v`
- **pnpm 9.12**: `corepack enable` ثم يشتغل تلقائيًا، أو `npm i -g pnpm@9.12.0`
- **أندرويد ستوديو** بآخر إصدار (يجي معه JDK 21 وهو يكفي)
- من **SDK Manager** نزّل: Android SDK Platform **36**، وBuild-Tools **36.0.0**، وNDK **27.1.12297006**
- ضع المشروع بمسار **قصير** مثل `C:\kb\alsarabkey` (مسارات ويندوز الطويلة تكسر بناء C++)

## الأوامر (من داخل مجلد alsarabkey)
```
pnpm install
npx expo prebuild --platform android
```
بعدها بطريقتين:

**أ) من الطرفية (الأسهل):**
```
cd android
./gradlew assembleRelease          # ويندوز: gradlew.bat assembleRelease
```
الملف يطلع هنا: `android/app/build/outputs/apk/release/app-release.apk`
(لتسريع البناء، وللأجهزة الحديثة يكفي arm64: أضف `-PreactNativeArchitectures=arm64-v8a`)

**ب) من أندرويد ستوديو:**
1. File > Open واختر مجلد `android` (مو مجلد المشروع الرئيسي).
2. انتظر Gradle Sync.
3. **مهم:** Build > Select Build Variant واختر **release** (مو debug).
4. Build > Build Bundle(s) / APK(s) > Build APK(s).

## ليش release وليس debug؟
نسخة debug ما تحمل كود الواجهة داخلها وتنتظر سيرفر Metro، والمشروع يحذف صلاحية الإنترنت، فشاشة الإعدادات ما راح تفتح.
نسخة release تحمل كل شي داخلها. وهي موقّعة بمفتاح debug تلقائيًا فتتثبت على الجهاز مباشرة.
للنشر على Google Play لازم تسوي مفتاح توقيع خاص بك.

## بعد التثبيت على الهاتف
1. افتح التطبيق واضغط «فتح إعدادات لوحات المفاتيح» وفعّل «كيبورد السراب البعيد».
2. ارجع للتطبيق واضغط «اختيار لوحة المفاتيح» واختر السراب.

## تغيير اسم الباكج (اختياري، قبل prebuild)
اسم الباكج الحالي طويل: `space.manus.alsarabkey.t125167943068416`.
لتغييره عدّل `rawBundleId` أعلى ملف `app.config.ts`، ثم احذف مجلد `android` وأعد `prebuild`.

## ما تغيّر عن النسخة الأصلية
ملفان فقط داخل `plugins/native/java/com/alsarab/keyboard/`:
- `SarabInputMethodService.kt`: خطأ بناء، الدالة `currentInputMethodSubtype` غير موجودة بـ InputMethodService، استُبدلت بقراءتها من InputMethodManager.
- `SarabKeyboardSettingsModule.kt`: خطأ بناء مع React Native 0.86 (`currentActivity` لم تعد متاحة)، واستُبدلت بـ `appContext.currentActivity`. وتحسين قراءة حالة التفعيل لو النظام أضاف أرقام subtypes بعد `;`.
