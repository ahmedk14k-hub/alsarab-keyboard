const fs = require("node:fs");
const path = require("node:path");
const {
  withAndroidManifest,
  withDangerousMod,
  withMainApplication,
} = require("@expo/config-plugins");

const SERVICE_CLASS = "com.alsarab.keyboard.SarabInputMethodService";
const SETTINGS_PACKAGE = "com.alsarab.keyboard.SarabKeyboardSettingsPackage";

function copyTree(source, destination) {
  if (!fs.existsSync(source)) return;
  fs.mkdirSync(destination, { recursive: true });
  for (const entry of fs.readdirSync(source, { withFileTypes: true })) {
    const from = path.join(source, entry.name);
    const to = path.join(destination, entry.name);
    if (entry.isDirectory()) copyTree(from, to);
    else fs.copyFileSync(from, to);
  }
}

function withSarabMainApplication(config) {
  return withMainApplication(config, (mod) => {
    let contents = mod.modResults.contents;
    const importStatement = `import ${SETTINGS_PACKAGE}`;
    if (!contents.includes(importStatement)) {
      contents = contents.replace(
        /^(package [^\n]+\n)/m,
        `$1\n${importStatement}\n`,
      );
    }

    const packageListMarker = "PackageList(this).packages.apply {";
    const packageRegistration = "add(SarabKeyboardSettingsPackage())";
    if (!contents.includes(packageRegistration)) {
      if (!contents.includes(packageListMarker)) {
        throw new Error(
          "with-alsarab-ime could not find the Expo PackageList block in MainApplication.kt",
        );
      }
      contents = contents.replace(
        packageListMarker,
        `${packageListMarker}\n          ${packageRegistration}`,
      );
    }
    mod.modResults.contents = contents;
    return mod;
  });
}

function withSarabManifest(config) {
  return withAndroidManifest(config, (mod) => {
    const application = mod.modResults.manifest.application?.[0];
    if (!application) throw new Error("AndroidManifest.xml has no application element");
    if (!Array.isArray(application.service)) application.service = [];

    const existing = application.service.find(
      (service) => service.$?.["android:name"] === SERVICE_CLASS,
    );
    const service = existing || { $: { "android:name": SERVICE_CLASS } };
    Object.assign(service.$, {
      "android:name": SERVICE_CLASS,
      "android:label": "@string/alsarab_ime_name",
      "android:permission": "android.permission.BIND_INPUT_METHOD",
      "android:exported": "true",
      "android:enabled": "true",
    });
    service["intent-filter"] = [
      {
        action: [{ $: { "android:name": "android.view.InputMethod" } }],
      },
    ];
    service["meta-data"] = [
      {
        $: {
          "android:name": "android.view.im",
          "android:resource": "@xml/alsarab_input_method",
        },
      },
    ];
    if (!existing) application.service.push(service);
    return mod;
  });
}

function withSarabNativeFiles(config) {
  return withDangerousMod(config, ["android", async (mod) => {
    const projectRoot = mod.modRequest.projectRoot;
    const androidRoot = mod.modRequest.platformProjectRoot;
    const sourceRoot = path.join(projectRoot, "plugins", "native");
    const mainRoot = path.join(androidRoot, "app", "src", "main");

    copyTree(
      path.join(sourceRoot, "java"),
      path.join(mainRoot, "java"),
    );
    copyTree(
      path.join(sourceRoot, "res"),
      path.join(mainRoot, "res"),
    );

    for (const variant of ["debug", "debugOptimized"]) {
      const variantManifest = path.join(
        androidRoot,
        "app",
        "src",
        variant,
        "AndroidManifest.xml",
      );
      if (!fs.existsSync(variantManifest)) continue;
      const original = fs.readFileSync(variantManifest, "utf8");
      const withoutOverlayPermission = original.replace(
        /<uses-permission\b(?=[^>]*android:name=["']android\.permission\.SYSTEM_ALERT_WINDOW["'])[^>]*\/>/g,
        "",
      );
      if (withoutOverlayPermission !== original) {
        fs.writeFileSync(variantManifest, withoutOverlayPermission, "utf8");
      }
    }

    const methodPath = path.join(mainRoot, "res", "xml", "alsarab_input_method.xml");
    const packageName = config.android?.package;
    if (!packageName) throw new Error("Android package name is required for the IME settings activity");
    const methodXml = fs.readFileSync(methodPath, "utf8").replaceAll("__APPLICATION_ID__", packageName);
    fs.writeFileSync(methodPath, methodXml, "utf8");
    return mod;
  }]);
}

module.exports = function withAlsarabIme(config) {
  config = withSarabMainApplication(config);
  config = withSarabManifest(config);
  config = withSarabNativeFiles(config);
  return config;
};
