package com.alsarab.keyboard

import android.content.ComponentName
import android.content.Context
import android.content.Intent
import android.provider.Settings
import android.view.inputmethod.InputMethodManager
import com.facebook.react.bridge.Arguments
import com.facebook.react.bridge.Promise
import com.facebook.react.bridge.ReactApplicationContext
import com.facebook.react.bridge.ReactContextBaseJavaModule
import com.facebook.react.bridge.ReactMethod
import com.facebook.react.bridge.UiThreadUtil

class SarabKeyboardSettingsModule(
  private val appContext: ReactApplicationContext,
) : ReactContextBaseJavaModule(appContext) {
  override fun getName(): String = "SarabKeyboardSettings"

  @ReactMethod
  fun getKeyboardStatus(promise: Promise) {
    try {
      val enabled = Settings.Secure.getString(
        appContext.contentResolver,
        Settings.Secure.ENABLED_INPUT_METHODS,
      ).orEmpty()
      val current = Settings.Secure.getString(
        appContext.contentResolver,
        Settings.Secure.DEFAULT_INPUT_METHOD,
      ).orEmpty()
      val enabledHere = containsOurService(enabled)
      val selectedHere = containsOurService(current)
      val result = Arguments.createMap().apply {
        putBoolean("enabled", enabledHere)
        putBoolean("selected", selectedHere)
      }
      promise.resolve(result)
    } catch (error: Exception) {
      promise.reject("SARAB_STATUS_FAILED", "تعذّر قراءة حالة لوحة المفاتيح", error)
    }
  }

  @ReactMethod
  fun openInputMethodSettings(promise: Promise) {
    UiThreadUtil.runOnUiThread {
      try {
        val intent = Intent(Settings.ACTION_INPUT_METHOD_SETTINGS)
          .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        val activity = appContext.currentActivity
        if (activity != null) activity.startActivity(intent) else appContext.startActivity(intent)
        promise.resolve(null)
      } catch (error: Exception) {
        promise.reject("SARAB_SETTINGS_FAILED", "تعذّر فتح إعدادات لوحات المفاتيح", error)
      }
    }
  }

  @ReactMethod
  fun showInputMethodPicker(promise: Promise) {
    UiThreadUtil.runOnUiThread {
      try {
        val manager = appContext.getSystemService(Context.INPUT_METHOD_SERVICE) as? InputMethodManager
        if (manager == null) {
          promise.reject("SARAB_PICKER_UNAVAILABLE", "قائمة لوحات المفاتيح غير متاحة")
          return@runOnUiThread
        }
        manager.showInputMethodPicker()
        promise.resolve(null)
      } catch (error: Exception) {
        promise.reject("SARAB_PICKER_FAILED", "تعذّر عرض قائمة لوحات المفاتيح", error)
      }
    }
  }

  private fun containsOurService(value: String): Boolean {
    val expectedPackage = appContext.packageName
    val expectedService = "com.alsarab.keyboard.SarabInputMethodService"
    return value.split(':').any { flattened ->
      // ENABLED_INPUT_METHODS قد يكون بصيغة id;subtypeHash;subtypeHash، فنأخذ الـ id فقط
      val component = ComponentName.unflattenFromString(flattened.substringBefore(';').trim())
      component != null &&
        component.packageName == expectedPackage &&
        component.className == expectedService
    }
  }
}
