package com.alsarab.keyboard

import android.content.Intent
import android.graphics.Color
import android.graphics.drawable.GradientDrawable
import android.inputmethodservice.InputMethodService
import android.os.Build
import android.view.Gravity
import android.view.View
import android.view.inputmethod.EditorInfo
import android.view.inputmethod.InputMethodManager
import android.view.inputmethod.InputMethodSubtype
import android.widget.LinearLayout
import android.widget.TextView
import java.util.Locale

class SarabInputMethodService : InputMethodService() {
  private var isEnglish = false
  private var symbolsPage = false
  private var shifted = false

  private data class KeySpec(
    val label: String,
    val weight: Float = 1f,
    val accent: Boolean = false,
    val gold: Boolean = false,
    val onPress: () -> Unit,
    val onLongPress: (() -> Unit)? = null,
  )

  override fun onCreateInputView(): View = createKeyboardView()

  override fun onStartInputView(attribute: EditorInfo, restarting: Boolean) {
    super.onStartInputView(attribute, restarting)
    syncLanguageFromSubtype()
    shifted = false
    symbolsPage = false
    setInputView(createKeyboardView())
  }

  override fun onCurrentInputMethodSubtypeChanged(subtype: InputMethodSubtype) {
    super.onCurrentInputMethodSubtypeChanged(subtype)
    applySubtype(subtype)
    setInputView(createKeyboardView())
  }

  private fun syncLanguageFromSubtype() {
    val manager = getSystemService(INPUT_METHOD_SERVICE) as? InputMethodManager
    val subtype = manager?.currentInputMethodSubtype ?: return
    applySubtype(subtype)
  }

  private fun applySubtype(subtype: InputMethodSubtype) {
    val localeTag = if (Build.VERSION.SDK_INT >= 24) subtype.languageTag else subtype.locale
    isEnglish = localeTag.startsWith("en", ignoreCase = true)
  }

  private fun createKeyboardView(): View {
    val root = LinearLayout(this).apply {
      orientation = LinearLayout.VERTICAL
      layoutDirection = if (isEnglish) View.LAYOUT_DIRECTION_LTR else View.LAYOUT_DIRECTION_RTL
      setPadding(dp(6), dp(5), dp(6), dp(7))
      background = GradientDrawable(
        GradientDrawable.Orientation.TOP_BOTTOM,
        intArrayOf(Color.rgb(84, 94, 106), Color.rgb(54, 62, 73)),
      ).apply { cornerRadius = dp(10).toFloat() }
    }

    val toolbar = listOf(
      KeySpec("⚙", weight = 1f, onPress = { openAppSettings() }),
      KeySpec("السراب", weight = 2.7f, onPress = {}),
      KeySpec("⇄", weight = 1f, accent = true, onPress = { showImePicker() }),
    )
    addRow(root, toolbar, 34)

    buildLetterRows().forEachIndexed { index, row ->
      addRow(root, row, if (index == 2) 45 else 42)
    }
    addRow(root, buildBottomRow(), 48)
    return root
  }

  private fun buildLetterRows(): List<List<KeySpec>> {
    if (symbolsPage) {
      val digits = if (isEnglish) "1234567890" else "١٢٣٤٥٦٧٨٩٠"
      val first = digits.map { characterKey(it.toString()) }
      val secondChars = if (shifted) {
        listOf("~", "`", "|", "•", "√", "π", "÷", "×", "¶", "∆")
      } else {
        listOf("@", "#", "\$", "%", "&", "-", "+", "(", ")", "/")
      }
      val thirdChars = if (shifted) {
        listOf("<", ">", "=", "[", "]", "{", "}", "\\", "€")
      } else {
        listOf("*", "\"", "'", ":", ";", "!", "?", "؟", "،")
      }
      val third = listOf(shiftKey()) + thirdChars.map { characterKey(it) } + listOf(backspaceKey())
      return listOf(first, secondChars.map { characterKey(it) }, third)
    }

    if (isEnglish) {
      val first = "qwertyuiop".map { characterKey(it.toString()) }
      val second = "asdfghjkl".map { characterKey(it.toString()) }
      val third = listOf(shiftKey()) + "zxcvbnm".map { characterKey(it.toString()) } + listOf(backspaceKey())
      return listOf(first, second, third)
    }

    val first = listOf("ض", "ص", "ث", "ق", "ف", "غ", "ع", "ه", "خ", "ح", "ج", "د")
      .map { characterKey(it, longPressOutput = if (it == "د") "ذ" else null) }
    val second = listOf("ش", "س", "ي", "ب", "ل", "ا", "ت", "ن", "م", "ك", "ط")
      .map { characterKey(it, longPressOutput = if (it == "ط") "ظ" else null) }
    val thirdLetters = listOf("ئ", "ء", "ؤ", "ر", "لا", "ى", "ة", "و")
      .map { characterKey(it, longPressOutput = if (it == "ر") "ز" else null) }
    val third = listOf(shiftKey()) + thirdLetters + listOf(backspaceKey())
    return listOf(first, second, third)
  }

  private fun buildBottomRow(): List<KeySpec> {
    val symbolsLabel = when {
      symbolsPage -> if (isEnglish) "ABC" else "أبج"
      isEnglish -> "?123"
      else -> "؟١٢٣"
    }
    val comma = if (isEnglish) "," else "،"
    val period = if (isEnglish) "." else "؟"
    val spaceLabel = if (isEnglish) "English" else "العربية"

    return listOf(
      KeySpec(symbolsLabel, weight = 1.4f, accent = true, onPress = { toggleSymbols() }),
      KeySpec(comma, weight = 0.8f, onPress = { commitCharacter(comma) }),
      KeySpec("ع / EN", weight = 1.2f, accent = true, onPress = { switchLanguage() }),
      KeySpec(spaceLabel, weight = 4.0f, onPress = { currentInputConnection?.commitText(" ", 1) }),
      KeySpec(period, weight = 0.8f, onPress = { commitCharacter(period) }),
      KeySpec("↵", weight = 1.4f, gold = true, onPress = { sendEnter() }),
    )
  }

  private fun characterKey(value: String, longPressOutput: String? = null): KeySpec {
    val label = when {
      isEnglish && shifted && value.length == 1 -> value.uppercase(Locale.ROOT)
      !isEnglish && shifted -> arabicDiacritics[value] ?: value
      else -> value
    }
    val longPressAction = longPressOutput?.let { alternate -> { commitCharacter(alternate) } }
    return KeySpec(
      label = label,
      onPress = { commitCharacter(value) },
      onLongPress = longPressAction,
    )
  }

  private fun shiftKey() = KeySpec(
    label = if (shifted) "⇧" else "⬆",
    weight = 1.35f,
    accent = true,
    onPress = {
      shifted = !shifted
      refreshKeyboard()
    },
  )

  private fun backspaceKey() = KeySpec(
    label = "⌫",
    weight = 1.35f,
    accent = true,
    onPress = { deleteCharacter() },
    onLongPress = { deleteWord() },
  )

  private fun addRow(parent: LinearLayout, keys: List<KeySpec>, rowHeight: Int) {
    val row = LinearLayout(this).apply {
      orientation = LinearLayout.HORIZONTAL
      layoutDirection = if (isEnglish) View.LAYOUT_DIRECTION_LTR else View.LAYOUT_DIRECTION_RTL
      gravity = Gravity.CENTER
    }

    keys.forEach { spec ->
      val button = TextView(this).apply {
        text = spec.label
        gravity = Gravity.CENTER
        includeFontPadding = false
        maxLines = 1
        textSize = if (spec.label.length > 3) 12f else 17f
        setTypeface(typeface, android.graphics.Typeface.BOLD)
        setTextColor(if (spec.gold) Color.rgb(34, 39, 45) else Color.WHITE)
        background = keyBackground(spec.accent, spec.gold)
        isFocusable = false
        setOnClickListener { spec.onPress() }
        spec.onLongPress?.let { longAction ->
          setOnLongClickListener {
            longAction()
            true
          }
        }
      }
      val params = LinearLayout.LayoutParams(0, dp(rowHeight), spec.weight)
      params.setMargins(dp(2), dp(3), dp(2), dp(3))
      row.addView(button, params)
    }

    parent.addView(
      row,
      LinearLayout.LayoutParams(
        LinearLayout.LayoutParams.MATCH_PARENT,
        dp(rowHeight + 6),
      ),
    )
  }

  private fun keyBackground(accent: Boolean, gold: Boolean): GradientDrawable {
    val colors = when {
      gold -> intArrayOf(Color.rgb(255, 220, 90), Color.rgb(239, 184, 38))
      accent -> intArrayOf(Color.rgb(40, 130, 141), Color.rgb(25, 99, 110))
      else -> intArrayOf(Color.rgb(111, 121, 133), Color.rgb(76, 86, 98))
    }
    return GradientDrawable(GradientDrawable.Orientation.TOP_BOTTOM, colors).apply {
      cornerRadius = dp(5).toFloat()
      setStroke(dp(1), Color.argb(85, 240, 244, 247))
    }
  }

  private fun refreshKeyboard() {
    setInputView(createKeyboardView())
  }

  private fun toggleSymbols() {
    symbolsPage = !symbolsPage
    shifted = false
    refreshKeyboard()
  }

  private fun switchLanguage() {
    val changed = try {
      shouldOfferSwitchingToNextInputMethod() && switchToNextInputMethod(true)
    } catch (_: Exception) {
      false
    }
    if (!changed) {
      isEnglish = !isEnglish
      symbolsPage = false
      shifted = false
      refreshKeyboard()
    }
  }

  private fun showImePicker() {
    val manager = getSystemService(INPUT_METHOD_SERVICE) as? InputMethodManager
    manager?.showInputMethodPicker()
  }

  private fun openAppSettings() {
    val launchIntent = packageManager.getLaunchIntentForPackage(packageName)
    if (launchIntent != null) {
      launchIntent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
      startActivity(launchIntent)
    } else {
      requestHideSelf(0)
    }
  }

  private fun commitCharacter(value: String) {
    val output = when {
      isEnglish && shifted && value.length == 1 -> value.uppercase(Locale.ROOT)
      !isEnglish && shifted -> arabicDiacritics[value] ?: value
      else -> value
    }
    currentInputConnection?.commitText(output, 1)
    if (shifted) {
      shifted = false
      refreshKeyboard()
    }
  }

  private fun deleteCharacter() {
    currentInputConnection?.deleteSurroundingTextInCodePoints(1, 0)
  }

  private fun deleteWord() {
    val connection = currentInputConnection ?: return
    val before = connection.getTextBeforeCursor(100, 0)?.toString() ?: return
    val suffix = before.takeLastWhile { !it.isWhitespace() }
    val count = suffix.codePointCount(0, suffix.length)
    if (count > 0) connection.deleteSurroundingTextInCodePoints(count, 0)
  }

  private fun sendEnter() {
    val connection = currentInputConnection ?: return
    val action = currentInputEditorInfo?.imeOptions?.and(EditorInfo.IME_MASK_ACTION)
      ?: EditorInfo.IME_ACTION_NONE
    val handled = when (action) {
      EditorInfo.IME_ACTION_GO,
      EditorInfo.IME_ACTION_SEARCH,
      EditorInfo.IME_ACTION_SEND,
      EditorInfo.IME_ACTION_NEXT,
      EditorInfo.IME_ACTION_DONE -> connection.performEditorAction(action)
      else -> false
    }
    if (!handled) connection.commitText("\n", 1)
  }

  private fun dp(value: Int): Int = (value * resources.displayMetrics.density).toInt()

  companion object {
    private val arabicDiacritics = mapOf(
      "ض" to "َ", "ص" to "ً", "ث" to "ُ", "ق" to "ٌ",
      "ف" to "ِ", "غ" to "ٍ", "ع" to "ْ", "ه" to "ّ",
    )
  }
}
