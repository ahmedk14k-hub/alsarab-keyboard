# تقرير الهندسة العكسية الأولي — كيبورد السراب

## خلاصة الملف القديم

تم فحص `Alsarab_keyboard.2.45.apk` قراءةً فقط. الحزمة هي `inputmethod.latin.perfectkeyboard`، إصدارها 2.45، وتعلن `minSdkVersion=8` و`targetSdkVersion=14`. خدمة `com.android.inputmethod.latin.DictionaryEditor` موجودة في الـManifest، وترث من `InputMethodService`، وتعلن الإذن `BIND_INPUT_METHOD`، ومرشح الإجراء `android.view.InputMethod`، وملف metadata باسم `android.view.im`. لذلك فالتطبيق يحتوي فعلًا على هيكل لوحة مفاتيح نظام، وليس مجرد شاشة شكلية.

## أسباب محتملة لتعطلها على Android الحديث

1. **منع التثبيت على Android 14 إذا استُخدم APK الأصلي مباشرة:** `targetSdkVersion=14` أقل من الحد الأدنى 23 الذي يمنع Android 14 تثبيت APK جديد يستهدفه. هذا يفسر فشل تثبيت الملف الأصلي على أجهزة Android 14، لكنه لا يفسر وحده فشل تشغيل النسخة التجريبية التي رُفع هدفها إلى 26.
2. **غياب تعريف اللغات الفرعية:** `res/xml/method.xml` يعلن نوع الإدخال وإعداداته، لكنه لا يحتوي عناصر `<subtype>` للعربية أو الإنجليزية. توثيق Android يبيّن أن subtypes هي ما يعرّف لغات/أنماط الكيبورد ويُستخدم في قوائم الإعدادات والتبديل. قد يؤثر غيابها على عرض اللغات والتبديل، لكنه لا يثبت وحده سبب اختفاء الخدمة.
3. **اعتماد محرك الاقتراحات على مكتبات قديمة:** توجد مكتبة `libjni_latinime_pt2_new.so` لمعمارية `armeabi` و`armeabi-v7a` و`x86` و`mips` فقط. لا توجد نسخ `arm64-v8a` أو`x86_64`. تحميل المكتبة محاط بمعالجة `UnsatisfiedLinkError`، لكن عدم وجود المكتبة المناسبة قد يعطل وظائف تعتمد على JNI، مثل الاقتراحات والقواميس، أو يسبب عطلًا عند استخدامها على جهاز لا يدعم تشغيل 32-بت.
4. **صلاحيات ميزات قديمة:** يطلب الملف الميكروفون وجهات الاتصال والتخزين الخارجي، ولا يحتوي كودًا ظاهرًا لواجهات طلب الصلاحيات وقت التشغيل. رفع target SDK وحده قد يجعل الصوت أو اقتراحات جهات الاتصال أو الوصول إلى التخزين غير متاح؛ لا يُتوقع أن يمنع ذلك إدخال الأحرف الأساسي بحد ذاته.
5. **مكوّنات Manifest قديمة:** بعض الأنشطة والخدمات التي تحتوي intent filters لا تعلن `android:exported`. إذا استهدف تطبيق جديد Android 12/API 31 أو أعلى، يجب إعلان قيمة `exported` صراحةً للمكونات ذات intent filters. النسخة القديمة تستهدف API 14، والنسخة التجريبية المعبأة استهدفت API 26؛ لذلك لا يمكن تحميل هذا السبب مباشرةً كسبب مؤكد لفشل النسخة التجريبية.

## ما يمكن استعادته بصريًا ووظيفيًا

الموارد تتضمن صفوف لوحة مفاتيح عربية/إنجليزية ورموزًا وأرقامًا، وتخطيطات QWERTY وAZERTY وCompact وSplit وT9، وعدة أشكال مرئية مثل Basic وICS وiPhone وHTC وHoneycomb وSilicon وStone. توجد أصول لخلفية الكيبورد، والمفاتيح وحالات الضغط، وشريط الاقتراحات، وأيقونات Shift والحذف والإعدادات والصوت واللغة. اللون العام يميل إلى الرمادي الداكن مع مفاتيح بارزة ولمسات ذهبية/تركوازية. لا توجد خطوط TTF/OTF مضمّنة.

توجد مكونات مرتبطة بالقاموس والتصحيح التلقائي والصوت وجهات الاتصال والجلود. بعض قواميس اللغة والتكاملات مرتبطة بحزم خارجية، لذلك لا يمكن استعادة محرك الاقتراحات الكامل من APK وحده. كذلك لا تثبت الموارد وحدها كل سلوك التطبيق أثناء التشغيل.

## حدود ما نعرفه الآن

هذا تحليل ثابت للـAPK؛ لم يُشغّل التطبيق على جهاز Android ولم تُجمع سجلات Logcat. لا يمكن الجزم بسبب عدم ظهور/عمل النسخة التجريبية على جهاز Honor من الملف وحده. نحتاج عند تشخيص النسخة القديمة تسجيل Logcat أثناء التفعيل والاختيار، ومعرفة رقم طراز Honor الدقيق وإصدار Android. أمّا التطبيق الجديد، فسيستخدم خدمة إدخال جديدة ومكتبات Java/Kotlin فقط بدل JNI القديم، مع تعريف صريح لخدمته وsubtypes العربية والإنجليزية.

## المصادر التقنية

- Android Developers، [Create an input method](https://developer.android.com/develop/ui/views/touch-and-input/creating-input-method): تعريف خدمة IME، الصلاحية والـintent filter والـmetadata، ودور subtypes في اختيار اللغات والتبديل.
- Android Developers، [Behavior changes: all apps on Android 14](https://developer.android.com/about/versions/14/behavior-changes-all): حظر تثبيت التطبيقات التي تستهدف أقل من API 23، مع استثناء التطبيقات القديمة التي كانت مثبتة قبل ترقية الجهاز.
- Android Developers، [Behavior changes: all apps on Android 15](https://developer.android.com/about/versions/15/behavior-changes-all): رفع الحد الأدنى للتثبيت إلى API 24.
- Android Developers، [Behavior changes for apps targeting Android 12](https://developer.android.com/about/versions/12/behavior-changes-12): اشتراط `android:exported` للمكونات ذات intent filters عندما يكون target API 31 أو أعلى.
- Android Developers، [Android ABIs](https://developer.android.com/ndk/guides/abis): اختلاف المكتبات الأصلية بحسب معمارية الجهاز وضرورة وجود ABI مناسب.
- Expo، [Create and use config plugins](https://docs.expo.dev/config-plugins/plugins/) و[EAS Build](https://docs.expo.dev/build/introduction/): دعم تعديل AndroidManifest والبناء السحابي للتطبيقات الأصلية المضمنة في مشروع Expo.
