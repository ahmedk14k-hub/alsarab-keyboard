import { useEffect, useState } from "react";
import {
  AppState,
  Image,
  NativeModules,
  Platform,
  Pressable,
  ScrollView,
  StyleSheet,
  Text,
  View,
} from "react-native";
import { SafeAreaView } from "react-native-safe-area-context";

type KeyboardStatus = { enabled: boolean; selected: boolean };
type KeyboardBridge = {
  getKeyboardStatus: () => Promise<KeyboardStatus>;
  openInputMethodSettings: () => Promise<void>;
  showInputMethodPicker: () => Promise<void>;
};

const nativeBridge = NativeModules.SarabKeyboardSettings as KeyboardBridge | undefined;
const previewRows = [
  ["ض", "ص", "ث", "ق", "ف", "غ", "ع", "ه", "خ", "ح", "ج", "د"],
  ["ش", "س", "ي", "ب", "ل", "ا", "ت", "ن", "م", "ك", "ط"],
  ["⇧", "ئ", "ء", "ؤ", "ر", "لا", "ى", "ة", "و", "⌫"],
];

export default function HomeScreen() {
  const [status, setStatus] = useState<KeyboardStatus | null>(null);
  const [notice, setNotice] = useState("");

  useEffect(() => {
    let active = true;
    const refresh = async () => {
      if (Platform.OS !== "android" || !nativeBridge) return;
      try {
        const next = await nativeBridge.getKeyboardStatus();
        if (active) setStatus(next);
      } catch {
        if (active) setStatus(null);
      }
    };
    void refresh();
    const subscription = AppState.addEventListener("change", (state) => {
      if (state === "active") void refresh();
    });
    return () => {
      active = false;
      subscription.remove();
    };
  }, []);

  const openSettings = async () => {
    setNotice("");
    if (Platform.OS !== "android" || !nativeBridge) {
      setNotice("تفعيل لوحة النظام يحتاج تثبيت نسخة Android، وليس معاينة الويب أو Expo Go.");
      return;
    }
    try {
      await nativeBridge.openInputMethodSettings();
    } catch {
      setNotice("تعذّر فتح إعدادات لوحات المفاتيح. افتحها يدويًا من إعدادات الهاتف.");
    }
  };

  const showPicker = async () => {
    setNotice("");
    if (Platform.OS !== "android" || !nativeBridge) {
      setNotice("قائمة الاختيار تظهر بعد تثبيت نسخة Android وتفعيل لوحة السراب أولًا.");
      return;
    }
    if (!status?.enabled) {
      setNotice("فعّل كيبورد السراب من إعدادات الهاتف أولًا، ثم ارجع واختره.");
      return;
    }
    try {
      await nativeBridge.showInputMethodPicker();
    } catch {
      setNotice("تعذّر عرض قائمة لوحات المفاتيح. اختر السراب من إعدادات الإدخال.");
    }
  };

  const statusLabel = status?.selected
    ? "محدّد حاليًا"
    : status?.enabled
      ? "مفعّل — اختره للكتابة"
      : Platform.OS === "android" && nativeBridge
        ? "بانتظار التفعيل"
        : Platform.OS === "web"
          ? "معاينة الواجهة فقط — خدمة الكيبورد داخل نسخة Android"
          : "تحتاج تثبيت APK Android لتفعيل الخدمة";

  return (
    <SafeAreaView style={styles.safeArea} edges={["top", "bottom"]}>
      <ScrollView contentContainerStyle={styles.content} showsVerticalScrollIndicator={false}>
        <View style={styles.header}>
          <View style={styles.brandCopy}>
            <Text style={styles.eyebrow}>لوحة مفاتيح عربية</Text>
            <Text style={styles.title}>السراب البعيد</Text>
            <Text style={styles.subtitle}>شكل مألوف، وبنية جديدة لأندرويد الحديث</Text>
          </View>
          <Image source={require("../assets/images/icon.png")} style={styles.logo} />
        </View>

        <View style={styles.statusCard}>
          <View style={styles.statusTop}>
            <View style={[styles.statusDot, status?.enabled ? styles.statusDotOn : null]} />
            <Text style={styles.statusLabel}>{statusLabel}</Text>
          </View>
          <Text style={styles.cardTitle}>خلّ السراب كيبوردك</Text>
          <Text style={styles.bodyText}>
            فعّله من إعدادات الهاتف، وبعدها اختاره من قائمة لوحات المفاتيح حتى تكتب بيه بأي تطبيق.
          </Text>
          <Pressable
            accessibilityRole="button"
            onPress={openSettings}
            style={({ pressed }) => [styles.primaryButton, pressed && styles.pressed]}
          >
            <Text style={styles.primaryButtonText}>فتح إعدادات لوحات المفاتيح</Text>
            <Text style={styles.buttonArrow}>‹</Text>
          </Pressable>
          <Pressable
            accessibilityRole="button"
            onPress={showPicker}
            style={({ pressed }) => [styles.secondaryButton, pressed && styles.pressed]}
          >
            <Text style={styles.secondaryButtonText}>اختيار لوحة المفاتيح</Text>
          </Pressable>
        </View>

        {notice ? (
          <View style={styles.noticeBox}>
            <Text style={styles.noticeText}>{notice}</Text>
          </View>
        ) : null}

        <View style={styles.sectionHeading}>
          <Text style={styles.sectionTitle}>معاينة التخطيط</Text>
          <Text style={styles.sectionMeta}>عربي · English</Text>
        </View>
        <View style={styles.previewCard}>
          <View style={styles.previewToolbar}>
            <Text style={styles.previewToolbarText}>السراب</Text>
            <Text style={styles.previewToolbarMeta}>⇄  الإعدادات</Text>
          </View>
          {previewRows.map((row, rowIndex) => (
            <View key={`row-${rowIndex}`} style={styles.previewRow}>
              {row.map((key) => (
                <View
                  key={`${rowIndex}-${key}`}
                  style={[
                    styles.previewKey,
                    key === "⇧" || key === "⌫" ? styles.previewActionKey : null,
                  ]}
                >
                  <Text style={styles.previewKeyText}>{key}</Text>
                </View>
              ))}
            </View>
          ))}
          <View style={styles.previewBottomRow}>
            <View style={[styles.previewKey, styles.previewActionKey]}>
              <Text style={styles.previewKeyText}>؟١٢٣</Text>
            </View>
            <View style={[styles.previewKey, styles.previewSpaceKey]}>
              <Text style={styles.previewSpaceText}>العربية</Text>
            </View>
            <View style={[styles.previewKey, styles.previewEnterKey]}>
              <Text style={styles.previewEnterText}>↵</Text>
            </View>
          </View>
        </View>

        <View style={styles.stepCard}>
          <Text style={styles.sectionTitle}>طريقة التفعيل</Text>
          <View style={styles.stepRow}>
            <Text style={styles.stepNumber}>١</Text>
            <Text style={styles.stepText}>اضغط «فتح إعدادات لوحات المفاتيح» وفعّل كيبورد السراب.</Text>
          </View>
          <View style={styles.stepRow}>
            <Text style={styles.stepNumber}>٢</Text>
            <Text style={styles.stepText}>ارجع للتطبيق واضغط «اختيار لوحة المفاتيح»، ثم اختر السراب.</Text>
          </View>
          <Text style={styles.smallNote}>
            قد يعرض Android تحذيرًا عامًا لأن لوحات المفاتيح تتعامل مع النص الذي تكتبه. هذا الإصدار يعالج الإدخال محليًا ولا يحفظ النص أو يرسله.
          </Text>
        </View>

        <View style={styles.limitsCard}>
          <Text style={styles.limitsTitle}>الإصدار الأول</Text>
          <Text style={styles.limitsText}>
            كتابة أساسية بالعربية والإنجليزية مع الأرقام والرموز وShift والحذف والإدخال. الاقتراحات الذكية والتصحيح التلقائي والصوت غير متاحة حاليًا.
          </Text>
        </View>
        <Text style={styles.footer}>صُنع ليبقى خفيفًا ويشتغل على جهازك.</Text>
      </ScrollView>
    </SafeAreaView>
  );
}

const styles = StyleSheet.create({
  safeArea: { flex: 1, backgroundColor: "#F3F1E8" },
  content: { paddingHorizontal: 18, paddingTop: 14, paddingBottom: 32, gap: 16 },
  header: { flexDirection: "row-reverse", alignItems: "center", justifyContent: "space-between", paddingVertical: 8 },
  brandCopy: { flex: 1, alignItems: "flex-end", paddingRight: 6 },
  logo: { width: 64, height: 64, resizeMode: "contain" },
  eyebrow: { color: "#278B91", fontSize: 13, fontWeight: "700", textAlign: "right" },
  title: { color: "#20262A", fontSize: 27, fontWeight: "800", textAlign: "right", marginTop: 3 },
  subtitle: { color: "#6B7274", fontSize: 13, textAlign: "right", marginTop: 3 },
  statusCard: { backgroundColor: "#FFFFFF", borderRadius: 22, padding: 18, borderWidth: 1, borderColor: "#E5E2D8", shadowColor: "#293538", shadowOpacity: 0.06, shadowRadius: 12, shadowOffset: { width: 0, height: 5 }, elevation: 2 },
  statusTop: { flexDirection: "row-reverse", alignItems: "center", gap: 8, marginBottom: 12 },
  statusDot: { width: 9, height: 9, borderRadius: 6, backgroundColor: "#D2AA40" },
  statusDotOn: { backgroundColor: "#248E79" },
  statusLabel: { color: "#596468", fontSize: 13, fontWeight: "700", textAlign: "right" },
  cardTitle: { color: "#22292D", fontSize: 21, fontWeight: "800", textAlign: "right" },
  bodyText: { color: "#666F71", fontSize: 14, lineHeight: 23, textAlign: "right", marginTop: 8, marginBottom: 14 },
  primaryButton: { minHeight: 52, paddingHorizontal: 15, borderRadius: 15, backgroundColor: "#197E87", flexDirection: "row-reverse", alignItems: "center", justifyContent: "space-between" },
  primaryButtonText: { color: "#FFFFFF", fontSize: 15, fontWeight: "800", textAlign: "right" },
  buttonArrow: { color: "#DDF7F5", fontSize: 26, lineHeight: 30, marginTop: -2 },
  secondaryButton: { minHeight: 47, marginTop: 9, borderRadius: 14, borderWidth: 1, borderColor: "#D7E7E5", backgroundColor: "#F5FAF8", alignItems: "center", justifyContent: "center" },
  secondaryButtonText: { color: "#266D6E", fontSize: 14, fontWeight: "700" },
  pressed: { opacity: 0.78, transform: [{ scale: 0.99 }] },
  noticeBox: { backgroundColor: "#FFF7DF", borderColor: "#F1DEA5", borderWidth: 1, borderRadius: 14, padding: 12 },
  noticeText: { color: "#6D5A21", fontSize: 13, lineHeight: 20, textAlign: "right" },
  sectionHeading: { flexDirection: "row-reverse", alignItems: "baseline", justifyContent: "space-between", marginTop: 1 },
  sectionTitle: { color: "#263035", fontSize: 17, fontWeight: "800", textAlign: "right" },
  sectionMeta: { color: "#8A8E8C", fontSize: 12, fontWeight: "700" },
  previewCard: { backgroundColor: "#414A55", borderRadius: 18, paddingHorizontal: 7, paddingVertical: 7, gap: 0, overflow: "hidden" },
  previewToolbar: { height: 31, paddingHorizontal: 8, flexDirection: "row-reverse", alignItems: "center", justifyContent: "space-between" },
  previewToolbarText: { color: "#F1F0E9", fontSize: 12, fontWeight: "800" },
  previewToolbarMeta: { color: "#B8C2C5", fontSize: 10, fontWeight: "600" },
  previewRow: { flexDirection: "row-reverse", justifyContent: "center", gap: 3, marginBottom: 5 },
  previewKey: { flex: 1, height: 36, borderRadius: 5, backgroundColor: "#66717D", borderColor: "#87919A", borderWidth: 0.6, alignItems: "center", justifyContent: "center" },
  previewKeyText: { color: "#FFFFFF", fontSize: 12, fontWeight: "700" },
  previewActionKey: { backgroundColor: "#267F88", borderColor: "#3D9AA1" },
  previewBottomRow: { flexDirection: "row-reverse", gap: 4, marginTop: 1 },
  previewSpaceKey: { flex: 4, backgroundColor: "#727D88" },
  previewSpaceText: { color: "#F0F1EE", fontSize: 11, fontWeight: "700" },
  previewEnterKey: { flex: 1.35, backgroundColor: "#F2C94C", borderColor: "#F6D870" },
  previewEnterText: { color: "#283137", fontSize: 19, fontWeight: "900" },
  stepCard: { backgroundColor: "#EAE7DC", borderRadius: 18, padding: 16, gap: 12 },
  stepRow: { flexDirection: "row-reverse", alignItems: "flex-start", gap: 10 },
  stepNumber: { width: 27, height: 27, borderRadius: 14, overflow: "hidden", backgroundColor: "#197E87", color: "#FFFFFF", textAlign: "center", textAlignVertical: "center", fontSize: 14, fontWeight: "800" },
  stepText: { flex: 1, color: "#4F595B", fontSize: 13, lineHeight: 21, textAlign: "right" },
  smallNote: { color: "#7B7D76", fontSize: 12, lineHeight: 19, textAlign: "right", borderTopWidth: 1, borderTopColor: "#D7D3C7", paddingTop: 10 },
  limitsCard: { backgroundColor: "#FCF1CE", borderRadius: 16, padding: 15, borderWidth: 1, borderColor: "#F0D98F" },
  limitsTitle: { color: "#6A5314", fontSize: 14, fontWeight: "800", textAlign: "right", marginBottom: 5 },
  limitsText: { color: "#75632B", fontSize: 12, lineHeight: 19, textAlign: "right" },
  footer: { color: "#92958E", fontSize: 11, textAlign: "center", marginTop: 2 },
});
