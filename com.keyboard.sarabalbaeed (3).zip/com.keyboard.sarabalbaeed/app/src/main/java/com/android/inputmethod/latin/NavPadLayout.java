package com.android.inputmethod.latin;

import android.content.Context;
import android.graphics.Insets;
import android.os.Build;
import android.view.WindowInsets;
import android.widget.LinearLayout;

/**
 * Wraps the keyboard view on Android 15+ (edge-to-edge): keeps the keys above the system navigation
 * bar instead of letting the navigation buttons draw over the bottom row.
 */
public class NavPadLayout extends LinearLayout {
    public NavPadLayout(Context context) {
        super(context);
        setOrientation(VERTICAL);
    }

    @Override
    public WindowInsets onApplyWindowInsets(WindowInsets insets) {
        try {
            if (Build.VERSION.SDK_INT >= 35 && getContext().getApplicationInfo().targetSdkVersion >= 35) {
                Insets i = insets.getInsets(WindowInsets.Type.navigationBars() | WindowInsets.Type.displayCutout());
                setPadding(i.left, 0, i.right, i.bottom);
            }
        } catch (Throwable ignored) {
        }
        return insets;
    }

    @Override
    protected void onAttachedToWindow() {
        super.onAttachedToWindow();
        requestApplyInsets();
    }
}
